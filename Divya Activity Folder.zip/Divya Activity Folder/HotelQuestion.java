package HackerRankSolution;
import java.util.Scanner;
class Node1{
	int beds;
	int rate;
	int x;
	int y;
	Node1 left,right;
	Node1(int x,int y,int beds,int rate){
		this.x=x;
		this.y=y;
		this.beds=beds;
		this.rate=rate;
	}
}

class Hotelroom{
	Node1 root;
	void add(int x,int y,int beds,int rate) {
		root=insert(root,x,y,beds,rate);
	}
	Node1 insert(Node1 root,int x,int y,int beds,int rate) {
		if(root==null) {
			root=new Node1(x,y,beds,rate);
			
		}
		if(root.rate>rate) {
			root.left=insert(root.left,x,y,beds,rate);
		}
		else if(root.rate<rate) {
			root.right=insert(root.right,x,y,beds,rate);
		}
		return root;
	}
	int inOrder() {
		return display(root);
	}
	static int sum=0;
	static int multi;
	int display(Node1 root) {
		if(root==null) {
			return  0;
		}
		
		
		multi=(root.rate)*(root.rate-1);
		sum=sum+multi;
		display(root.left);
		display(root.right);
		return sum;
	}
}
public class HotelQuestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	Hotelroom h=new Hotelroom();
	for (int i = 0; i < 4; i++) {
	int x=sc.nextInt();
	int y=sc.nextInt();
	int beds=sc.nextInt();
	int rate=sc.nextInt();
	h.add(x,y,beds,rate);
	}	
	System.out.println(h.inOrder());

	}
	
}
