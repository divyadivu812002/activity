package com.customerdetails;

public interface PatientPriorityQueue {
	
		   void addPatient(Patient patient);
		   Patient getNextPatient();
		   boolean isEmpty();
		
}
