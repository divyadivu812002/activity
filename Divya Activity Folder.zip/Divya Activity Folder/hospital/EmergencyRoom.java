package com.customerdetails;

import java.util.Comparator;
import java.util.PriorityQueue;

public class EmergencyRoom implements PatientPriorityQueue {
   private PriorityQueue<Patient> patientQueue;
 private int totalUrgency;
 private int patientCount;
   public EmergencyRoom() {
       // Initialize the priority queue
	   patientQueue=new PriorityQueue<>(new PatientComparator());
	  totalUrgency=0;
	  patientCount=0;
   }
 
   @Override
   public void addPatient(Patient patient) {
       // Implement this method
	   patientQueue.add(patient);
	   totalUrgency+=patient.getUrgencyLevel();
	   patientCount++;
   }
 
   @Override
   public Patient getNextPatient() {
       // Implement this method
	   return patientQueue.poll();
   }
 
   @Override
   public boolean isEmpty() {
       // Implement this method
	   
	   return patientQueue.isEmpty();
   }
 
   public double calculateAverageUrgency() {
       // Implement this method
	   if(patientCount==0) {
		   return 0.0;
	   }
	   return (double)totalUrgency/patientCount;
   }
   private static class PatientComparator implements Comparator<Patient>{
	   @Override
	   public int compare(Patient p1,Patient p2) {
		   return Integer.compare(p1.getUrgencyLevel(), p2.getUrgencyLevel());
	   }
   }
}