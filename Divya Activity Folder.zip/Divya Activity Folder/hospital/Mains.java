package com.customerdetails;

import com.customerdetails.EmergencyRoom;
import com.customerdetails.Patient;

public class Mains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmergencyRoom er=new EmergencyRoom();
		er.addPatient(new Patient("John Doe",2));
		er.addPatient(new Patient("JaneSmith",1));
        er.addPatient(new Patient("Alice Johnson",3));
        
        	Patient nextpatient=er.getNextPatient();
        	System.out.println("Next Patient: "+nextpatient.getName());
     
        System.out.println("urgency level: "+er.calculateAverageUrgency());;
       
        
	}

}
