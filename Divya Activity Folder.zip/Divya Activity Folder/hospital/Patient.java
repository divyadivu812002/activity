package com.customerdetails;

public class Patient {
	   private String name;
	   private int urgencyLevel;
	   public Patient(String name, int urgencyLevel) {
			super();
			this.name = name;
			this.urgencyLevel = urgencyLevel;
		}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUrgencyLevel() {
		return urgencyLevel;
	}
	public void setUrgencyLevel(int urgencyLevel) {
		this.urgencyLevel = urgencyLevel;
	}
	
	
	 
}