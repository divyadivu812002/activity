package HackerRankSolution;


import java.util.*;
import java.util.stream.Collectors;

interface DeviceInventory {
   void addDevice(Device device);
   List<Device> getDevicesByCategory(String category);
   double calculateAveragePrice(String category);
}

class Device {
   private String name;
   private String category;
   private double price;

   public Device(String name, String category, double price) {
       this.name = name;
       this.category = category;
       this.price = price;
   }

   public String getName() {
       return name;
   }

   public String getCategory() {
       return category;
   }

   public double getPrice() {
       return price;
   }

   @Override
   public String toString() {
       return name;
   }
}

class InventoryManager implements DeviceInventory {
   private List<Device> devices;

   public InventoryManager() {
       devices = new ArrayList<>();
   }

   @Override
   public void addDevice(Device device) {
       devices.add(device);
   }

   @Override
   public List<Device> getDevicesByCategory(String category) {
       return devices.stream()
               .filter(device -> device.getCategory().equals(category))
               .collect(Collectors.toList());
   }

   @Override
   public double calculateAveragePrice(String category) {
       List<Device> categoryDevices = getDevicesByCategory(category);
       if (categoryDevices.isEmpty()) {
           return 0.0;
       }
       double totalPrice = categoryDevices.stream()
               .mapToDouble(Device::getPrice)
               .sum();
       return totalPrice / categoryDevices.size();
   }
   public Set<String> getAllCategories() {
       return devices.stream()
               .map(Device::getCategory)
               .collect(Collectors.toSet());
   }
}

public class DeviceSystem {
   public static void main(String[] args) {
       InventoryManager inventory = new InventoryManager();
       inventory.addDevice(new Device("Samsung ", "Phone", 500));
       inventory.addDevice(new Device("Apple ", "Phone", 600));
       inventory.addDevice(new Device("Dell ", "Laptop", 1000));
       inventory.addDevice(new Device("Xiaomi ", "Phone", 450));
       inventory.addDevice(new Device("Apple ", "Laptop", 1200));
       Set<String> categories = inventory.getAllCategories();
       for (String category : categories) {
           List<Device> devicesByCategory = inventory.getDevicesByCategory(category);
           double averagePrice = inventory.calculateAveragePrice(category);
           System.out.println("Category: " + category);
           System.out.println("Devices: " + devicesByCategory);
           System.out.printf("Average Price: %.2f\n", averagePrice);
       }
   }
}
