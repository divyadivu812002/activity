package HackerRankSolution;


import java.util.*;
 
interface Vehicle {
    String getLicensePlate();
    int getSpeed();
    String getType();
}
 
class Car implements Vehicle {
    private String licensePlate;
    private int speed;
    private String type;
 
    public Car(String licensePlate, int speed) {
        this.licensePlate = licensePlate;
        this.speed = speed;
        this.type = "Car";
    }
 
    @Override
    public String getLicensePlate() {
        return licensePlate;
    }
 
    @Override
    public int getSpeed() {
        return speed;
    }
 
    @Override
    public String getType() {
        return type;
    }
 
    @Override
    public String toString() {
        return getLicensePlate() + " (" + getType() + ")";
    }
}
 
interface TrafficController<T extends Vehicle> {
    List<T> getCrossedVehicles();
    void addCrossedVehicle(T vehicle);
    int getCrossCount(String licensePlate);
}
 
class Intersection implements TrafficController<Car> {
    private List<Car> crossedVehicles;
    private Map<String, Integer> vehicleCrossCount;
 
    public Intersection() {
        crossedVehicles = new ArrayList<>();
        vehicleCrossCount = new HashMap<>();
    }
 
    @Override
    public List<Car> getCrossedVehicles() {
        return crossedVehicles;
    }
 
    @Override
    public void addCrossedVehicle(Car car) {
        crossedVehicles.add(car);
        if (vehicleCrossCount.containsKey(car.getLicensePlate())) {
            vehicleCrossCount.put(car.getLicensePlate(), vehicleCrossCount.get(car.getLicensePlate()) + 1);
        } else {
            vehicleCrossCount.put(car.getLicensePlate(), 1);
        }
    }
 
    @Override
    public int getCrossCount(String licensePlate) {
        if (vehicleCrossCount.containsKey(licensePlate)) {
            return vehicleCrossCount.get(licensePlate);
        } else {
            return 0;
        }
    }
}
 
public class Traffic {
    public static void main(String[] args) {
        Intersection intersection = new Intersection();
 
        Car car1 = new Car("ABC123", 60);
        Car car2 = new Car("XYZ789", 80);
        Car car3 = new Car("ABC123", 70);
 
        intersection.addCrossedVehicle(car1);
        intersection.addCrossedVehicle(car2);
        intersection.addCrossedVehicle(car3);
 
        System.out.println("Cross Count for ABC123: " + intersection.getCrossCount("ABC123"));
        System.out.println("Cross Count for XYZ789: " + intersection.getCrossCount("XYZ789"));
        System.out.println("Total vehicles crossed: " + intersection.getCrossedVehicles().size());
        System.out.println("List of crossed vehicles: " + intersection.getCrossedVehicles());
    }
}