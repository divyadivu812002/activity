import java.util.*;
public class Sub {
    public static void main(String[] args) {
       // Scanner s=new Scanner(System.in);

        int arr[]={1,1,4,3,3};
        int n=arr.length;
       // System.out.println(n);
//        int c=0;
        for(int i=0;i<n;i++) {
            int j;
            for (j = 0; j < i; j++){
                if (arr[j] == arr[i]) {
//                    c+=1;
                    break;
                }}
            if (i == j) {
                System.out.print(arr[i]);
            }
        }
            }
        }


