package Arraylist.Stack;

import java.util.ArrayList;

class StackUnderFlowException extends Exception{
    public StackUnderFlowException(){
        super("No element in stack");
    }
}
class Stack{
    ArrayList a1;
    int top;

    public Stack(){
        this.a1=new ArrayList<Integer>();
        this.top=-1;
    }

    void push(int element){
        a1.add(element);
    }

    int pop() throws StackUnderFlowException{
        if(a1.size()==0){
            throw new StackUnderFlowException();
        }
        int last=a1.size()-1;
        int t=(int)a1.get(last);
        a1.remove(last);
        return t;
    }
}
public class Main {
    public static void main(String[] args) throws Exception{
        Stack myStack=new Stack();
        myStack.push(10);
        myStack.push(20);
        System.out.println(myStack.pop());
        System.out.println(myStack.pop());
        System.out.println(myStack.pop());
    }
}
