package Arraylist.Stack;

class StackUnderFlowException2 extends Exception{
    public StackUnderFlowException2(){
        super("No element in Stack");
    }
}
public class Node {
    int data;
    Node next;

    public Node(int data){
        this.data=data;
        this.next=null;
    }
}

class Methods{
    Node top;
    int size=0;

    void push(int data){
        Node temp=new Node(data);
        if(top==null){
            top=temp;
            size++;
        }
        else{
            temp.next=top;
            top=temp;
            size++;
        }
    }

    int pop() throws StackUnderFlowException2{
        int t;
        if(top==null){
            throw new StackUnderFlowException2();
        }
        else{
            t=top.data;
            top=top.next;
            size--;
        }
        return t;
    }
    int size(){
        return size;
    }
    int peek(){
        if(top==null){
            return -1;
        }
        return top.data;
    }
    boolean isEmpty(){
        if(top!=null){
            return false;
        }
        return true;
    }
}

class LL{
    public static void main(String[] args) throws StackUnderFlowException2{
       Methods stack1=new Methods();
       stack1.push(10);
//       stack1.push(20);
        System.out.println(stack1.pop());
//        System.out.println(stack1.pop());
//        System.out.println(stack1.pop());
        System.out.println(stack1.size());
        System.out.println(stack1.peek());
        System.out.println(stack1.isEmpty());
    }
}
