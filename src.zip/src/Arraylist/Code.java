package Arraylist;

import java.util.Scanner;
public class Code {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Your Account Number (e.g., XXXXXXXXXXXX6182):");
        String accountNumber = scanner.nextLine();
        System.out.println("Enter Credited Amount (e.g., 6.00):");
        String creditedAmount = scanner.nextLine();
        System.out.println("Enter Date (e.g., 9/7/2023):");
        String date = scanner.nextLine();
        System.out.println("Enter Time (e.g., 9:58:18 AM):");
        String time = scanner.nextLine();
        System.out.println("Enter Payment Mode (e.g., GOOGLEPAY or PAYTM):");
        String paymentMode = scanner.nextLine();
        System.out.println("Enter Bank Name (e.g., KVB):");
        String bankName = scanner.nextLine();
        String smsMessage = "Your a/c " + accountNumber + " is credited Rs. " + creditedAmount + " from " + paymentMode + " on " + date + " " + time + ".\n"
                + "info: UPI/P2A/325093677664 - " + bankName;
        System.out.println(smsMessage);
    }
}
