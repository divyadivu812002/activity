import java.util.*;
import java.lang.*;
public class Sample {
    public static void main(String[] args) {
        Sample ob=new Sample();
        StringBuffer a = new StringBuffer("sanjay");
        StringBuffer b = new StringBuffer("rose");
//        int tocut=ob.cancel(a,b);
        StringBuffer f = new StringBuffer("flames");


        for (int i = 0; i < a.length(); i++) {
            for (int j = 0; j < b.length(); j++) {
                 System.out.println(a.charAt(i)+"="+b.charAt(j));
                if (a.charAt(i) == b.charAt(j)) {
                    System.out.println(a.charAt(i)+"="+b.charAt(j));
                    a.delete(i, i + 1);
                    b.delete(j, j + 1);
                    i = i - 1;
                    break;


                }
            }

        }

        int l= a.length() + b.length();
        System.out.println(l);
        int n=0;
        int k=f.length();

//        while (f.length()!=1){
//            int c=0;
//            for (int i = 1; i <tocut; i++) {
//                if(c>=f.length())
//                    c=0;
//                ++c;
//
//            }
//            f=f.substring(0,c-1)+f.substring(c);
//            f=f.trimToSize();
//        }

//        System.out.println(n);
//        for (int i = 0; i < f.length(); i++) {
//
//
//            int ind = (n % f.length()) ;
//            if (ind == -1) {
//                ind += 1;
//            }
//            f.delete(ind-1, ind);
//            int temp = ind;
//           // System.out.println(temp);
//
//
//            System.out.println(f);
//
//
//        }
            for (int i = 0; i < f.length(); i++) {
                System.out.print(f.charAt(i));
            }




    }
}

