package Placement;
public class Areaofrect {
    public static int area(int a,int b){
        int c=a*b;
        System.out.println(c);
        return 0;
    }
    public static void main(String[] args) {
        int a=5,b=10;
        area(a,b);
    }
}
