package Hashmap;

import java.util.HashMap;

public class Diffofk {
        public static int countPairsWithDifferenceK(int[] arr, int k) {
            HashMap<Integer, Integer> map = new HashMap<>();
            int count = 0;
            for (int i:arr) {
                if (map.containsKey(i)) {
                    map.put(i, map.get(i) + 1);
                    if (k == 0) {
                        count++;
                    }
                } else
                    map.put(i, 1);
            }
                for (int i:arr){
                if (k!=0 && map.containsKey(i-k)) {
                    count++;
                }
                }

            return count;
        }
        public static void main(String[] args) {
            int[] arr = {5,-8,12,15,4};
            int k = -4;
            System.out.println("Output: " + countPairsWithDifferenceK(arr, k)); // Output: 2
        }
    }
