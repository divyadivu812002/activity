package Hashmap;

import java.util.*;

public class Uniq {
    public static void main(String[] args) {
        int[] s = {3, 2, 4, 1, 2, 3, 6, 4};
        //char[] arr=s.toCharArray();
        HashMap<Integer, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < s.length; i++) {
            if (map.containsKey(s[i])) {
                map.put(s[i], map.get(s[i]) + 1);
            } else {
                map.put(s[i], 1);
            }
        }
        int[] arr=new int[map.size()];
        for (int i = 0; i <map.size(); i++) {
        for (Map.Entry<Integer,Integer> entry : map.entrySet()) {
                // System.out.print(entry.getKey()+" ");
                arr[i] = entry.getKey();
            }
        }
        Set<Integer> set=map.keySet();
        //System.out.println(set);
//        for (Integer i:set){
//            System.out.println(i);
//        }

        //  System.out.println(set);
        System.out.println(Arrays.toString(arr));
    }
}
