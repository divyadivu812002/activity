package Hashmap;

import java.util.HashMap;

public class Longest_K_Distinct {
    static void longsub(String str,int k){
        int s=0,e=0;
        HashMap<Character,Integer> map=new HashMap<>();
        while (e<str.length()){
            char c=str.charAt(e);
            map.put(c,map.getOrDefault(c,0)+1);
           // System.out.print(map.keySet());

            while (map.size()>k){
                char d=str.charAt(s);
                if(map.get(d)==1){
                    map.remove(d);

                }
                else {
                    map.put(d,map.get(d)-1);
                }

                s++;
            }
            e++;
            System.out.print(map.keySet());
        }
    }
    public static void main(String[] args) {
        String str="aabcbcdef";
        int k=2;
        longsub(str,k);
    }
}
