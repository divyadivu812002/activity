package Hashmap;
import java.io.*;
import java.util.*;
public class Occr {
        static void characterCount(String inputString)
        {
            HashMap<Character, Integer> charCountMap = new LinkedHashMap<Character, Integer>();
            char[] strArray = inputString.toCharArray();
            for (char c : strArray) {
                if (charCountMap.containsKey(c)) {
                    charCountMap.put(c, charCountMap.get(c) + 1);
                }
                else {
                    charCountMap.put(c, 1);
                }
            }
            for (Map.Entry entry : charCountMap.entrySet()) {
                System.out.print(entry.getKey() + " " + entry.getValue()+" ");
                System.out.println();
            }
        }
        public static void main(String[] args)
        {
            String str = "Ajitj";
            characterCount(str);
        }
    }


