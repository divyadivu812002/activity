package Hashmap;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Hash2 {
    public static void main(String[] args) {
        int[] nums = {1, 2, 4, 1, 3};
        int k = 3;
        // int n=arr.length;
        HashMap<Integer, Integer> map = new LinkedHashMap<>();
        int s = 0, end = 0;
        int[] arr = new int[nums.length];
        for (int i = 0; i < nums.length; i++) {
            if (map.containsKey(nums[i])) {
                map.put(nums[i], map.get(nums[i]) + 1);
            } else {
                map.put(nums[i], 1);
            }
            arr[i] = i;
            if (map.containsValue(2)) {
                System.out.println(arr[i]);
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}
