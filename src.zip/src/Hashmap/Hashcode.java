package Hashmap;

import java.util.ArrayList;
import java.util.Map;

public class Hashcode<K,V> {
    ArrayList<Mapnode<K,V>> buckets;
    int count;
    int numbuckets;
    public Hashcode(){
        buckets=new ArrayList<>();
        numbuckets=20;
        for (int i = 0; i <numbuckets; i++) {
            buckets.add(null);
        }
    }
    private int getIndex(K key){
        int hc=key.hashCode();
        int ind=hc%numbuckets;
        return ind;
    }
    public int size(){
        return count;
    }
    public V getvalue(K key){
        int bucind=getIndex(key);
        Mapnode<K,V> head=buckets.get(bucind);
        while (head!=null){
            if(head.key.equals(key)){
                return head.value;
            }
            head=head.next;
        }
        return null;
    }
    private void reHash(){
        ArrayList<Mapnode<K,V>> temp=buckets;
        buckets=new ArrayList<>();
        for (int i = 0; i <2*numbuckets; i++) {
            buckets.add(null);
        }
        count=0;
        numbuckets=numbuckets*2;
        for (int i = 0; i <temp.size(); i++) {
            Mapnode<K,V> head=temp.get(i);
            while (head!=null) {
                K key = head.key;
                V value = head.value;
                insert(key,value);
                head = head.next;
            }
        }
    }
    public V remove(K key){
        int bucind=getIndex(key);
        Mapnode<K,V> head=buckets.get(bucind);
        Mapnode<K,V> previous=null;
        while (head!=null){
            if(head.key.equals(key)){
                if(previous!=null) {
                    previous.next = head.next;
                }
                else {
                    buckets.set(bucind,head.next);
                }
                count--;
                return head.value;
            }
            previous=head;
            head=head.next;
        }
        return null;
    }
    public double loadFactor(){
        return (1.0*count/numbuckets);
    }
    public void insert(K key,V value) {
        int bucind = getIndex(key);
        Mapnode<K, V> head = buckets.get(bucind);
        while (head != null) {
            if (head.key.equals(key)) {
                head.value = value;
                return;
            }
            head = head.next;
        }
        head = buckets.get(bucind);
        Mapnode<K, V> newnode = new Mapnode<>(key, value);
        newnode.next = head;
        buckets.set(bucind, newnode);
        count++;
        double loadFactor = (1.0 * count / numbuckets);
        if (loadFactor > 0.7) {
            reHash();
        }
    }
        public static void main(String[] args) {
            Hashcode<String,Integer> map=new Hashcode<>();
            for (int i = 0; i <20; i++) {
                map.insert("abc"+i,i+1);
                System.out.println(map.loadFactor());
            }
            map.remove("abc3");
            map.remove("abc7");
            for (int i = 0; i <20; i++) {
                System.out.println("abc"+i+":"+map.getvalue("abc"+i));

            }
        }
}
