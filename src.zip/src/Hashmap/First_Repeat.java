package Hashmap;

import java.util.HashMap;

public class First_Repeat {
    public static char repeat(char[] arr){
        HashMap<Character,Integer> map=new HashMap<>();

        for(char i:arr) {
            if (map.containsKey(i)) {
                return i;
                //map.put(i, map.get(i) + 1);
            } else
                map.put(i, 1);
        }
            return '0';
        }
    public static void main(String[] args) {
        char[] arr={'a','b','c'};
        System.out.println(repeat(arr));
    }
}
