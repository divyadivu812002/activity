package Hashmap;

import java.util.HashMap;

public class Highestfreq {
    public static int highestfreq(int[] arr){
        HashMap<Integer,Integer> map=new HashMap<>();
        int max=0,ans=0;
        for(int n:arr){
            if(map.containsKey(n)){
                map.put(n,map.get(n)+1);
            }
            else
                map.put(n,1);
        if(map.get(n)>max) {
            max = map.get(n);
            ans = n;
        }
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] arr={1,2,3,4,2,3,3,5,6};
        int res=highestfreq(arr);
        System.out.println(res);
    }
}
