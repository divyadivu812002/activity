package Hashmap;

import java.util.Arrays;
import java.util.HashMap;

public class Longestsub {
    public static void main(String[] args) {
        int arr[] = {1,2,5,6,7,8,9};
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int n : arr) {
            map.put(n, 1);
        }
        System.out.println(map);
        int s=0,e=0;
//        for (int i = 0; i < map.size(); i++) {
//            for (int j = i+1; j <map.size(); j++) {
//                if (map.containsValue(arr[i]) == map.containsValue(arr[j])) {
//                    s = arr[i];
//                    e = arr[j];
//                }
//            }
//        }
        int k=0,count=0,max=Integer.MIN_VALUE;
        int [] res=new int[2];
        for(int i :map.keySet()){
            System.out.print(i+" ");
            if (i==k+1) {
                count++;
                if(max<count) {
                    max=count;
                    res[0]=s;
                    res[1]=i;
                }
                k=i;
            }
            else {
                k = i;
                count=1;
                s=k;
            }
        }
        System.out.println();
        System.out.println("max is:"+max);
      //  System.out.println(sn+" "+e);
        //System.out.println(res[0]+" "+res[1]);
      //  for (int i = 0; i < res.length; i++) {
            if(res[1]==1){
                System.out.println(res[0]);
            }
            else
                System.out.print(res[0]+" "+res[1]);
     //   }
       // System.out.println(map.containsValue(2));
    }
}
