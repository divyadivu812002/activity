package Hashmap;

public class Hash1 {
    public static void main(String[] args) {
        String s="sanjay";
        int as=256;
        int l=s.length();
        int maxcount[]=new int[as];
        for (int i = 0; i <l; i++)
          maxcount[s.charAt(i)]++;
        int max=-1;
        int c=0;
        char res=' ';
        for (int i = 0; i <l; i++) {
            if(max<maxcount[s.charAt(i)]){
                max=maxcount[s.charAt(i)];
                res=s.charAt(i);
                c+=1;
            }

        }
        System.out.println(res);
        System.out.println(c);
    }
    }

