package Hashmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Intersection {
    public static void main(String[] args) {
        ArrayList<Integer> arr1=new ArrayList<Integer>(Arrays.asList(1,4,5,2,2,3,6,5,3,2));
        ArrayList<Integer> arr2=new ArrayList<Integer>(Arrays.asList(0,2,3,2,6,6,5,1));
        //ArrayList<Integer> arr3=new ArrayList<>();
        HashMap<Integer,Integer> map=new HashMap<>();
        for (int n:arr1){
            map.put(n,1);
        }
        System.out.println(map);
        for (int n:arr2){
            if(map.containsKey(n)){
               // map.put(n,map.get(n)+1);
                System.out.print(n+" ");
            }
        }
    }
}
