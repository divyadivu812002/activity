package Hashmap;

import java.util.HashMap;

public class Even_Freq {
    public static void main(String[] args) {
        int[] arr={2,3,4,4,2,2,4,8};
        int max=0,ch=0;
        HashMap<Integer,Integer> map=new HashMap<>();
        for(int i:arr) {
            if (i % 2 == 0) {
                if (map.containsKey(i)) {
                    map.put(i, map.get(i) + 1);
                } else
                    map.put(i, 1);
                if (ch < map.get(i)) {
                    ch = map.get(i);
                    max=i;
                    //System.out.print(max+" ");
                }
            }
        }
            System.out.print(max+" ");
        }
    }

