package Hashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Pair0 {
            static int getPairsCount(int[] arr, int n) {
                HashMap<Integer, Integer> m = new HashMap<>();
                int count = 0;
                for (int i = 0; i < n; i++) {
                    if (m.containsKey(-arr[i])) {
                        System.out.print(arr[i]+" "+-arr[i]);
                        count=count+m.get(-arr[i]);
                        System.out.println();
                    }
                    if (m.containsKey(arr[i])) {
                        m.put(arr[i], m.get(arr[i]) + 1);
                    } else {
                        m.put(arr[i], 1);
                    }

                }
                    return count;
                }
            public static void main(String[] args)
            {
                int[] arr = {5,1,7,7,9};
                int n = arr.length;
                System.out.print("Count of pairs is "
                        + getPairsCount(arr, n));
            }
        }

