package Hashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Occrofchar {
    public static void main(String[] args) {
        HashMap <Character,Integer> hash=new LinkedHashMap<>();
        String str="sanjay";
        char[] arr=str.toCharArray();
        for (int i = 0; i <str.length(); i++) {
            if(hash.containsKey(arr[i])){
                hash.put(arr[i],hash.get(arr[i])+1);
            }
            else {
                hash.put(arr[i],1);
            }

        }
        System.out.println(hash);
        //for ((Map.Entry entry:))
    }
}
