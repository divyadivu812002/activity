package Hashmap;

import java.util.HashMap;

public class MaxOccur {
    public static void main(String[] args) {
        String str = "vikkkashini";
        char[] arr = str.toCharArray();
        HashMap<Character, Integer> map = new HashMap<>();
        int max = 0,check=0;
        for (char c : arr) {
            if (map.containsKey(c)) {
                map.put(c, map.get(c) + 1);
            } else
                map.put(c, 1);
            System.out.print(map.get(c)+" ");
            if(map.get(c)>=max){
                check=max;
                max = map.get(c);
            }
        }
        System.out.println();
        if(max==check){
            System.out.println('0');
        }
        else{
            System.out.println(max);
        }
    }
}
