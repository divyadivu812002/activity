package Hashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Uniq_String {
    public static void main(String[] args) {
        String str = "sanjayS";
        char[] arr=str.toCharArray();
        HashMap<Character, Integer> map = new LinkedHashMap<>();
        for(char c:arr){
            if(!map.containsKey(c))
                map.put(c,1);
        }
        for(Map.Entry e:map.entrySet())
            System.out.print(e.getKey());
    }
}
