package Hacker;
import java.util.*;
public class Loopseries {
    public static void main(String[] args) {
//        Scanner s=new Scanner(System.in);
//        int a=s.nextInt();
//        int b=s.nextInt();
//        int n=s.nextInt();
//        for(int j = 0; j < n; j++){
//            a = a + (int)Math.pow(2,j)*b;
//            System.out.print(a + " ");
//        }
//        System.out.println("");
        int low=100,high=10000;
        int l=1,s=2;
        ArrayList<Integer> arr=new ArrayList<>();
        for(int i=0;i<=high;i++){
            if(l>i && l<=high){
                arr.add(l);
                l=(l*10)+s;
                ++s;
            }
        }
        System.out.println(arr);
    }
    }

