package Hacker;


    import java.io.*;
import java.util.*;

    public class Solution1 {

        public static void main(String[] args) {

            Scanner sc=new Scanner(System.in);
            String A=sc.next();
            A.toUpperCase();
            String B=sc.next();
            B.toUpperCase();
            int l=A.length()+B.length();
            System.out.println(l);
            //  int s=A.compareTo(B);
            if(A.compareTo(B)>=B.compareTo(A)){
                System.out.println("Yes");
            }
            else{
                System.out.println("No");
            }
            System.out.println(A+" "+B);

        }
    }



