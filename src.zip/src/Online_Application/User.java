package Online_Application;
import java.util.Scanner;
public class User {
    int id;
    static String newpassword;
    static String name;
    static String password;
    public User(String name, String password,int id){
        this.name=name;
        this.password=password;
        this.id=id;
    }
    static String encrypted_Password;

    public User() {

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public static void admin(String name, String password, int i){
        passcheck(password);
        System.out.println("Name is "+name);
        System.out.println("Password is "+encrypted_Password);
    }
    public static void passcheck(String password){
        int n=password.length();
        encrypted_Password="";
        if (password.charAt(0)>='a' && password.charAt(0)<='z') {
            for (int i = 0; i < password.length(); i++) {
                encrypted_Password += (char)(password.charAt(i)+1);
            }
        }
    }
    public boolean logins(String encrypted_Password,String password){
        String check="";
        for (int i=0;i<encrypted_Password.length();i++) {
            check += (char) (encrypted_Password.charAt(i) - 1);
        }
        System.out.println(check);
            if(!check.equals(password))
                return false;
        return true;
    }

    public void choices() {
        Scanner s = new Scanner(System.in);
        int input = 0;
        System.out.println("Choose one options from below: ");
        System.out.println("1.Change password" + "\n" + "2.Update Profile" + "\n" + "3.Create Manager" + "\n" + "Update Manager" + "\n" + "6.Add Inventory" + "\n" + "7.Update Inventory" + "\n" + "8.Remove Inventory" + "\n" + "9.View Inventory" + "\n" + "10.Logout");
    }
    public String changepassword(String password){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the new password");
        String updatepass=s.next();
        return updatepass;
    }
    public void addmanager(String name,String password,int id){
        passcheck(password);
        System.out.println(name+" "+encrypted_Password+" "+id);
    }
    public void choicesmanager(){
        Scanner s = new Scanner(System.in);
        int input = 0;
        System.out.println("Choose one options from below: ");
        System.out.println("1.Change password" + "\n" + "2.Update Profile" + "\n" + "3.Add Inventory" + "\n" + "4.Update Inventory" + "\n" + "5.Remove Inventory" + "\n" + "7.View Inventory" + "\n" + "7.Logout");
    }
}
