package Online_Application;

public class Signin {
    int id=1;
    String name;
    String email;
    String password;

    public Signin(String name, String email, String password){
        this.id++;
        this.name=name;
        this.email=email;
        this.password=password;
    }
    public Signin(){

    }

    public static void passwordencrypted(String password){
        System.out.println(password);
    }
}
