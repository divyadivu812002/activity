package Online_Application;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int[] arr = {0, 1, 2};
        List<User> signinlist = new ArrayList<>();
        int input = 1;
        while (input != 0) {
            System.out.println("For Signin 1 or For Login 2 or 0 For exit");
            input = s.nextInt();
            //String admin= String.valueOf(arr[0]);
            User login = new User();
            String name = login.getName();
            String password = login.getPassword();
            if (input == 1) {
                System.out.println("Enter number of users");
                int admin = s.nextInt();
                while (admin != 0) {
                    System.out.println("Enter name and password: ");
                    name = "Admin";
                    password = "abcd";
                    User.admin(name, password, arr[0]);
                    //signinlist.addAll(password);
                    admin--;
                }
                if (login.logins(User.encrypted_Password, password)) {
                    login.choices();
                } else {
                    System.out.println("Password is wrong");
                }
              //  User manager = new User(name, password, arr[1]);
                List<User> managers=new ArrayList<>();
                while (input != 10) {
                    input = s.nextInt();
                    switch (input) {
                        case 1: {
                            User.newpassword = login.changepassword(password);
                            login.passcheck(User.newpassword);
                            System.out.println(User.newpassword);
                            break;
                        }
                        case 2: {
                            name = name;
                            password = User.newpassword;
                            System.out.println(name + " " + password);
                            break;
                        }
                        case 3: {
                            name = s.next();
                            password = s.next();
                            //  manager.addmanager(name, password, arr[1]);
                            managers.add(new User(name, password, arr[1]));
                            break;
                        }
                        case 4: {
                            for (User elements : managers) {
                                System.out.println(elements);
                            }
                        }
                    }
                }

            }

        }
    }
}


