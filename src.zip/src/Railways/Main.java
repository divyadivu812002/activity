package Railways;

import java.util.Scanner;

public class Main {
    public static void bookticket(Passenger p){
        Ticket_Booker booker=new Ticket_Booker();
        if(Ticket_Booker.avail_waitinglist==0){
            System.out.println("No Tickets available!!");
            return;
        }
        if((p.berth_Preference.equals("L") && Ticket_Booker.avail_lower>0) ||
                (p.berth_Preference.equals("M") && Ticket_Booker.avail_middle>0) ||
                (p.berth_Preference.equals("U") && Ticket_Booker.avail_upper>0))
        {
            System.out.println("Prefered Berth Available!!");
            if(p.berth_Preference.equals("L")){
                System.out.println("Lower Berth Given");
                booker.bookTicket(p,(Ticket_Booker.lowerberthpositions.get(0)),"L");
                Ticket_Booker.lowerberthpositions.remove(0);
                Ticket_Booker.avail_lower--;
            } else if (p.berth_Preference.equals("M")) {
                System.out.println("Middle Berth Given");
                booker.bookTicket(p,(Ticket_Booker.middleberthpositions.get(0)),"M");
                Ticket_Booker.middleberthpositions.remove(0);
                Ticket_Booker.avail_middle--;
            }
            else if (p.berth_Preference.equals("U")){
                System.out.println("Upper Berth Given");
                booker.bookTicket(p,(Ticket_Booker.upperberthpositions.get(0)),"U");
                Ticket_Booker.upperberthpositions.remove(0);
                Ticket_Booker.avail_upper--;
            }
        } else if (Ticket_Booker.avail_lower>0) {
            System.out.println("Lower berth Given");
            booker.bookTicket(p,(Ticket_Booker.lowerberthpositions.get(0)),"L");
            Ticket_Booker.lowerberthpositions.remove(0);
            Ticket_Booker.avail_lower--;
        } else if (Ticket_Booker.avail_middle>0) {
            System.out.println("Middle berth Given");
            booker.bookTicket(p,(Ticket_Booker.middleberthpositions.get(0)),"M");
            Ticket_Booker.middleberthpositions.remove(0);
            Ticket_Booker.avail_middle--;
        } else if (Ticket_Booker.avail_upper>0) {
            System.out.println("Upper Berth Given");
            booker.bookTicket(p,(Ticket_Booker.upperberthpositions.get(0)),"U");
            Ticket_Booker.upperberthpositions.remove(0);
            Ticket_Booker.avail_upper--;
        } else if ( Ticket_Booker.avail_rac>0) {
            System.out.println("RAC is Given");
            booker.addtorac(p,(Ticket_Booker.racpositions.get(0)),"RAC");

        } else if (  Ticket_Booker.avail_waitinglist>0) {
            System.out.println("You are on waiting List!!");
            booker.addtowaitinglist(p,(Ticket_Booker.waitingpositions.get(0)),"WL");
        }
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        boolean loop = true;
        while (loop) {
            System.out.println(" 1. Book Ticket \n 2. Cancel Ticket \n 3. Available Tickets \n 4. Booked Tickets \n 5. Exit");
            int choice = scan.nextInt();
            switch (choice) {
                case 1: {
                    System.out.println("Enter Passenger Details and Berth Preference (L or M ot U)");
                    String name = scan.next();
                    int age = scan.nextInt();
                    String berth_Preference = scan.next();
                    Passenger p = new Passenger(name, age, berth_Preference);
                    bookticket(p);
                }
                break;
                case 5:{
                    loop=false;
                }
                break;
                default:
                    break;
            }
        }
    }
}
