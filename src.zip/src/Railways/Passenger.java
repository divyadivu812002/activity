package Railways;

public class Passenger {
    static int id=1;
    String name;
    int age;
    String berth_Preference;
    int passengerid;
    String alloted;
    int number;
    public Passenger(String name, int age,String berth_Preference){
        this.name=name;
        this.age=age;
        this.berth_Preference=berth_Preference;
    }
}
