package Railways;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.*;

public class Ticket_Booker {
    static int avail_lower=1;
    static int avail_middle=1;
    static int avail_upper=1;
    static int avail_rac=1;
    static int avail_waitinglist=1;

    static Queue<Integer> waitinglist=new LinkedList<>();
    static Queue<Integer> raclist=new LinkedList<>();

    static List<Integer> bookedTicketlist=new ArrayList<>();



    static List<Integer> lowerberthpositions=new ArrayList<>(Arrays.asList(1));
    static List<Integer> middleberthpositions=new ArrayList<>(Arrays.asList(1));
    static List<Integer> upperberthpositions= new ArrayList<>(Arrays.asList(1));

    static List<Integer> racpositions=new ArrayList<>(Arrays.asList(1));
    static List<Integer> waitingpositions=new ArrayList<>(Arrays.asList(1));

    static Map<Integer,Passenger> passengers=new HashMap<>();

    public void bookTicket(Passenger p,int berthinfo, String allotedberth){
        p.number=berthinfo;
        p.alloted=allotedberth;
        passengers.put(p.passengerid,p);
        bookedTicketlist.add(p.passengerid);
        System.out.println("------------------------ Ticket Booked Successfully!!");
    }

    public void addtorac(Passenger p,int berthinfo, String allotedrac){
        p.number=berthinfo;
        p.alloted=allotedrac;
        passengers.put(p.passengerid,p);
        raclist.add(p.passengerid);
        avail_rac--;
        racpositions.remove(0);
        System.out.println("------------------------ Added to RAC Successfully!!"+raclist.peek());
    }

    public void addtowaitinglist(Passenger p,int berthinfo,String waitingnum){
        p.number=berthinfo;
        p.alloted=waitingnum;
        passengers.put(p.passengerid,p);
        waitinglist.add(p.passengerid);
        avail_waitinglist--;
        waitingpositions.remove(0);
        System.out.println("------------------------ You are in waiting list!!"+waitinglist.peek());

    }
}
