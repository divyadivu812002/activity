package Twodarray;
import java.util.Scanner;
public class Spiralform {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int m = s.nextInt();
        int n = s.nextInt();
        int arr[][] = new int[m][n];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                arr[i][j] = s.nextInt();
            }
        }
        int row = arr.length;
        int col = arr[0].length;
        int i, rowst = 0, colst = 0;
        int elements = row * col, count = 0;
        while (count < elements) {
            for (i = colst; count < elements && i < col; ++i) {
                System.out.print(arr[rowst][i] + " ");
                count++;
            }
            rowst++;
            for (i = rowst; count < elements && i < row; ++i) {
                System.out.print(arr[i][col - 1] + " ");
                count++;
            }
            col--;
            for (i = col-1; count < elements && i >= colst; --i) {
                System.out.print(arr[row - 1][i] + " ");
                count++;
            }
            row--;
            for (i = row - 1; count < elements && i >= rowst; --i) {
                System.out.print(arr[i][colst] + " ");
                count++;
            }
            colst++;
        }
    }
}

