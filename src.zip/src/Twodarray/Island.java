package Twodarray;

import java.util.Scanner;

public class Island {
    static void mark(int[][] arr,int i,int j) {
        int row = arr.length;
        int col = arr[0].length;
        if (i < 0 || j < 0)
            return;
        if(i>=row || j>=col)
            return;
        if (arr[i][j] == 0)
            return;
        arr[i][j] = 0;
            mark(arr, i - 1, j);
            mark(arr, i + 1, j);
            mark(arr, i, j - 1);
            mark(arr, i, j + 1);
            mark(arr, i + 1, j + 1);
            mark(arr, i - 1, j - 1);
            mark(arr, i - 1, j + 1);
            mark(arr, i + 1, j - 1);
        }

    static int countofisland(int arr[][]){
        int row=arr.length;
        int col=arr[0].length;
        int count=0;
        for (int i = 0; i <row; i++) {
            for (int j = 0; j <col; j++) {
                if(arr[i][j]==1) {
                    count++;
                    mark(arr, i, j);
                }
            }

        }
        return count;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int m=s.nextInt();
        int[][] arr=new int[n][m];
        for (int i = 0; i <n; i++) {
            for (int j = 0; j <m; j++) {
                arr[i][j]=s.nextInt();
            }
        }
        System.out.println(countofisland(arr));
    }
}
