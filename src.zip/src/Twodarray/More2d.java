package Twodarray;
import java.util.*;
public class More2d {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int r=s.nextInt();
        int c=s.nextInt();
        int arr[][]=new int[r][c];
        int n= arr.length;
        for (int i = 0; i <r; i++) {
            for (int j = 0; j <c; j++) {
                arr[i][j]=s.nextInt();
            }
        }
        for (int i = 0; i <arr.length; i++) {
                arr[i] = new int[n];
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
        }
    }

