package Twodarray;
import java.util.*;
public class Maxof0 {
    public static int maxcol(int arr[][]){
        int row=arr.length;
        int col=arr[0].length;
        int c = 0, max = 0;
        for (int i = 0; i <col; i++) {
            for (int j = 0; j <row; j++) {
                if(arr[i][j]==0){
                    c+=1;
                }
            }
        }
    return max;
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int arr[][] = {{1, 0, 1}, {1, 0, 1}, {1, 0, 1}};
        maxcol(arr);


        int mid = arr.length / 2;
        }

}

