package Twodarray;

import java.util.Arrays;

public class Deloitte {
    public static void main(String[] args) {
        int n=3;
        int[][] arr={{1,2,3},{4,10,5},{10,6,9}};
        System.out.println(Arrays.toString(arr));
    }
}
