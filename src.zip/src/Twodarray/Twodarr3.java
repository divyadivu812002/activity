package Twodarray;

public class Twodarr3 {
    public static void array(int arr[][]){
        for (int i = 0; i <arr.length; i++) {
            for (int j = 0; j <arr[0].length; j++) {
                arr[i][j]=2*i+j;
            }
        }
    }
    public static void main(String[] args) {
        int arr[][]=new int[2][2];
        array(arr);

        for (int i = 0; i <2; i++) {
            for (int j = 0; j <2; j++) {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
    }
}
