package Twodarray;

public class Sudokooptimized {
    public static final int GRIDSIZE =9;

    public static void main(String[] args) {
        int[][] board={
                {7,0,2,0,5,0,6,0,0},
                {0,0,0,0,0,3,0,0,0},
                {1,0,0,0,0,9,5,0,0},
                {8,0,0,0,0,0,0,9,0},
                {0,9,0,0,0,0,0,0,8},
                {0,0,0,0,0,0,0,0,0},
                {0,0,9,7,0,0,0,0,5},
                {0,0,0,2,0,0,0,0,0},
                {0,0,7,0,4,0,2,0,3}

        };
        if(solve(board)){
            System.out.println("Solved Successfully");
        }
        else {
            System.out.println("Not solved");
        }
        printboard(board);
    }
    public static void printboard(int[][] board){
        for (int i = 0; i <GRIDSIZE ; i++) {
            for (int j = 0; j <GRIDSIZE ; j++) {
                System.out.print(board[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static boolean rowcheck(int[][] board,int num,int row){
        for (int i=0;i< GRIDSIZE;i++){
            if(board[row][i]==num){
                return true;
            }
        }
        return false;
    }
    public static boolean colcheck(int[][] board,int num,int col){
        for (int i = 0; i < GRIDSIZE; i++) {
            if (board[i][col]==num){
                return true;
            }
        }
        return false;
    }
    public static boolean gridcheck(int[][] board,int num,int row,int col){
        int locrow=row-row%3;
        int loccol=col-col%3;
        for (int i = locrow; i <locrow+3; i++) {
            for (int j = loccol; j <loccol+3; j++) {
                if(board[i][j]==num){
                    return true;
                }
            }
        }
        return false;
    }
    public static boolean isvalid(int[][] board,int num,int row,int col){
        return !rowcheck(board,num,row)&&
                !colcheck(board,num,col)&&
                !gridcheck(board,num,row,col);
    }
    public static boolean solve(int[][] board){
        for (int row = 0; row < GRIDSIZE; row++) {
            for (int col = 0; col < GRIDSIZE ; col++) {
                if (board[row][col]==0){
                    for (int num = 1; num <=GRIDSIZE ; num++) {
                        if (isvalid(board,num,row,col)){
                            board[row][col]=num;
                            if(solve(board)){
                                return true;
                            }
                            else {
                                board[row][col]=0;
                            }
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }
}
