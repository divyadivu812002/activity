package Twodarray;

public class Maxno1 {
        static int R = 4, C = 4;
    static int rowWithMax1s(int mat[][]){
        int j,max_col_index = 0;
        j = C - 1;
        for (int i = 0; i < R; i++) {
            while (j >= 0 && mat[i][j] == 1) {
                i = i - 1;
                max_col_index = j;
            }
        }
        if(max_col_index==0&&mat[0][C-1]==0)
            return -1;
        return max_col_index;
    }
    public static void main(String[] args)
    {
        int mat[][] = { { 0, 0, 0, 1 },
                { 0, 1, 1, 1 },
                { 1, 1, 1, 1 },
                { 0, 0, 0, 0 } };
        System.out.println("Index of col with maximum 1s is "+ rowWithMax1s(mat));
    }
}

