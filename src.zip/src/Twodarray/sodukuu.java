package Twodarray;

import java.util.Scanner;

public class sodukuu {

    static void sudoku(int[][] arr){
        Scanner s=new Scanner(System.in);
        int i=s.nextInt();
        int j=s.nextInt();
        if(arr[i][j]==0){

            int value =s.nextInt();
            for(int k=0;k<arr.length;k++){
                if(value==arr[k][j] || value==arr[i][k]){
                    // t=false;
                    System.out.println("wrong value for"+i+" "+j);
                    System.out.println("enter the new value:");
                    value=s.nextInt();
                    break;
                }
            }
            if((i>=0 && 3>i)&&(j>0 && 3>j)){
                for(int q=i;q<3;q++){
                    for(int w=j;w<3;w++){
                        if(arr[q][w]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }}
            }
            if((i>=3 && 6>i)&&(j>0 && 3>j)){
                for(int e=i;e<6;e++){
                    for(int r=j;r<3;r++){
                        if(arr[e][r]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }
                }
            }
            if((i>=6 && 9>i)&&(j>0 && 3>j)){
                for(int b=i;b<9;b++){
                    for(int y=j;y<3;y++){
                        if(arr[b][y]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }
                }
            }
            if((i>=0 && 3>i)&&(j>=3 && 6>j)){
                for(int o=i;o<3;o++){
                    for(int p=j;p<6;p++){
                        if(arr[o][p]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }
                }
            }
            if((i>=3 && 6>i)&&(j>=3 && 6>j)){
                for(int a=i;a<6;a++){
                    for(int d=j;d<6;d++){
                        if(arr[a][d]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }
                }
            }
            if((i>=6 && 9>i)&&(j>=3&& 6>j)){
                for(int f=i;f<9;f++){
                    for(int g=j;g<6;g++){
                        if(arr[f][g]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }
                }
            }
            if((i>=0 && 3>i)&&(j>=6 && 9>j)){
                for(int h=i;h<3;h++){
                    for(int l=j;l<9;l++){
                        if(arr[h][l]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }}
            }
            if((i>=3 && 6>i)&&(j>=6 && 9>j)){
                for(int n=i;n<6;n++){
                    for(int x=j;x<9;x++){
                        if(arr[n][x]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }}
            }
            if((i>=6 && 9>i)&&(j>=6 && 9>j)){
                for(int c=i;c<9;c++){
                    for(int v=j;v<9;v++){
                        if(arr[c][v]==value){
                            System.out.println("wrong value for"+i+" "+j);
                            System.out.println("enter the new value:");
                            value=s.nextInt();
                            break;
                        }
                    }}
            }

            arr[i][j]=value;
            print(arr);
            for(int ei =0;ei<arr.length; ei++){
                for(int rr=0;rr<arr.length;rr++){
                    if(arr[ei][rr]==0){
                        sudoku(arr)  ;
                    }
                }
            }
        }
    }
    public static void main(String[]args){
//Scanner s=new Scanner(System.in);
//int n=9;
//int arr[][]=new int [n][n];
        int[][] arr={{7,9,8,3,4,1,0,0,5},{5,0,4,0,8,0,9,0,1},
                {1,0,0,0,5,9,0,7,0},{6,1,5,4,2,0,0,9,9},
                {0,7,0,0,9,0,0,6,0},{0,8,0,0,6,7,5,4,2},{0,5,0,9,3,0,0,0,6},{8,0,0,0,7,0,3,0,0},{3,0,0,1,0,8,2,5,9}};
        int n=arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print("|" + arr[i][j]+"| ");
            }
            System.out.println();
        }
        sudoku(arr);
    }
    static void print(int[][] arr){
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                System.out.print("|" +arr[i][j]+"| ");
            }
            System.out.println();
        }
    }
}