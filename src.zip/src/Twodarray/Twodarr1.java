package Twodarray;
import java.util.*;
public class Twodarr1 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int r = s.nextInt();
        int c = r;
        int arr[][] = new int[r][c];
        int n = arr.length;
        //System.out.println(n);
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                if (arr[0][1]<=1) {
                    System.out.print("X");
                }
            }
            System.out.println();
        }
    }
}

