package Twodarray;

import java.util.Scanner;

public class Boundaries {

    public static void main (String[]args){
        Scanner s = new Scanner(System.in);
        int m = s.nextInt();
        int n = s.nextInt();
        int arr[][] = new int[m][n];
//        for (int i = 0; i < n; i++) {
//            for (int j = 0; j < n; j++) {
//                arr[i][j] = s.nextInt();
//            }
//        }
        char c='X';
        char ch='O';
        int mi= arr.length/2+1;
        //System.out.println(mi);
        for (int i = 0; i <m; i++) {
            for (int j = 0; j <n; j++) {
                //int ld=j%2;
                if (i == 0) {
                    // c=c+arr[i][j];
                    System.out.print(c);
                }
                else if (i==m-1){
                    System.out.print(c);
                } else if (j==0) {
                    System.out.print(c);
                } else if (j==n-1) {
                    System.out.print(c);
                } else if (i==n/2 && j==n/2) {
                    System.out.print(c);
                }
                else if ((i+j)==(arr.length-1)) {
                    System.out.print(c);
                }
//                else if (i==j) {
//                    System.out.print(c);
//                }
                else {
                    System.out.print(ch);
                }
            }
                System.out.println();
        }
    }
}

