package Twodarray;

import java.util.Scanner;

public class Sudoku {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        final int n = 3;
        int[][] arr = new int[n][n];
        assign(arr,n);
    }
    static void assign(int[][]arr,int n){
        Scanner s=new Scanner(System.in);
        //int[][] c={};
        for (int i=0;i< n;i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] == 0) {
                    int t = s.nextInt();
                    boolean a = true;
                    int l=0;
                    for (int k = 0; k < n; k++) {
                        a = true;
                        l=0;
                        if (t == arr[k][j] || t == arr[i][k]) {
                            a= false;
                            l=10;
                            System.out.println("worng"+t+" "+arr[k][j]+" "+arr[i][k]+" ");
                            break;
                        }

                        }
                    if (l!=10) {

                        arr[i][j] = t;
                    }
                }
            }
        }
            for (int i=0;i< n;i++){
                for (int j=0;j<n;j++){
                    System.out.print(arr[i][j]+" ");
                    }
                System.out.println();
                }
      //  return c[0];
        }
    }

