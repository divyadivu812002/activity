package Twodarray;
import java.util.Scanner;
public class Waveform {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int m = s.nextInt();
        int n = s.nextInt();
        int arr[][] = new int[m][n];
        int row=arr.length;
        int col=arr[0].length;
        for (int i = 0; i <row; i++) {
            for (int j = 0; j <col; j++) {
                arr[i][j]=s.nextInt();
            }
        }
        for (int i = 0; i <col; i++) {
            if(i%2==0){
                for (int j = 0; j <row; j++) {
                    System.out.print(arr[i][j]+" ");
                }
            } else {
                for (int j =row-1; j >=0; j--) {
                    System.out.print(arr[i][j]+" ");
                }
            }
        }
    }
}
