package Twodarray;
import java.util.*;
public class more2dd {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        int m = s.nextInt();
        int n = s.nextInt();
        int arr[][] = new int[m][n];
        int l=arr.length;
        for (int i = 0; i <arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                arr[i][j]=s.nextInt();
            }
        }
        int rowsum=0,colsum=0;
        for (int i = 0; i <l; i++) {
            rowsum += arr[l / 2][i];
        }
        System.out.println("Middle Row sum"+rowsum);
        for (int i = 0; i <l; i++) {
            colsum = colsum + arr[i][l / 2];
        }
        System.out.println("Middle Col sum"+colsum);
    }
}
