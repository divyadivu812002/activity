package Twodarray;
import java.util.*;
public class Twodarr2 {
    public static int largest(int a[][]) {
        int rows = a.length;
        int cols = a[0].length;
        int large = 0;
        for (int i = 0; i < cols; i++) {
            int sumcol = 1;
            for (int j = 0; j < rows; j++) {
                sumcol = sumcol + a[i][j];
                if (sumcol > large) {
                    large = sumcol;
                }
            }
        }
        return large;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int m=s.nextInt();
        int n=s.nextInt();
        int a[][]=new int[m][n];
        for (int i=0;i<n;i++) {
            for (int j=0;j<n;j++) {
                a[i][j]=s.nextInt();
            }
        }
            System.out.println("Sum of largest col is: " +largest(a));
    }
}

