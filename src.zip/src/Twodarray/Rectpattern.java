package Twodarray;

public class Rectpattern {
    public static void main(String[] args) {
     //   int n=5;
        int c1=2;
        int c2=2;
        int[][]n=new int[5][5];

    }
}
