package Queue;

import java.util.Stack;

public class Node {
    int data;
    Node next;

    public Node(int element){
        this.data=element;
        this.next=null;
    }
}

class Methods{
    Node front;
    Node rear;
    int capacity;
    int size;

    public Methods(int data){
        this.front=null;
        this.rear=null;
        this.capacity=data;
        this.size=0;
    }

    void enQueue(int data){
        if(size==capacity){
            System.out.println("Queue is Overflow");
            return;
        }
        Node temp=new Node(data);
        if(front==null){
            front=temp;
            rear=temp;
        }
        else{
            rear.next=temp;
            rear=rear.next;
        }
        size++;
    }
    int deQueue(){
        if(front==null){
            return -1;
        }
        else {
            int value = front.data;
            front=front.next;

            if(front==null){
                rear=null;
            }
            size--;
            return value;

        }
    }

    void print(){
        if(front.next==null){
            System.out.println(front.data);
        }
        else{
            Node cur=front;
            while (cur!=null){
                System.out.print(cur.data+" ");
                cur=cur.next;
            }
            System.out.println();
        }
    }
}

class QueueLL{
    public static void main(String[] args) {
        Methods queue1 = new Methods(5);
        queue1.enQueue(10);
        queue1.enQueue(20);
        queue1.enQueue(30);
        queue1.enQueue(40);
        queue1.print();
        Stack<Integer> st=new Stack<>();
        while (queue1.size>0) {
            int temp = queue1.deQueue();
            st.push(temp);
        }
        while (st.size()>0){
            queue1.enQueue(st.pop());
        }
        queue1.print();

//        System.out.println(queue1.front.data+" "+queue1.rear.data);
//        System.out.println(queue1.front.data);
//        System.out.println(queue1.rear.data);
//        queue1.enQueue(20);
//        queue1.enQueue(30);
//        queue1.enQueue(40);
//        queue1.enQueue(30);
//        System.out.println(queue1.deQueue());
//        System.out.println(queue1.deQueue());
//        System.out.println(queue1.deQueue());
//        System.out.println(queue1.rear);
//        System.out.println(queue1.front);
//        System.out.println(queue1.rear);
//        System.out.println(queue1.deQueue());

    }
}
