package Queue;

import java.util.LinkedList;
import java.util.Queue;

public class MaxSub {
    public static void main(String[] args) {
        int[] arr={12,10,9,15,20,10,8};
        int n=arr.length;
        int k=3;
        Queue<Integer> qu=new LinkedList<>();
        for(int i=0;i<n;i++){

        }
    }
}
