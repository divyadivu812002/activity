package Queue;

class Queue{
    int[] arr;
    int front;
    int rear;
    int size;
    int capacity;

    public Queue(int capacity){
        this.capacity=capacity;
        this.arr=new int[capacity];
        this.front=0;
        this.rear=-1;
        this.size=0;
    }

    void enQueue(int n){
        if(size==capacity){
            System.out.println("Queue is full");
        }
        else{
            rear=(rear+1)%capacity;
            arr[rear]=n;
            size++;
        }
    }
    int deQueue(){
        if(size==0){
            System.out.println("Queue is empty");
            return -1;
        }
        else {
            int t=arr[front];
            front=(front+1)%capacity;
            size--;
            return t;
        }
    }

}
public class Main {
    public static void main(String[] args) {
        Queue queue = new Queue(3);
        queue.enQueue(10);
        queue.enQueue(20);
        queue.enQueue(30);
        System.out.println(queue.deQueue());
        queue.enQueue(40);
    }
}
