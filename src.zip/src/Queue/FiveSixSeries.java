package Queue;

import java.util.LinkedList;
import java.util.Queue;

public class FiveSixSeries {
    public static void main(String[] args) {
        int n=12;
        Queue<String> qu=new LinkedList<>();
        qu.add("5");
        qu.add("6");
        for(int i=0;i<n;i++){
            String temp=qu.poll();
            System.out.print(temp+" ");
            qu.add(temp+"5");
            qu.add(temp+"6");
        }
    }
}
