package Integer;

public class Armstrong {
    public static void main(String[] args) {
        int a=1634;
        float f=1;
        System.out.println(f);
        int input=a;
        int c=0,sum=0;
        while (input!=0){
            input=input/10; //163,16,1,0
            c++;            //1 2 3 4
          //  System.out.print(input+" ");//163,16,1 0
        }
        //System.out.println();
        input=a;
        //System.out.println(input);
        while (input!=0){
            int rem=input%10;
            System.out.print(rem+" ");
            sum+=Math.pow(rem,c);
            input=input/10;
        }
       // System.out.println(sum);

    }
}
