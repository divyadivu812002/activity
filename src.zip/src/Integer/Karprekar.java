package Integer;

public class Karprekar {
    static boolean karprekar(int n){
        int res=n,c=0;
        res=n*n;
        System.out.println(res);
        while (res!=0){
            c++;
            res=res/10;
        }
        System.out.println(c);
        res=n*n;
        for (int i = 1; i <c ; i++) {
            int mid=(int) Math.pow(10,i);
            System.out.println(mid+" ");
//            if(mid==n)
//                continue;
            int sum=res/mid+res%mid;
            System.out.println("..."+sum+" ");
          //  System.out.println();
            if(sum==n) {
                System.out.println(sum);
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        int n=298;
        //System.out.println(2025/10 +" "+ 2025%10 );
        if (karprekar(n))
            System.out.println('1');
        else
            System.out.println('0');
    }

}
