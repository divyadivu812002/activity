package Integer;

public class Coins {
    public static int coin(int n){
        int a=0;
        for (int i = 0; i <n; i++) {
            for (int j = 0; j <i+1 ; j++) {
                System.out.print('*');
                //c++;
                n--;
            }
            System.out.println();
            a++;
        }
        //System.out.println();
        return a;
    }
    public static void main(String[] args) {
        int n=8;
        int count=coin(n);
        System.out.println(count);
    }
}
