package Integer;

public class Number {
    public static void main(String[] args) {
        int num = 12356;
        int sum = 0;
        boolean b = true;
        while (b) {
            int rem = num % 10;
            num = num / 10;
            sum += rem;
        if (num == 0) {
            if (sum <=9)
                b = false;
            num = sum;
            sum = 0;
        }
    }
        System.out.println(num);
    }
}
