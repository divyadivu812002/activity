package Integer;

public class Inttodig {
//    public static boolean happy(int temp) {
//        int sum = 0;
//
//        while (temp > 0) {
//            int d = temp % 10;
//
//            temp = temp / 10;
//            sum += d * d;
//            //temp=sum;
//            System.out.print(sum + " ");
//        }
//            while (sum != 1 && sum != 4) {
//                happy(temp);
//
//
//        }
//            if (temp==1) {
//
//                return true;
//            }
//            else {
//                return false;
//            }
//
//
////        return temp;
//    }
public static boolean happy(int N) {
    do {
        N = HappyNumber(N);
    } while (N != 1 && N != 4);

    if (N == 1) {
        return true;
    }
    return false;
}
    static int HappyNumber(int N) {

        int sum = 0;
        while (N > 0) {         //123
            int Rem = N % 10;   //3
            N /= 10;           //
            sum =sum+ (Rem * Rem);
        }
        return sum;
    }
    public static void main(String[] args) {
        int a = 19;
       // int temp = a;
        if( happy(a)==true)
            System.out.println("yes");
        else
            System.out.println("no");

        //System.out.print(temp);


        }
    }


