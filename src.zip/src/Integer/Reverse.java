package Integer;

public class Reverse {
    public static int reverse(int x) {

        int rev = 0;
        while (x != 0) {
            int rem = x % 10;
            rev = rev * 10 + rem;
            x = x / 10;
            System.out.print(rev);

        }
     return rev;
    }
    public static void main(String[] args) {
        int a= -121;
        int v=reverse(a);
        if (v==a)
        System.out.println("Palindrome");
        else
            System.out.println("Not palindrome");
    }
}