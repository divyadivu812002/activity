package Integer;

public class Primeornot {
    public static boolean prime(int n){
        for (int i = 2; i <n-1; i++) {
            if(n%i==0){
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        int n=2;
        System.out.println(prime(n));
//        System.out.println((char)'a'+1);
    }
}
