package Integer;
import java.util.Scanner;
public class Primefrom1ton {
    public static void prime(int m, int n){
        int flg;
        for (int x= 2; x <=n; x++) {
            if(n<=1) {
                System.out.println("Not Possible");
                return;
            }
            flg=1;
            for (int y=2;y<=x/2;y++){
                if(x%y==0) {
                    flg = 0;
                    break;
                }
            }
            if (flg==1) {
                System.out.print(x + " ");
//                c++;
//                System.out.println(c);
            }
        }
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int m=s.nextInt();
        int n=s.nextInt();
        prime(m,n);
    }
}
