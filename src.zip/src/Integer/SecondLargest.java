package Integer;

import java.util.Scanner;

public class SecondLargest {
    public static int secondLargest(int[] arr){
//        int p=Math.max(arr[0],arr[1]),vp=Math.min(arr[0],arr[1]);
       int p,vp;
       if(arr[0]>arr[1]){
           p=arr[0];
           vp=arr[1];
       }
       else {
           vp=arr[0];
           p=arr[1];
       }
        System.out.println(p+" "+vp);
       for(int i=2;i<arr.length;i++) {
            if(arr[i]>p){
                vp=p;
                p=arr[i];
            }
            else if(arr[i]>vp && arr[i]!=p){
                vp=arr[i];
            }
        }
        return vp==p ? -1 : vp;
//        return vp;
    }

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int[] arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=s.nextInt();
        }
        int result=secondLargest(arr);
        System.out.println(result);

    }
}
