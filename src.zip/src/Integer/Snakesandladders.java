package Integer;

import java.util.Scanner;

public class Snakesandladders {
    static void start(int[][] arr,int a){
        Scanner s=new Scanner(System.in);
        int b=0;
        if(a==1) {
            System.out.println("You started the game: ");
            move(arr, a,b);
        }

       // while (b!=1) {
            System.out.println("Enter b: ");
            b = s.nextInt();
        if (b==1) {
            System.out.println("You stated the game");
            move(arr,a,b);
        }
        //}
        System.out.println("Enter a: ");
            a=s.nextInt();
            if(a!=1)
            start(arr,a);
            if(b!=1)
                start(arr,b);
    }
    static void move(int[][] arr,int a,int b) {
        Scanner s = new Scanner(System.in);
       // if (a == 1) {
            int sum_a = a,sum_b=b;
        //System.out.println("check"+a+" "+b);
            while (sum_a != 36) {
                System.out.println("Enter a: ");
                a = s.nextInt();
                System.out.println("Enter b: ");
                b = s.nextInt();
                sum_a = sum_a + a;
                sum_b = sum_b + b;
                System.out.println("Current a=" + sum_a);
                System.out.println("Current b=" + sum_b);
                snakes(arr, a,b);
                ladders(arr, a,b);
        if(a==36)
            System.out.println("Congratulations A wins");
        if(b==36)
            System.out.println("Congratulations B wins");
        //if (a!=36 || b!=36)
              //  move(arr, a,b);
//        for (int i = 0; i <arr.length; i++) {
//            for (int j = 0; j < arr.length; j++) {

//                    arr[i][j]=a;
//                    arr[i][j]=b;
//            }
//        }
            }
        }
        static void snakes(int[][] arr,int a,int b){
        if(a==19) {
            a = 17;
            System.out.println("You step on snake you go to "+a);
        }
        if(b==19)
            b=17;
        if(a==35)
            a=26;
            if(b==35)
                b=26;
    }
    static void ladders(int[][] arr,int a,int b){
        if(a==5)
            a=15;
        if(b==5)
            b=15;
        if(a==23)
            a=32;
        if(b==23)
            b=32;
    }
    static void print(int[][] arr,int a,int b){
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length ; j++) {
                if(a==1)
                System.out.println(a);
                if(b==1)
                    System.out.println(b);
            }
        }
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        //System.out.println("Enter board size: ");
        int size=6;
        int[][] arr=new int[size][size];
//        for (int i = 0; i <size ; i++) {
//            for (int j = 0; j < size; j++) {
//                arr[i][j]=s.nextInt();
//            }
//        }
        System.out.println("Who to start 1 or 2");
        int st=s.nextInt();
        int a=0;
        if(st==1) {
            System.out.println("Enter a :");
            a = s.nextInt();
            start(arr,a);
        }
        else
            start(arr,a);
    }
}
