package Functions;
import java.util.*;
public class Divide {
    public static int fah(int a,int b,int c) {
        for (int i = a; i<=b; i+=c) {
            int cel = ((i - 32)*5 / 9) ;
            System.out.println(i + " " + cel);
        }
        return 0;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int s=sc.nextInt();
        int e=sc.nextInt();
        int a=sc.nextInt();
        int res=fah(s,e,a);
    }
}
