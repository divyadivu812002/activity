package Functions;
import java.util.*;
public class Fun1 {
    public static void even(int n,int m){
        if(n%2!=0) {
            n++;
        }
        int a=0;
        for (int i = n; i <=m; i+=2) {
            System.out.println(i);


//            if (n % 2 == 0) {
//
//                System.out.println(a);
//                a += 2;
//            }
        }

    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int m=s.nextInt();
        even(n,m);


    }
}
