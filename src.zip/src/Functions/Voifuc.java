package Functions;
import java.lang.reflect.Array;
import java.util.*;
public class Voifuc {
    public static void main(String[] args) {
//        int a=0;
//        //int res=
//           double div=(5/9);
//           int div1=(a-32);
//        System.out.println(div);
//        System.out.println(div1);
        int arr[]={11,23,43,24,67};
        //int array=0;
//        Arrays.sort(Array,Collections.reverseOrder());
        for(int value:arr){
            System.out.print(value);
        }

    }

}
