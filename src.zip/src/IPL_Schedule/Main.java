package IPL_Schedule;
import java.util.*;
//import java.util.Scanner;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;

public class Main {
    static List<Teams> teams = new ArrayList<>();
    public static void main(String[] args) {
       // Scanner s=new Scanner(System.in);
        Schedule schedule=new Schedule();
        schedule.addteam();
        //schedule.getdate();
//        for (int i = 0; i <10; i++) {
//            System.out.println(first_match_date.plusDays(i));
        schedule.printmatch();
    }
}
