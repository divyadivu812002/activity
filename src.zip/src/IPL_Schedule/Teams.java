package IPL_Schedule;

import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class Teams {


     int team_NO;

     String name;
     String homeground;
    public Teams(String name){ //consider as match class
        this.name=name;
        //this.homeground=homeground;
        //this.team_NO=tmpt;
    }
//    public String getName(){
//        return name;
//    }
//    public String getHomeground(){
//        return homeground;
//    }

}
