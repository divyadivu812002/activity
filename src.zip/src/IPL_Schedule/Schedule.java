package IPL_Schedule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Schedule {
   static int tmpt;
    LocalDate date;
//   static List<Integer> homematch=new ArrayList<>();
//   static List<Integer> awaymatch=new ArrayList<>();
    Scanner s = new Scanner(System.in);
    List<Teams> teams=new ArrayList<>();

    List<Match> teamlist=new ArrayList<>();
    public void addteam() {


        System.out.println("Enter total number of teams :");
        int team_NO = s.nextInt();
        //tmpt=((team_NO-1)*2);

        for (int i = 1; i <= team_NO; i++) {
            System.out.println("Enter the "+ i +" st name");
            teams.add(new Teams(s.next()));
        }
        int row;
        if(team_NO%2==0){
            row=2*(team_NO-1);
        }
        else {
            row=team_NO*2;
        }

        getdate();
        for (int i = 0; i <row; i++) {
            for (int j = 0,k=team_NO-1; j <team_NO/2; j++,k--) {
                teamlist.add(new Match(teams.get(j).name,teams.get(k).name,date));
                date=date.plusDays(1);
            }
            String  temp=teams.get(0).name;
            teams.remove(0);
            teams.add(new Teams(temp));
        }
       // System.out.println("Total number of matches are "+team_NO*tmpt);
//        for (Teams element:teams) {
//            System.out.println(element.name+" "+element.homeground+" "+element.team_NO);
//        }
    }
     public void getdate(){
        System.out.println("Enter the starting date of IPL");
        String input_date=s.next();
         DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
         date=LocalDate.parse(input_date,formatter);
    }
    public void printmatch(){
        int k=1;
        for (Match element:teamlist) {
            System.out.println("Match NO. "+k++ +" --> "+element.team1+" vs "+element.team2+" on "+element.date);
        }
    }
}
