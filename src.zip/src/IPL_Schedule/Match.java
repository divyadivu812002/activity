package IPL_Schedule;

import java.time.LocalDate;

public class Match {
    String team1;
    String team2;
    LocalDate date;

    //    String homeground;
    public Match(String name1, String name2, LocalDate date) { //consider as match class
        this.team1 = name1;
        this.team2 = name2;
        this.date = date;
    }
}
