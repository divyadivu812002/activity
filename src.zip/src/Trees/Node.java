package Trees;

import java.util.LinkedList;
import java.util.Queue;

public class Node {
    int data;
    Node left;
    Node right;

    public Node(int data){
        this.data=data;
        this.left=null;
        this.right=null;
    }
}

class Methods{
    int size;
    public Methods(){
        this.size=0;
    }
    void inorder(Node root){
        if(root!=null){
            inorder(root.left);
            System.out.print(root.data+" ");
            inorder(root.right);
        }
    }
    void preOrder(Node root){
        if(root!=null){
            System.out.print(root.data+" ");
            preOrder(root.left);
            preOrder(root.right);
        }
    }
    void postOrder(Node root){
        if(root!=null){
            postOrder(root.left);
            postOrder(root.right);
            System.out.print(root.data+" ");
        }
    }
    int height(Node root){
        if(root==null){
            return 0;
        }
        else{
            int lh=height(root.left);
            int rh=height(root.right);
            return Math.max(lh, rh)+1;
        }

    }
    void printfromK(Node root,int k){
        if(root!=null){
            if(k==0){
                System.out.print(root.data+" ");
            }
            else{
                printfromK(root.left,k-1);
                printfromK(root.right,k-1);
            }
        }
    }
    void levelOrder(Node root){
        Queue<Node> qu=new LinkedList<>();
        if(root!=null) {
            qu.add(root);
            while (qu.size() > 0) {
                Node cur=qu.poll();
                System.out.print(cur.data+" ");
                size++;
                if(cur.left!=null)
                    qu.add(cur.left);
                if(cur.right!=null)
                    qu.add(cur.right);
            }
        }
        System.out.println();
        System.out.print(size);
    }
    void levelOrderRight(Node root){
        Queue<Node> qu=new LinkedList<>();
        if(root!=null){
            qu.add(root);
            while (qu.size()>0){
                Node cur=qu.poll();
                System.out.print(cur.data+" ");
                if(cur.right!=null){
                    qu.add(cur.right);
                }
                if(cur.left!=null){
                    qu.add(cur.left);
                }
            }
        }
    }

}
class Main{
    public static void main(String[] args) {
        Node root=null;
        root=new Node(10);
        root.left=new Node(20);
        root.right=new Node(30);
        root.left.left=new Node(40);
        root.right.left=new Node(50);
        root.right.right=new Node(60);

        Methods tree=new Methods();
        tree.inorder(root);
        System.out.println();
        tree.preOrder(root);
        System.out.println();
        tree.postOrder(root);
        System.out.println();
        System.out.println(tree.height(root));
        tree.printfromK(root,2);
        System.out.println();
        tree.levelOrder(root);
        System.out.println();
        tree.levelOrderRight(root);
    }
}
