package Empyra;
import java.time.*;
public class Expires {
    public static void main(String[] args) {
        String str="2024-10-10";
        int n=60;
        LocalDate date=LocalDate.parse(str);
        LocalDate finalDate=date.plusDays(n);
        if(finalDate.isAfter(LocalDate.now())){
            System.out.println("Not expired "+finalDate);
        }
        else {
            System.out.println("Expired "+finalDate);
        }
    }
}
