package Pattern;

public class Hollow_Triangle {
    public static void main(String[] args) {
        int n=5;
        for(int i=1;i<=n;i++){
            for (int k=1;k<=n-i;k++){
                System.out.print(" ");
            }
            for(int j=0;j<i;j++){
                if(i==1 || i==n || j==i-1 || j==0) {
                    System.out.print(j+1+" ");
                }
                else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
