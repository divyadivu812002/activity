package Pattern;
import java.util.Scanner;

public class Mirrorpattern3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int i = 1;
        while (i <= n) {
            int sp=1;
            while (sp <= 2 * n - 2 * i) {
                System.out.print(" ");
                sp+=1;
            }
            int st=1;
            int temp=i;
            while (st<=i){
                System.out.print(temp);
                st+=1;
                temp+=1;
            }
            int z=2*i-2;
            while (z>i-1){
                System.out.print(z);
                z-=1;
            }
            System.out.println();
            i += 1;
        }
    }
}



