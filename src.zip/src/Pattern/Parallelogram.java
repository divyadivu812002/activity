package Pattern;
import java.util.*;
public class Parallelogram {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int i=1,j=1;
        int h=0;
        while (i<n){
             h=i;
            while (1<=h-1){
                System.out.print(" ");
                h--;
            }
            j=1;
            while (j<=n){
                System.out.print("*");
                j++;
            }
            System.out.println();
            i++;
        }
    }
}
