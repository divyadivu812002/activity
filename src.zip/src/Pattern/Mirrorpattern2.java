package Pattern;
import java.util.Scanner;

public class Mirrorpattern2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int i = 1;
        int n1 = n / 2 + 1;
        while (i <= n1) {
            int sp = 1;
            while (sp <= n1 - i) {
                System.out.print(" ");
                sp = sp + 1;
            }
            int st = 1;
            int c=1;
            while (st <=2 * i - 1) {
                System.out.print(c);
                st = st + 1;
                c+=1;
            }
            System.out.println();
            i = i + 1;
        }
       int n2=n/2;
        i=n2;
        while (i>=1) {
            int sp = 1;
            while (sp <= n2 - i+1) {
                System.out.print(" ");
                sp+=1;
            }
            int j=1;
            while (j<=2*i-1){
                System.out.print(j);
                j+=1;

            }
            i-=1;
            System.out.println();
        }
    }
}




