package Pattern;
import java.util.*;
public class Pattern6 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int i = 1;
        while (i <=n) {
            int b=n;
            int j = 1;
            while (j <=n-i+1) {
                System.out.print(b);
                j += 1;

            }

//            b -=1;
            System.out.println();
            i += 1;

        }
    }
}
