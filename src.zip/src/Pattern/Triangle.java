package Pattern;

import java.util.Scanner;

public class Triangle {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str=s.next();
        int n=str.length();
        char[] arr=str.toCharArray();
        for(int i=0;i<str.length();i++) {
            for (int j = 0; j < str.length(); j++) {
                if (i == j) {
                    System.out.print(arr[i]);
                } else if (i + j == str.length() - 1) {
                    System.out.print(arr[n - 1 - i]);
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
