package Pattern;

public class Sum_natural {
    public static void main(String[] args) {
        int n=5;
        for (int i=1;i<=n;i++){
            int sum=i*(i+1)/2;
            for(int j=0;j<i;j++){
                System.out.print(sum--+" ");
            }
            System.out.println();
        }
    }
}
