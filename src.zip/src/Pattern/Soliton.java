package Pattern;

import java.util.Scanner;

public class Soliton {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int m=s.nextInt();
        int i,l=0;
        int k=0;
        int r=n,c=m;
        char arr[][]=new char[m][n];
        char x='X';
        while(k<m&&l<n){
            for ( i = 1; i <n; i++) {
                arr[k][i] = x;
            }
            for(i = k; i <m ;i ++) {
                arr[i][n-1]=x;
                n-=1;
            }
            if(k<m){
                for (i =n-1; i>=l ;--i) {
                    arr[m-1][i]=x;
                    m-=1;
                }
            if(l<n){
                    for (i =m-1;i>=k ;--i) {
                       arr[i][l]=x;
                       l++;

                    }
                }
            }
            x=(x=='O')?'X':'O';

        }
        for (i = 0; i <r ;i ++) {
            for (int j = 0; j < c; j++) {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();

        }


    }
}
