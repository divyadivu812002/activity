
package Pattern;

import java.util.Scanner;


public class Pattern2 {
    public static void main(String[] args) {


        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        String a = "";
        int i = 1;
        while (i <=n) {
            a +="*";
            System.out.println(a);
            i+=1;
        }
        System.out.println();
    }
}






