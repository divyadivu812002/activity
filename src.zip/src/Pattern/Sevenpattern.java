package Pattern;
import java.util.Scanner;

public class Sevenpattern {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int i = 1;
        int k=n/2+1;
        int c=0;
        while (i <= k) {
            k=n/2+1;
            int j=1;
            while (j <= k) {
                System.out.print(n);
                j = j + 1;
            }
            c+=1;
            System.out.println();
            i = i + 1;
        }
    }
}



