package Pattern;
import java.util.Scanner;

public class Mirrorpattern1 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int i = 1;
        char c=(char)('A');
        while (i <= n) {
            int  sp=1;
            while (sp <= n-i) {
                System.out.print(' ');
                sp = sp + 1;
            }
            int st=1;
            while(st<=i){
            System.out.print(c);
            c=(char)(c+1);
            st=st+1;
        }
            System.out.println();
            i=i+1;
    }
    }
}



