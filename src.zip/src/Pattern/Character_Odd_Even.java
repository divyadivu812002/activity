package Pattern;
public class Character_Odd_Even {
    public static void main(String[] args) {
        int n=5;
        char ch='A';
        for(int i=1;i<=n;i++){
            char chRev=(char)(ch+i-1);
            if(i%2==0) {
                for (int j = 0; j < i; j++) {
                    System.out.print(chRev--+" ");
                    ch++;
                }
            }
            else{
                for (int j=0;j<i;j++){
                    System.out.print(ch+++" ");
                }
            }
            System.out.println();
        }
    }
}