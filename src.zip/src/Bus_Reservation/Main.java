package Bus_Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner s=new Scanner(System.in);
        List<Buses> buses=new ArrayList<>();
        SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
        buses.add(new Buses(1,1,dateFormat.parse("19-03-2024")));
        buses.add(new Buses(1,1,dateFormat.parse("09-03-2024")));
        List<Passenger> passenger=new ArrayList<>();
        int input=1;
        while(input ==1){
            System.out.print("What you like to choose 1 for book and 2 for exit");
            input=s.nextInt();
            if(input==1){
                System.out.println("Enter name,gender,busNO and date_of_travelling(dd-MM-yyyy) of the passenger: ");
                Passenger ref=new Passenger(s.next(),s.next().charAt(0),s.nextInt(),dateFormat.parse(s.next()));
                passenger.add(ref);
                Booking booking=new Booking();
                booking.isavailable(buses,ref);
            }
        }
    }
}
