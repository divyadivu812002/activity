package Bus_Reservation;

import java.util.Date;

public class Passenger {
     String name;
   char gender;
    int bus_no;
    Date date;
    public Passenger(String name,char gender,int bus_no,Date date){
        this.name=name;
        this.gender=gender;
        this.bus_no=bus_no;
        this.date=date;
    }


}
