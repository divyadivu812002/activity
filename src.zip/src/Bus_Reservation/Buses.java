package Bus_Reservation;

import java.util.Date;

public class Buses {
     int bus_no;
     int seat;
     int seat_filled=0;
     Date date;
    public Buses(int bus_no,int seat,Date date){
        this.bus_no=bus_no;
        this.seat=seat;
        this.date=date;
        this.seat_filled++;
    }
    public Buses() {

    }

    public boolean isavail(int capacity, Date date,Date bus_date){
        if(seat_filled<capacity && bus_date.equals(date)){
            return true;
        }
        else
            return false;
    }
}
