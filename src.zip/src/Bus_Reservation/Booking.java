package Bus_Reservation;
import java.util.*;
public class Booking {
   public void isavailable(List<Buses> buses,Passenger ob){
        int capacity=0;
       int booked=0;
       Buses bus=new Buses();

       for (Buses buse:buses) {
           if (buse.bus_no == ob.bus_no) {
               capacity = buse.seat;
               System.out.println(buse.seat);
           }
               if(bus.isavail(capacity,ob.date,buse.date)) {
                   ++booked;
                   buse.seat--;
                   System.out.println("Booked on "+ ob.date);
                   return;
               }
       }
       System.out.println("Not booked");
       }
   }
