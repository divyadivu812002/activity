package Recursion;

public class Num_Digits {
    static int numofdigits(int n){
        if(n<=9)
            return 1;
        int small_ans=numofdigits(n/10);
        int res=small_ans+1;
        return res;
    }
    public static void main(String[] args) {
        System.out.println(numofdigits(0));
     //   int n=12345;
//        int length = (int) (Math.log10(n) + 1);
//        System.out.println(length);
    }
}
