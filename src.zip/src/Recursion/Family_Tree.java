package Recursion;

public class Family_Tree {
    static char family(char root,int k,int n){
        if(k==1)
            return root;
        int num_child=(int)Math.pow(2,k-1);
        if(n<=num_child/2)
            return family(root,k-1,n);
        else {
            char new_root='m';
            if(root=='m') {
                new_root = 'f';
            }
                return family(new_root, k - 1, n - num_child / 2);
        }
    }
    public static void main(String[] args) {
        char root='m';
        int n=5,k=5;
        System.out.println(family( root,n,k));
    }
}
