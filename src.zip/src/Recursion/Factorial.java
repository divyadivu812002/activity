package Recursion;

public class Factorial {
    public static int factorial(int n){
        if(n==0)
            return 1;
        else {
            int small=factorial(n-1);
            int ans=n*small;
            return ans;
        }
    }
    public static void main(String[] args) {
        int fact=factorial(5);
        System.out.println(fact);
    }
}
