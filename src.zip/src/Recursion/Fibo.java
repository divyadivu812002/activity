package Recursion;

public class Fibo {
    static int i=0,j=1,s=0;
    static void fibo(int n){
        if(n>0){
            s=i+j;
            i=j;
            j=s;
            System.out.print(" "+s);
            fibo(n-1);
        }
    }
    public static void main(String[] args) {
        int n=6;
        System.out.print(i+" "+j);
        fibo(n-2);
    }
}
