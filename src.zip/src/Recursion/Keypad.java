package Recursion;

public class Keypad {
    static String getoptions(int n){
        if(n==2)
            return "abc";
        if(n==3)
            return "def";
        if(n==4)
            return "ghi";
        if(n==5)
            return "jkl";
        if(n==6)
            return "mno";
        if(n==7)
            return "pqrs";
        if(n==8)
            return "tuv";
        return "wxyz";

    }
    static String[] keypad(int n){
        if(n==0){
            String[] output=new String[1];
            output[0]=" ";
            return output;
        }
        int last=n%10;
        int rem=n/10;
        String[] small=keypad(rem);
        String lastdigit=getoptions(last);
        String[] output=new String[small.length*lastdigit.length()];
        int k=0;
        for (int i = 0; i<lastdigit.length() ; i++) {
            for (int j = 0; j <small.length; j++) {
                output[k++]=small[j]+lastdigit.charAt(i);
            }
        }
        return output;
    }
    public static void main(String[] args) {
        String[] str=keypad(23);
        for (int i = 0; i <str.length; i++) {
            System.out.println(str[i]);
        }
    }
}
