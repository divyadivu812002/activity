package Recursion;

public class Tower_Of_Hanoi {
    static void tower(int n,char source, char destination ,char helper) {
        if (n == 1){
            System.out.println("move 1st disk form " + source + " to " + destination);
        return;
    }
        tower(n-1,source,helper,destination);
        System.out.println("move "+n+" th disk from "+source+" to "+destination);
        tower(n-1,helper,destination,source);
    }
    public static void main(String[] args) {
        int n=3;
        tower(n,'a','c','b');
    }
}
