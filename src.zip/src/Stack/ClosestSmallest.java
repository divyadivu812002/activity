package Stack;

import java.util.Stack;

public class ClosestSmallest {
    public static void main(String[] args) {
        int[] arr={4,4,4,4,5};
        int n=arr.length;
        Stack<Integer> st=new Stack<>();
        for(int i=0;i<n;){
            if(st.isEmpty()) {
                System.out.print(-1 + " ");
                st.push(arr[i]);
                i++;
            } else if (st.peek()<arr[i]) {
                System.out.print(st.peek()+" ");
                st.push(arr[i]);
                i++;
            } else if (st.peek()>=arr[i]) {
                st.pop();
            }
        }
        }
    }
