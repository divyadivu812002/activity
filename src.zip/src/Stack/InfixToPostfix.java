package Stack;

import java.util.Stack;

public class InfixToPostfix {
    public static void main(String[] args) {
        String str="a+b*(c-d)/e";
        Stack <Character> st=new Stack<>();
        char[] arr=str.toCharArray();
        int n=arr.length;
        for(int i=0;i<n;i++){
            if(arr[i]>='a' && arr[i]<='z'){
                System.out.print(arr[i]);
            } else if (arr[i]=='(') {
                st.push(arr[i]);
            } else if (arr[i]==')') {
                while (st.size()>0 && st.peek()!='('){
                    System.out.print(st.pop());
                }
                st.pop();
            }
            else if(arr[i]=='+' || arr[i]=='-' || arr[i]=='*' || arr[i]=='/'){
                if(st.isEmpty()){
                    st.push(arr[i]);
                }
                else{
                    if(st.size()>0 && prec(arr[i])>prec(st.peek())){
                        st.push(arr[i]);
                    }
                    else{
                        while (st.size()>0 && prec(arr[i])<=prec(st.peek())){
                            System.out.print(st.pop());
                        }
                        st.push(arr[i]);
                    }
                }
            }
        }
        while (st.size()>0){
            System.out.print(st.pop());
        }
    }

    private static int prec(char ch) {
        if(ch=='^'){
            return 3;
        } else if (ch=='*' || ch=='/') {
            return 2;
        } else if (ch=='+' || ch=='-') {
            return 1;
        }
        return  0;
    }
}
