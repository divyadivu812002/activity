package Strings;

import java.util.Arrays;

public class Swap_words {
        public static void main(String[] args) {
            // Input string
            String input = "Humbird Ai Technology Private Limited";

            // Split the input string into an array of words
            String[] wordsArray = input.split(" ");

            // Sort the array of words alphabetically using a bubble sort
            for (int i = 0; i < wordsArray.length - 1; i++) {
                for (int j = 0; j < wordsArray.length - i - 1; j++) {
                    if (wordsArray[j].compareTo(wordsArray[j + 1]) > 0) {
                        // Swap words if they are in the wrong order
                        String temp = wordsArray[j];
                        wordsArray[j] = wordsArray[j + 1];
                        wordsArray[j + 1] = temp;
                    }
                }
            }

            // Create a new string by joining the sorted words
            String sortedByWord = String.join(" ", wordsArray);

            // Print the result
            System.out.println("Input: " + input);
            System.out.println("Output: " + sortedByWord);
        }
    }


//        public static void main(String[] args) {
//            // Input string
//            String input = "Humbird Ai Technology Private Limited";
//
//            // Convert the input string to a char array
//            char[] charArray = input.toCharArray();
//
//            // Sort the char array alphabetically
//         //   Arrays.sort(charArray);
//
//            // Convert the sorted char array back to a string
//            String sortedByCharacter = new String(charArray);
//
//            // Split the string into an array of words
//            String[] wordsArray = sortedByCharacter.split(" ");
//
//            // Sort the array of words alphabetically
//            Arrays.sort(wordsArray);
//
//            // Create a new string by joining the sorted words
//            String sortedByWord = String.join(" ", wordsArray);
//
//            // Print the result
//            System.out.println("Input: " + input);
//            System.out.println("Output: " + sortedByWord);
//        }
//    }


//    public static void main(String[] args) {
//        String s="Humbrid Ai Technology Limited";
//        int n=s.length(),count=0;
//        char[] arr=new char[n];
//        //System.out.println(Arrays.toString(arr));
//        for (int i = 0; i <arr.length; i++) {
//            if(arr[i]==' '){
//                count+=1;
//                arr[i]=s.charAt(i);
//            }
//            System.out.println(Arrays.toString(arr));
//        }





