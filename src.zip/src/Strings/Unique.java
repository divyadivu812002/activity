//package Strings;
//import java.util.*;
//public class Unique {
//   // class Main{
//        public class void main(String[] args){
//            Scanner s=new Scanner (System.in);
//           // int arr[]=newInt(Session);
//            System.out.println("4");
//        }
//    }
//}
