package Strings;
import java.util.*;
public class Compare {
    public static void main(String[] args) {
        String[] str1 = {"axc", "gowtham", "sanjay"};
//        for (int i = 0; i < str1.length; i++) {
//        }
        for (int i = 0; i < str1.length; i++) {
            for (int j = 0; j < str1.length-1; j++) {
                if (str1[j].compareTo(str1[j +1])>0) {
                    String temp=str1[j];
                    str1[j]=str1[j+1];
                    str1[j+1]=temp;
                }
            }
        }
        for (int i = 0; i <str1.length; i++) {
            System.out.println(str1[i]);
        }
    }
}

