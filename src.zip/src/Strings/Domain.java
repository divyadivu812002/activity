package Strings;

import java.util.Arrays;

public class Domain {
    public static void main(String[] args) {
        String[] arr={"https:/www.google.com","https:/www.example.com","https:/www.google.com","https:/www.tapacademy.com","http:/www.example.com"};
        String[] str=new String[arr.length];
        for(int i=0;i<arr.length;i++){
            str[i]= Arrays.toString(arr[i].split("."));
        }
    }
}
