package Strings;
import java.util.*;
import java.lang.*;
public class String1 {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str1=s.nextLine();
        String rev="";
        int n=str1.length();
        for (int i =n-1; i>=0; --i) {
            rev=rev+str1.charAt(i);
        }
        if(str1.equals(rev)){
            System.out.println(str1 +" is a palindrome");
        }
        else {
            System.out.println(str1+" is not a palindrome");
        }
        }
}
