package Strings;

public class Reference {
    public static void main(String[] args) {
        String str1="hello";
        //String str2="hello";
        String str3=new String("hello");
        if(str1.equals(str3)){
            System.out.println("equal");
        }
        else {
            System.out.println("unequal");
        }
    }
}
