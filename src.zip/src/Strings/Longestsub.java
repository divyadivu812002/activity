package Strings;

public class Longestsub {
    public static String palindrome(String s) {
        int n = s.length();
//        char[] f=new char[n];
        String f="";
        int r = 0, l = 0;
        for (int i = 0; i < n; i++) {
            int count = 0;
            if(s.charAt(i) != s.charAt(n- 1 - i)) {
                for (int j = i + 1; j < n; j++)
                    if (s.charAt(i) == s.charAt(j)) {
                        r = i;
                        l = j;
                        System.out.println(r);
                        System.out.println(l);
                        count++;
                    }

                if (count != 0)
                    break;
            }
        }
            for (int i = r; i <= l; i++) {
                f+=s.charAt(i);
            }
            return f;
        }
        public static void main(String[] args){
            String s ="aacabdkacaa";
            System.out.println(palindrome(s));


        }
    }




