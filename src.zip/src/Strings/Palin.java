package Strings;

import java.util.*;

public class Palin {
    public static void main(String[] args) {
        String s="BA3C55ED";
        int n=s.length();
        String str="";
        String num="";
        int sum=0;
        for (int i = 0; i <n ; i++) {
            char c=s.charAt(i);
            if(c<='9' && c>='0')
                num=num+c;
            if(c<='Z' && c>='A')
                str=str+c;
        }
        System.out.println(str);
        System.out.println(num);
        int arr=Integer.parseInt(num);
        String s1=Integer.toString(arr);
        //System.out.println(arr+" "+num);
        while (arr!=0){
            int rem=arr%10;
            sum+=rem;
            arr=arr/10;
        }
        System.out.println(sum);
        char[] ch=str.toCharArray();
        Arrays.sort(ch);
        str=String.valueOf(ch);
        System.out.println(str+sum);

    }
}
