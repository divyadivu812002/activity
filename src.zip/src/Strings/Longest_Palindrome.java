package Strings;

public class Longest_Palindrome {
    public static boolean palindrome(String str){
        String check="";
        for(int i=str.length()-1;i>=0;i--){
            check=check+str.charAt(i);
        }
        //System.out.println(check);
        if(str.equals(check))
            return true;
        return false;
    }
    public static void main(String[] args) {
        String str="abcbsmadams";//"grtmadamdf";
        int n=str.length();
        String max="";
        for(int i=1;i<=n;i++){
            for(int j=0;j<=n-i;j++){
                String temp="";
                int check=j+i-1;
                for(int k=j;k<=check;k++){
                    temp=temp+str.charAt(k);
                }
                if(palindrome(temp)){
                if(temp.length()>max.length()) {
                    max = temp;
                }
                }
            }
        }
        System.out.println(max);
    }
}
