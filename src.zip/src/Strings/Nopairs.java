package Strings;
import java.util.*;
public class Nopairs {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] arr = new String[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.next();
        }

        for (int i = 0; i < n; i++) {
            int count = 0;
            String str = arr[i];
            int j, k;
            char[] arrs = str.toCharArray();
            for (j = 0, k = j + 1; k < arrs.length; ) {
                if (arrs[j] == arrs[k]) {
                    k++;
                    count++;
                } else if (arrs[j] != arrs[k]) {
                    k++;
                    j++;
                }
            }
            System.out.println(count);
        }
    }
}
