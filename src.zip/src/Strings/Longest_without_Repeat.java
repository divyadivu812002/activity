package Strings;

public class Longest_without_Repeat {
    public static void main(String[] args) {
        String str="aabaaaac";
        int i,j,max=1,count=1;
        for(i=0,j=i+1;i<str.length()-1;){
            if(str.charAt(i)==str.charAt(j)){
                max++;
                j++;
            }
            else {
                i=j;
                j++;
                max=1;
            }
            if(count<max)
                count=max;
        }
        System.out.println(count);
    }
}
