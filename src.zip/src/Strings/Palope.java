package Strings;

import java.util.Arrays;

public class Palope {
    public static void main(String[] args) {
        String str="AB+C*D";
        int n=str.length();
        char[] ch=str.toCharArray();
        int j=0;
        for (int i = 0; i <n; i++) {
           // for (int k = i+1; k <n; k++) {
                if(str.charAt(i)>='A' && str.charAt(i)<='Z'){
                    swap(ch,i,n-1-j);
                    j++;
                    System.out.print(Arrays.toString(ch));
                }
            }
     //   }
    }
    static void swap(char[] str,int n,int j){
        char temp=str[n];
        str[n]=str[j];
        str[j]=temp;
    }
}
