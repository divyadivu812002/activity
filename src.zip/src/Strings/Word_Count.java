package Strings;

public class Word_Count {
    public static void main(String[] args) {
        String str="Hello Hello";
        String[] arr=str.split(" ");
        for (int i=0;i<arr.length;i++){
            int count=1;
            for(int j=i;j<arr.length;j++){
                if (arr[i]=="0") {
                    count=0;
                    continue;

                }
                else if(i==j ) {
                    count = 0;
                    continue;
                }
                 else if (arr[i].equals(arr[j])) {
                    count++;
                    arr[j]="0";
                }
            }
            if(count!=0) {
                System.out.println(arr[i] + " " + count);
            }
        }
    }
}
