package Strings;

public class Valid_Palin {
    public static void main(String[] args) {
        String s="0P";
        s=s.toLowerCase();
        String str="";
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)<='z'&&s.charAt(i)>='a'||s.charAt(i)>='0' &&s.charAt(i)<='9') {
                str += s.charAt(i);
            }
        }
        System.out.println(str);
        String str2="";
        for (int i = str.length()-1; i>=0 ; i--) {
            str2+=str.charAt(i);
        }
        System.out.println(str2);

    }
    }

