package Strings;
import java.util.Locale;
public class Vowelcount {
    static void printPermutn(int c,String str, String ans)
    {
        if (str.length() == 0) {
            System.out.print(ans + " ");
            return;
        }
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            String ros = str.substring(0, i) +
                    str.substring(i + 1);
            c++;
            printPermutn(c, ros, ans + ch);
        }
    }
    public static void main(String[] args)
    {
        String s = "MMLMLLM";
        int c=0;
        printPermutn(c,s, "");
    }
}
//    public static void main(String[] args) {
//        String str="Sanjay22";
//        int vcount=0,ccount=0;
//        str=str.toLowerCase();
//        for (int i = 0; i <str.length() ; i++) {
//            if (str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u'){
//                vcount+=1;
//            } else if (str.charAt(i)>='a'&&str.charAt(i)<='z') {
//                ccount+=1;
//            }
//        }
//        System.out.println("vowels count:"+vcount);
//        System.out.println("consonents count:"+ccount);
//    }
