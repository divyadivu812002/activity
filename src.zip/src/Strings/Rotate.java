package Strings;
public class Rotate {
    public static void main(String[] args) {
        String str="kyoto";
        int n=str.length();
        char[] arr=str.toCharArray();
        for (int i = 0; i <n ; i++) {
            System.out.print(arr[(i+n-2)%n]);
        }
    }
}

