package Strings;

import java.util.Arrays;

public class Palwords {
    public static void main(String[] args) {
        String str="Was it a car or a cat I saw";//was it a car or cat I saw
        String res= "";
        int k=0;
        int n=str.length();
        String fi="";
        System.out.println(n);
        char[] rev=new char[str.length()];
        for (int i = n-1; i>=0; i--) {
            res=  res+str.charAt(i);
            if (str.charAt(i)!=' ')
                rev[k++]=str.charAt(i);
        }
        System.out.println(k);
        int c=0;
        for (int i = 0; i <n; i++) {
            if(str.charAt(i)!=' '){
                fi+=rev[c++];
            }
            else if (str.charAt(i)==' '){
                fi=fi+' ';
            }
        }
        fi=fi.toLowerCase();
        fi=fi.substring(0,1).toUpperCase()+str.substring(1);
        System.out.println(fi);
    }
}
