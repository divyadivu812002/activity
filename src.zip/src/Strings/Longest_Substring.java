package Strings;

import java.util.HashMap;

public class Longest_Substring {
    static void longest(String str){
        HashMap<Character,Integer> map=new HashMap<>();
        String res="";
        int max=0;
        for (int right=0,left=0;right<str.length();right++){
            char cur=str.charAt(right);
            if(res.length()<=right)
                res+=str.charAt(right);
            if(map.containsKey(cur) && map.get(cur)>=left){
                left= map.get(cur)+1;
                res="";
            }
            max=Math.max(max,right-left+1);
            map.put(cur,right);
        }
        System.out.println(max);
        System.out.println(res);
    }
    public static void main(String[] args) {
        String str="ababccdef";
//        System.out.println(longest(str));
        longest(str);
    }
}
