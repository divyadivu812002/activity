package Strings;

import java.util.Arrays;

public class Rotate_Words {
    public static void main(String[] args) {
        String str="welcome to zoho association";
        String[] arr=str.split(" ");
        System.out.println(Arrays.toString(arr));
        System.out.println(arr[0].compareTo(arr[1]));
//        for (int i = 0; i <arr.length; i++) {
//            for (int j = i+1; j <arr.length; j++) {
//                String temp=arr[i];
//                arr[i]=arr[j];
//                arr[j]=temp;
//            }
//        }
//        System.out.println(Arrays.toString(arr));
        for (int i = 0; i <arr.length-1; i++) {
            for (int j = 0; j <arr.length-1-i ; j++) {
//                System.out.println(arr[i] + " 1" + arr[j]);
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    String temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(arr));
        System.out.println(arr[0].compareTo(arr[1]));
    }
}
