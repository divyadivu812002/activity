package Strings;

import java.util.Scanner;

public class Occrtry {
    public static void occur(String str){
        int n=str.length();
        int arr[]=new int[26];
        for (int i = 0; i <n; i++) {
            arr[str.charAt(i)-'a']++;
        }
        for (int i = 0; i <n; i++) {
            if(arr[str.charAt(i)-'a']!=0){
                System.out.print(str.charAt(i));
                System.out.print(arr[str.charAt(i)-'a']+" ");
                arr[str.charAt(i)-'a']=0;
            }
        }
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str=s.nextLine();
        occur(str);
    }
}
