package Strings;

public class reverse {
    public static void main(String args[]){
        String a="vikaash";
        String rev="";
        for(int i=0;i<a.length();i++){
            rev=a.charAt(i)+rev;
        }
        System.out.println(rev);
    }
}
