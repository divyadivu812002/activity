package Strings;

public class Repeated_String {
    public static void main(String[] args) {
        String str="aaabc";
        int n=3;
        int count=0;
        for(int i=0;i<str.length();i++){
            if(str.charAt(i)=='a'){
                count++;
            }
        }
        int flg=1;
        if(n>str.length()) {
            flg=0;
            int quo = n / str.length();
            int rem = n % str.length();
            int full = quo * count;
            int part = 0;
            for (int i = 0; i < rem; i++) {
                if (str.charAt(i) == 'a') {
                    part++;
                }
            }
            System.out.println(full + part);
        }
        if(flg==1){
            System.out.println(count);
        }
    }
}
