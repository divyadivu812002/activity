package Strings;

public class Occurence {
    public static void main(String[] args) {
        String str="sanjay";
        int n=str.length();
        int count[]=new int[256];
        for (int i = 0; i <n; i++) {
            count[str.charAt(i)]++;
            for (int j=i+1;j<n;j++)
                if (str.charAt(i) == str.charAt(j))
                    continue;
            System.out.print(count[str.charAt(i)] + " ");

        }
//        char ch[]=new char[n];
//        for (int i = 0; i <n; i++) {
//            ch[i]=str.charAt(i);
//            int find=0;
//            for (int j = 0; j <i; j++) {
//                if(str.charAt(i)==ch[j])
//                    find++;
//            }
//            if(find==1)
//                System.out.println(count[str.charAt(i)]);
//        }
    }
}
