package Strings;
import java.util.*;

public class Spliting {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str="PPPPP@PPP@PP$PP";
        str = str.replace("@", " ");
        str = str.replace("$", " ");
        System.out.println(str);
        String arr[] = str.split(" ");
        //System.out.println(str);
        int max = 0;
        for(int i = 0; i < arr.length; i++) {

            max = Math.max(max, arr[i].length());
           // System.out.println(arr[i+1].length());


            System.out.println(max + 1);
            break;
        }

    }
}
