package Strings;
import java.util.*;
public class Brackets {
    public static boolean brackets(String str){
        int i=-1;
        char[] c=new char[str.length()];
        for (char ch:str.toCharArray()) {
            if(ch=='(' || ch=='{' ||ch=='['){
                c[++i]=ch;
            }
            else {
                if(i>=0 && ((c[i]=='(' && ch==')')
                        ||(c[i]=='[' && ch==']')
                        || (c[i]=='{' && ch=='}')))
                    i--;
                else
                    return false;
            }
        }
        return i==-1;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str="";
        str=s.next();
        if(brackets(str))
            System.out.println("Balanced");
        else
            System.out.println("Not Balanced");
    }
}
