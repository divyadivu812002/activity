package Strings;

public class Panagram {
    public static void main(String[] args) {
        String str = "abccdefghijklmnop qrst uvwxyzzzzfjdsfneoerfnor";
        int n = str.length();
        String fin = "";
        for (int i = 0; i < n; i++) {
            int j;
            for (j = 0; j < i; j++) {
                if (str.charAt(i) == str.charAt(j)) {
                    break;
                }
            }
            if(str.charAt(i)==(' '))
                continue;
            if (j == i) {
                fin=fin+str.charAt(i);
            }
        }
        System.out.println(fin);
        System.out.println(fin.length());
    }
}
