package Strings;

public class Substring {
    public static void longestpal(String str){
        int n=str.length();

    }
    public static void main(String[] args) {
        String str = "sanjay";
        int n = str.length();
        longestpal(str);
        for (int i = 0; i < n; i++) {
            System.out.println(str.charAt(i));
        }
        for (int i = 0; i < 1; i++) {
           // System.out.println(str.charAt(i));
            for (int j = i+1; j < n; j++) {
                for (int k = i; k <= j; k++) {
                    System.out.print(str.charAt(k));
                }
                System.out.println();
            }
        }
    }
}

