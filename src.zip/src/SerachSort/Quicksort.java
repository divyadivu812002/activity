package SerachSort;

import java.util.Arrays;

public class Quicksort {
    static void swap(int[] a,int i,int j){
        int temp=a[i];
         a[i]=a[j];
         a[j]=temp;
    }
    public static void quick(int[] arr,int low,int high) {
        if (low < high) {
            int pivot = arr[low];
            // int high=n-1;
            int i = low, j = high;
            while (i < j) {
                i += 1;
                while (i <= high && arr[i] < pivot)
                    i++;
                while (j >= low && arr[j] > pivot)
                    j--;
                if (i < j && i <= high)
                    swap(arr, i, j);
            }
            swap(arr, low, j);
            quick(arr, low, j - 1);
            quick(arr, j + 1, high);
        }
    }
    public static void main(String[] args) {
        int[] arr={5,4,2,7,1};
        int n=arr.length-1;
        quick(arr,0,n);
        System.out.println(Arrays.toString(arr));
    }
}
