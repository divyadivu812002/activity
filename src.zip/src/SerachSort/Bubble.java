package SerachSort;
import java.util.Scanner;

public class Bubble {
    private static void swap(int[] arr,int j){
        int temp=arr[j];
        arr[j]=arr[j+1];
        arr[j+1]=temp;
    }
    static int ascending_Swap(int[] arr,int n){
        int count=0;
        for (int i = 0; i <n-1; i++) {
            for (int j = 0; j <n-i-1; j++) {
                if(arr[j]>arr[j+1]){
                    swap(arr,j);
                    count++;
                }
            }
        }
        return count;
    }
    static int descending_Swap(int[] arr,int n){
        int count=0;
        for (int i = 0; i <n-1; i++) {
            for (int j = 0; j <n-i-1; j++) {
                if(arr[j]<arr[j+1]){
                    swap(arr,j);
                    count++;
                }
            }
        }
        return count;
    }
    public static void print_Res(int asc,int dsc){
        if(asc<dsc)
            System.out.println(asc);
        else
            System.out.println(dsc);
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int[] arr=new int[n];
        for (int i=0;i<n;i++){
            arr[i]=s.nextInt();
        }
        int[] arr1=new int[n];
        for (int i = 0; i <n; i++) {
            arr1[i]=arr[i];
        }
            int asc = ascending_Swap(arr, n);
            int dsc = descending_Swap(arr1, n);
            print_Res(asc, dsc);
    }
}
