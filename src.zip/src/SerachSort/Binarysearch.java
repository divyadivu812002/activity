package SerachSort;
public class Binarysearch {
     static int binary(int[] arr,int s){
       // Arrays.sort(arr);
        int n=arr.length;
        int low=0, high=n-1;
        while (low<=high){
            int mid=low+(high-low)/2;
        if(arr[mid]==s)
            return mid;
        else if (arr[mid]<s) {
            low=mid+1;
        }
        else
            high=mid-1;
        }
    return -1;
    }
    public static void main(String[] args) {
        int[] arr={1,2,3,4,5,7};
        int s=7;
        int res=binary(arr,s);
        if(res==-1)
            System.out.println("Not present");
        else
            System.out.println(res);
    }
}
