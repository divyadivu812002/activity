package SerachSort;
public class Binary {
    public static int Binarysearch(String[] arr,String t) {
        int l = 0, h = arr.length - 1;
        //System.out.println(h);
        while (l <= h) {
            int mid = (l + h) / 2;
            int res=t.compareTo(arr[mid]);
           // System.out.println(mid);
            if (res == 0)
                return mid;
            else if (res >0)
                h = mid - 1;
            else if (res <0)
                l = mid + 1;
        }
        return -1;
    }
    public static void main(String[] args) {
        String arr[]={"T","T","T","T","T"};
        String target="F";
        int res=Binarysearch(arr,target);
        if(res==-1)
            System.out.println("Not present");
        else
            System.out.println(res);
    }
}
