package LinkedList;

import java.util.Scanner;

 class Node<T> {
    T data;
    Node next;

    Node(T data) {
        this.data = data;
    }
//public static Node createlinekdlist(){
//        Node n1=new Node(5);
//        Node n2=new Node(6);
//        Node n3=new Node(7);
//        Node n4=new Node(8);
//        n1.next=n2;
//        n2.next=n3;
//        n3.next=n4;
//        //n4.next=NULL;
//        return n1;
//}
static  void display(Node head){
        Node temp=head;
        while(temp!=null){
         //   temp.data++;
            System.out.print(temp.data);
            temp=temp.next;
        }
    System.out.println();
}
static  int length(Node head){
        int count=0;
        Node temp=head;
        while (temp!=null){
            count++;
            temp=temp.next;
        }
        return count;
}
static void ith(Node head){
        int pos=1;
    Scanner s=new Scanner(System.in);
    int i=s.nextInt();
    Node temp=head;
    while (pos<i){
        temp=temp.next;
        pos++;
    }
    System.out.println(temp.data);

}
static Node delete(Node head){
        Node temp=head,prev=head;
        Scanner s=new Scanner(System.in);
        int pos=s.nextInt();
        for(int i=0;i<pos;i++){
            if(pos==1){
                head=head.next;
            }
            else{
                if(i==pos-1){
                    prev.next= temp.next;
                }
                else {
                    prev=temp;

                }
            }
        }
    //Node temp=head;
        head.next=head.next;
        return head;
    }
    static Node insertion(Node head){
        Node newnode=new Node(15);
        int pos=1,curpos=0;
        Node temp=head;
        while (curpos<(pos-1)){
            temp=temp.next;
            curpos++;
        }
        if(temp==null)
            return head;
        newnode.next=temp.next;
        temp.next=newnode;
        return head;
    }
 public static Node insert(){

        Scanner s=new Scanner(System.in);
        int data=s.nextInt();
        Node head=null;

        while (data!=-1){
            Node newnode=new Node(data);
            if(head==null)
                head=newnode;
            else {
                Node temp=head;
                while (temp.next!=null) {
                 //   temp.data = s.nextInt();
                    temp = temp.next;
                }
                temp.next=newnode;
            }
            data=s.nextInt();
        }
        return head;
    }
    public static void main(String[] args) {
        //Node head=createlinekdlist();
        Node head=insert();
        //display(head);
        System.out.println(length(head));
        //ith(head);
      //  delete(head);
        insertion(head);
        display(head);
       // System.out.println(c);
//        System.out.println(head);

       // Node n1=new Node(10);
        //System.out.println(n1.data);
        //System.out.println(n1.next);
    }
}
