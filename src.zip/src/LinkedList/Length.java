package LinkedList;

import java.util.Scanner;

public class Length {
    static Node<Integer> createll(){
        Node<Integer>n1=new Node<>(10);
        Node<Integer>n2=new Node<>(20);
        Node<Integer>n3=new Node<>(30);
        Node<Integer>n4=new Node<>(40);
        n1.next=n2;
        n2.next=n3;
        n3.next=n4;
        return n1;
    }
    static int length(Node <Integer> head){
        int len=0;
        Node <Integer> temp=head;
        while(temp!=null){
            len++;
          //  System.out.print(temp.data+" ");
            temp=temp.next;
        }
        return len;
    }
    static void print(Node <Integer> head){
        Node <Integer> temp=head;
        while(temp!=null){
              System.out.print(temp.data+" ");
            temp=temp.next;
        }
        System.out.println();
    }
    static int getith(Node<Integer> head){
        int i=3;
        int len=0;
        Node <Integer> temp=head;
        while(temp!=null){
            if(i==len){
                return temp.data;
            }
            else {
                len++;
                temp=temp.next;
            }
        }
        return -1;
    }
    static Node<Integer> input(){
        Scanner s=new Scanner(System.in);
        int data=s.nextInt();
        Node<Integer> head=null,tail=null;
        while (data!=-1){
            Node<Integer> currentNode= new Node<>(data);
            if(head==null) {
                head = currentNode;
                tail = currentNode;
            }
            else {
                tail.next=currentNode;
                tail=currentNode;
            }
            data=s.nextInt();
        }
        return head;
    }
    public static Node<Integer> insertion(Node<Integer> head,int pos){
        Scanner s=new Scanner(System.in);
        int currentPosition=0;//data=s.nextInt();
        Node<Integer> newNode= new Node<>(12);
        if(pos==0){
            newNode.next=head;
            head=newNode;
            return head;
        }
        Node<Integer> temp=head;
        while (currentPosition<(pos-1)){
            temp=temp.next;
            currentPosition++;
        }
        if(temp==null) {
            return head;
        }
        newNode.next=temp.next;
        temp.next=newNode;
        return head;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        Node <Integer> head=createll();
        print(head);
//        int len=length(head);
//        System.out.println(len);
//        int ithnode=getith(head);
//        System.out.println(ithnode);
//        Node <Integer> head=input();
//        print(head);
       // int pos=s.nextInt();
        int pos=0;
        head=insertion(head,pos);
        print(head);
    }
}
