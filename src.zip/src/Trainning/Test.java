package Trainning;
import java.util.*;
import java.lang.String;
public class Test {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
//      int arr[] = new int [n];
//      String a = "";
//      int i = 1;
//      while (i < n) {
//         a +="*";
//         System.out.println(a);
//         i+=1;
//        }
//        System.out.println();
//    }
//}
        int i = 1;
        while (i <= n) {
//      int c=n;
            int j=1;
            while (j <= n) {
                System.out.print(n-j+1);
//              c-=1;
                j = j + 1;
            }
            System.out.println();
            i = i + 1;
        }
    }
}



