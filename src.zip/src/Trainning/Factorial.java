package Trainning;
import java.util.*;
public class Factorial {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int a = 1;
        int b = n;
//        for (int i =i; i <=n; i++) {
//            a=a*i;
//        }
//        System.out.println(a);
//    }
        while (b > 0) {
            a = a * b;
            b--;
        }
        System.out.println(a);

        while (a > 0){
            int c;
            c=a%10;
            if(c==1){
                System.out.println("Yes");
                break;
            }
            else if(a/10==0)
                System.out.println("No");
            a=a/10;


        }

    }
}