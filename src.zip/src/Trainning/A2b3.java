package Trainning;
import java.util.*;
public class A2b3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String a = s.nextLine();
        char ch[]=a.toCharArray();
        int tem = (int) ch[1] - 48;
        System.out.println((int)('1'));
//        char ch[] = new char[];
//        for (int i = 0; i < a.length(); i++) {
//            ch[i] =s.next();
//        }
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] >= '0' && ch[i] <= '9') {
                int temp = (int) ch[i] - 48;
                for (int j = 0; j < temp; j++) {
                    System.out.print(ch[i - 1]);
                }
            }
        }
    }
}

