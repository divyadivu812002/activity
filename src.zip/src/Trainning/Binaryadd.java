package Trainning;

import java.util.*;
public class Binaryadd {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String str1=s.nextLine();
        int n=str1.length();
        String str2=s.nextLine();
        int n2=str2.length();
        int arr[]=new int[5];
        int ind=4;
        int carry=0,sum=0;
        for (int i = n-1; i>=0; i--) {
            int a = ((int) str1.charAt(i))- 48;
            int b = ((int) str2.charAt(i)) - 48;
            System.out.println(a+ " "+b);
            sum = a + b + carry;
            carry=sum/2;
            sum=sum%2;
            arr[ind--]=sum;
        }
        System.out.println(Arrays.toString(arr));

    }
}
