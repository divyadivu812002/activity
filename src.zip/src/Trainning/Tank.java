package Trainning;
import java.util.*;
public class Tank {
    public static void main(String[] args) {
        char a[]=new char[5];
        for (int i = 0; i <a.length; i++) {
           // a[0] ='5';
            System.out.println(a[i]);
        }
    }
}
