package DSA;

import java.util.HashSet;
import java.util.LinkedHashSet;

class Node{
    int data;
    Node next;

    Node(int data){
        this.data=data;
        this.next=null;
    }
}

class Methods {
    Node head;

    void printLL() {
        Node cur = head;
        while (cur != null) {
            System.out.print(cur.data + " ");
            cur = cur.next;
        }
        System.out.println();
    }

    Node mergeTwoSortedLists(Node l1,Node l2){
        Node dummy=new Node(0);
        Node cur=dummy;
        while (l1!=null && l2!=null){
            if(l1.data<l2.data){
                cur.next=l1;
                l1=l1.next;
            }
            else{
                cur.next=l2;
                l2=l2.next;
            }
            cur=cur.next;
        }
        if(l1!=null){
            cur.next=l1;
        }
        else{
            cur.next=l2;
        }
        return dummy.next;
    }
    void reversed(){
        Node cur=head;
        Node prev=null;
        Node front=null;
        while (cur!=null) {
            front = cur.next;
            cur.next = prev;
            prev = cur;
            cur = front;
        }
        head=prev;
        printLL();
    }

    void printReverse(Node cur){
        if(cur==null){
            return;
        }
        printReverse(cur.next);
        System.out.print(cur.data+" ");
    }
    void reverse(){
        printReverse(head);
    }


    void add(int data) {
        Node temp = new Node(data);
        if (head == null) {
            head = temp;
        } else {
            Node curr = head;
            while (curr.next != null) {
                curr = curr.next;
            }
            curr.next = temp;
        }
    }

    void addFirst(int data) {
        Node temp = new Node(data);
        if (head == null) {
            head = temp;
        } else {
            temp.next = head;
            head = temp;
        }
    }

    void add(int ind, int data) {
        if (ind == 1) {
            addFirst(data);
        } else {
            Node temp = new Node(data);
            Node cur = head;
            int count = 1;
            while (count < ind - 1) {
                cur = cur.next;
                count++;
            }
            temp.next = cur.next;
            cur.next = temp;
        }
    }

    void addAll(int arr[]) {
        for (int i : arr) {
            add(i);
        }
    }

    void removeFirst() {
        if (head != null) {
            head = head.next;
        }
    }

    void removeLast() {
        if (head == null) {

        } else if (head.next == null) {
            removeFirst();
        } else {
            Node cur = head;
            while (cur.next.next != null) {
                cur = cur.next;
            }
            cur.next = null;
        }
    }

    int indexOf(int data) {
        Node cur = head;
        int ind = 0;
        while (cur != null) {
            if (cur.data == data) {
                return ind;
            }
            cur = cur.next;
            ind++;
        }
        return -1;
    }
    int lastIndexOf(int data){
        Node cur=head;
        int first=0,ind=0;
        while (cur!=null){
            if(cur.data==data){
                if(first<=ind){
                    first=ind;
                }
            }
            cur=cur.next;
            ind++;
        }
        return first;
    }

    int middle(){
        int middle=0;
        Node slow=head,fast=head;
        while (fast!=null && fast.next!=null){
//            middle=slow.data;
            slow=slow.next;
            fast=fast.next.next;
        }
        middle=slow.data;
        return middle;
    }

    void removeDuplicates(){
        HashSet<Integer> hash=new LinkedHashSet<>();
        Node cur=head;
        while (cur!=null){
            if(hash.contains(cur.data)){
                cur=cur.next;
            }
            else {
                hash.add(cur.data);
            }
        }
        System.out.println(hash);
    }
    int findnth(int n){
        int result=0;
        Node cur=head;
        int count=0;
        while (cur!=null){
            cur=cur.next;
            count++;
        }
        int len=count-n;
        System.out.println(count);
        int ind=0;
        cur=head;
        while (ind!=len){
            ind++;
            cur=cur.next;
        }
        result=cur.data;
        return result;
    }
    int findnthEff(int n){
        Node first=head;
        Node second=head;
        for(int i=0;i<n;i++){
            first=first.next;
        }
        while (first!=null){
            first=first.next;
            second=second.next;
        }
        return second.data;
    }
    void reverseupton(int n){
        Node cur=head;
        Node prev=null;
        Node next=null;
        Node start=head;
        int count=0;
        while (count<n){
            next=cur.next;
            cur.next=prev;
            prev=cur;
            cur=next;
            count++;
        }
        if(start!=null){
            start.next=cur;
        }
        head=prev;
    }
}
public class LinkedList1 {
    public static void main(String[] args) {
        Methods l1=new Methods();
        l1.add(10);
        l1.add(20);
        l1.add(30);
//        l1.add(40);
//        l1.add(50);
        Methods l2=new Methods();
        l2.add(5);
        l2.add(15);
        l2.add(17);
        l2.add(25);
//        Node mergedHead = l1.mergeTwoSortedLists(l1.head, l2.head);
//        l1.printLL();
//        l1.add(4,5);
//        int arr[]={1,2,3,4};
//        l1.addAll(arr);
        l1.printLL();
//        l1.removeFirst();
//        l1.printLL();
//        l1.removeLast();
//        l1.printLL();
//        System.out.println(l1.indexOf(10));
//        System.out.println(l1.lastIndexOf(10));
//        l1.reverse();
//        l1.reversenth(3);
//          l1.reversed();
//        System.out.println(l1.middle());
//        l1.removeDuplicates();
//        System.out.println(l1.findnth(1));
//        System.out.println(l1.findnthEff(1));
        l1.reverseupton(2);
        l1.printLL();

    }
}
