package ProblemSolving;
import java.util.*;
public class Rotaterowandcol {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int m = s.nextInt();
        int n = s.nextInt();
        int arr[][] = new int[m][n];
        int i = 0;
        for (i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                arr[i][j] = s.nextInt();
            }
        }
        int a= arr.length;
        int b=arr[0].length;
        for (i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                int temp=b;
                b=a;
                a=temp;
            }
        }
        for (int j = 0; j <n; j++) {
            System.out.println(arr[j]);
        }
    }
}