package ProblemSolving;

public class Rotatearr {
    public static void main (String[] args) {
        int arr[] = { 1, 2, 3, 4, 5};
        int N = arr.length;
        int d = 2;

            int temp[] = new int[N];
            int k = 0;
            for (int i = d; i < N; i++) {
                temp[k] = arr[i];
                k++;
            }
            for (int i = 0; i < d; i++) {
                temp[k] = arr[i];
                k++;
            }
            for (int i = 0; i < N; i++) {
                arr[i] = temp[i];
            }

        for (int i = 0; i < N; i++) {
            System.out.print(arr[i]+" ");
        }
    }
}

