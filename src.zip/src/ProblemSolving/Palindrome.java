package ProblemSolving;
import java.util.*;
public class Palindrome {
    public static void main(String[] args) {
//        Scanner s=new Scanner(System.in);
//        String str=s.nextLine();
        String str="sanjas";
        int n=str.length();
        System.out.println(n);
        for (int i = 0; i <n/2; i++) {
            if (str.charAt(i) != str.charAt(n-1- i)) {
                System.out.println("no");
                break;
            }
            else if(i==(n/2)-1){
                System.out.println("Yes");
            }
//            else {
//                System.out.println("Yes");
//                break;
//            }
        }
    }
}
