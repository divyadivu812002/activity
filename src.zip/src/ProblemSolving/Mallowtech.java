package ProblemSolving;
import java.lang.*;

public class Mallowtech {
    public static void main(String[] args) {
        double n=(9);
        System.out.println(Math.sqrt(n));
         double c;
         c=Math.sqrt(n);
        System.out.println(c);
    }
}
