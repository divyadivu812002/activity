package Arrays;

import java.util.*;
import java.util.Scanner;

public class Max_Sub {
    public static void swap(int[] arr,int i,int ind){
        int temp=arr[ind];
        arr[ind]=arr[i];
        arr[i]=temp;

    }
    public static void main(String[] args) {
//        int[] arr={1,-4,5,2,-6,8};
//        int cur=arr[0],max=arr[0];
//        for(int i=1;i<arr.length;i++){
//            if(cur>arr[i]){
//                cur=max;
//            } else if (cur<max) {
//                cur+=arr[i];
//            }
//
//        }

        int[] arr={5,2,3,1,4,6,7};
        int min=0,max=0,ind=0;
        for(int i=0;i<arr.length;i++){
             min=0;max=0;ind=i;
            for(int j=i;j<arr.length;j++){
                if(i%2==0 ){
                if( arr[j]>max) {
                    max = arr[j];
                    ind = j;
                }
                } else{
                    if (arr[j]<min) {
                        min=arr[j];
                        ind=j;
                    }
                }
            }
            int temp = arr[i];
            arr[i] = arr[ind];
            arr[ind] = temp;
        }
        System.out.println(Arrays.toString(arr));
    }
}
