package Arrays;
import java.util.*;
public class Frequencies {
    static void print(int arr[],int n) {
        for (int i = 0; i < n; i++) {
            arr[i] = arr[i] - 1;
//            System.out.println(arr[i]);
            System.out.print(arr[i]);
        }
        System.out.println();
        System.out.println(n);
        for (int i = 0; i < n; i++) {
            arr[arr[i] % n] = arr[arr[i] % n] + n;
            System.out.print(arr[i] + " ");
       }
        System.out.println();
        for (int i = 0; i < n; i++)
            System.out.println(i + 1 + "->" + arr[i]);
    }
    public static void main(String[] args) {
       // Frequencies count=new Frequencies();
        int arr[]={2,3,2,4,5};
        int n=arr.length;
        print(arr,n);
    }
}
