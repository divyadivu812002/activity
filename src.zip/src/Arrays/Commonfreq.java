package Arrays;

public class Commonfreq {
    public static void main(String[] args) {
        int []arr={5,8,4,4,4};
        int n=arr.length;
        int c=0;
        for (int i = 0; i <n; i++) {
            c=0;
            for (int j=0;j<i+1;j++)
                if(arr[i]==arr[j]){
                    c++;
            }
        }
        for (int i = 0; i <n; i++) {
            System.out.println("Freq of"+arr[i]+"is"+c);

        }

    }
}
