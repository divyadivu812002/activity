package Arrays;

import java.util.Scanner;

public class Moveone {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
//        int n= sc.nextInt();
        int arr[]={1,4,-1,6,-1,9,2,-1};
//        int arr[]=new int[n];
//        for(int i=0;i<n;i++){
//            arr[i]=sc.nextInt();
//        }
        for (int i=0,j=0;j<arr.length;){
            if(arr[j]==-1) {
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
                i++;
                j=i;
            }
            else{
                j++;
            }
        }
        for(int i=0;i< arr.length;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
