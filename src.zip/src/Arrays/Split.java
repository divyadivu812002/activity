package Arrays;

import java.util.Arrays;

public class Split {
    public static void main(String[] args) {
        int[] arr={7,5,7,7,2,2,7,1,9};
        int k=7;
        int count=0,n=arr.length,index=0;
        int[] arr2=new int[n];
        int[] arr3=new int[n];
        for (int i = 0; i <n; i++) {
            //index=0;
            if(arr[i]==k){
                count+=1;
                index=i;
            }
        }
        System.out.println(count+" "+index);
        int split=n-count;
        System.out.println(split);
        for (int i = 0;i<split;i++) {
            arr2[i]=arr[i];
        }
        for (int i =split; i <n ; i++) {
            arr3[i]=arr[i];
        }
        System.out.println(Arrays.toString(arr2));
        System.out.println(Arrays.toString(arr3));
    }
}
