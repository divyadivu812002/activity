package Arrays;

public class Maxmin {
    public static void main(String[] args) {

        int[] arr = {1, 2, 5, 3, 4};
        for (int i =0; i < arr.length;i++){
        }
    }
}
