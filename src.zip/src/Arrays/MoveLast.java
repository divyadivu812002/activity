package Arrays;

import java.util.Scanner;

public class MoveLast {
    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
        int arr[]={0,1,0};
        int i=0;
        for(int j=i;j<arr.length;j++){
            if(arr[j]!=0){
               arr[i]=arr[j];
               i++;
            }
        }
        while (i<arr.length){
            arr[i]=0;
            i++;
        }
        for (int k=0;k<arr.length;k++){
            System.out.print(arr[k]+" ");
        }
    }
}
