package Arrays;

import java.util.Arrays;

public class Inttoarr {
    static int[] Int_to_array(int n)
    {
        int j = 0;
        int len = Integer.toString(n).length();
        int[] arr = new int[len];
        while(n!=0)
        {
            arr[len-j-1] = n%10;
            n=n/10;
            j++;
           // System.out.print(arr[n]);
        }
        return arr;
    }
    public static void main(String[] args) {
      //  int arr[]={3,4,5};
        int n=512;
        int[] arr=(Int_to_array(n));
        System.out.println(Arrays.toString(arr));
    }
}
