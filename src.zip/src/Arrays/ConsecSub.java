package Arrays;
public class ConsecSub {
    public static void main(String[] args) {
        int arr[]={11,12,13,14,2};
        int n=arr.length;
        int count=1;
        int check=0;
        int si=0,ei=0;
        for(int i=0;i<n-1;i++){
            if(arr[i+1]-arr[i]==1){
                count++;
//                System.out.print(arr[i]+" ");
            }
            else {
//                System.out.println(count);
                if(count>check){
                    check=count;
                    ei=i;
                }
                count=1;
            }
        }
//        System.out.print(arr[n-1]);
        if (count>check){
            check=count;
            ei=n-1;
        }
//        System.out.println(check);
        si=ei-check+1;
        for (int i=si;i<=ei;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
