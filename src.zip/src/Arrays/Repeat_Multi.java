package Arrays;

public class Repeat_Multi {
    public static void main(String[] args) {
        int[] arr1={4,5,6};
        int[] arr2={6,5};
//        int j=Math.max(arr1.length,arr2.length);
        int j=arr2.length, i=0;
        for(i=0,j=j-1;i<arr1.length;){
            if(arr1[i]==arr2[j]){
                System.out.print(arr1[i]+" ");
                i++;
                j--;
            } else if (arr1[i]<arr2[j]){
                i++;
            }
            else{
                j--;
            }
        }
    }
}
