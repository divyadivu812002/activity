package Arrays;

import java.util.Arrays;

public class Deleteelem {
    public static void main(String[] args) {
        int[] arr={1,2,3,4,5,3};
        int k=3;
        int n=arr.length,c=0;
        for (int i = 0; i <n; i++) {
            if(arr[i]==k){
                arr[i]=Integer.MAX_VALUE;
                c++;
            }
        }
        Arrays.sort(arr);
      //  System.out.println(c);
        //System.out.println(Arrays.toString(arr));
        for (int i = 0; i <n-c; i++) {
            System.out.print(arr[i]+" ");
        }
    }
}
