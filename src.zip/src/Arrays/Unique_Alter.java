package Arrays;

public class Unique_Alter {
    public static void main(String[] args) {
        int a[]={3,4,1,3,4,1,5,6,-1};
        int n=a.length,g=1,j=0;
        int [] newarr=new int[n];
        for(int i=0;i<n;i++) {
            for (j = i - 1; j >= 0; j--) {
                g=1;
                if (a[i] == a[j]) {
                    g = 0;
                    break;
                }
            }
            if(g==1)
                newarr[i]=a[i];
            System.out.print(newarr[i]+" ");
        }
    }
    }
//        int[] arr={3,4,2,2,3,5,6,1,2,5};
//        int n=arr.length,j;
//        for (int i = 0; i <n; i++) {
//            for (j = i+1; j <n; j++) {
//                if(arr[i]==arr[j])
//                    break;
//            }
//            if(j==n)
//                System.out.println(arr[i]+" "+i);
//        }
//    }

