package Arrays;

public class Largest_Repeating {
    public static void main(String[] args) {
        int[] arr={1,2,2,3,4,4,5};

    }
}
