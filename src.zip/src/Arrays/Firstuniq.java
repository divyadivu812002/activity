package Arrays;

import java.util.Arrays;

public class Firstuniq {
   public static void main(String[] args) {
        int[] arr = {2 ,4 ,6 ,8 ,10 ,2 ,6 ,10};
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        for (int i = 0; i <arr.length-1; i++) {
            if(arr[i]!=arr[i+1])
                System.out.println(arr[i]);
            else
                i++;
        }
        for (int i = 0; i < arr.length; i++) {
            int j;
            for (j = 0; j <arr.length; j++) {
                if(i!=j && arr[i]==arr[j])
                    break;
                }
                if(j== arr.length) {
                    System.out.println(arr[i]);
                }
        }
    }
}
