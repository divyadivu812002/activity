package Arrays;

public class AllSub {
    public static void main(String[] args) {
        int arr[]={-2,-3,4,-1,-2,1,5,-3};
        int n=arr.length;
        int lgsum=Integer.MIN_VALUE;
        int ei=0,si=0,count=0;
        for(int i=n;i>=1;i--) {
            for (int j = 0; j <= n - i; j++) {
                int sum = 0;
                 count=0;
                for (int k = j; k < i + j; k++) {
//                    System.out.print(arr[k]+" ");
                    sum += arr[k];
                    count++;
                }
//                System.out.println(sum);
//                System.out.println();
                if (sum > lgsum) {
                    ei = i+1;
                    si=ei-count+1;
                    lgsum = sum;
                }
            }
        }
        System.out.println("lg"+lgsum+" "+ei+" "+si);
        for (int i=si;i<=ei;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
