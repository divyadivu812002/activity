package Arrays;
import java.util.*;
public class Max {
    public static void main(String[] args) {
        int arr[] = {1,2,4,3};
        int n = arr.length;
        int arr1[]=new int[n];
        for (int i = 0; i <n; i++) {
            arr1[i]=arr[i];
        }
        Arrays.sort(arr1);
        int min = arr1[n-1];
        int lastbefore=arr1[n-2];
        for (int i = 0; i <n; i++) {
            if(arr[i]==min)
                arr[i]=-1;
            else if(arr[i]!=lastbefore)
                arr[i]=min;
        }
        for (int i = 0; i <n ; i++) {
            System.out.print(arr[i]+" ");
        }
        }
}
