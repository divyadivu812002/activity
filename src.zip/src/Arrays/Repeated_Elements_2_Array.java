package Arrays;

import java.util.Scanner;

public class Repeated_Elements_2_Array {
    public static void repeatedelements(int[] arr1,int[] arr2){
        int n=arr1.length;
        int m=arr2.length;
        for(int i=n-1;i>=0;i--){
            int flg=0;
            for(int j=0;j<m;j++){
                if(arr1[i]==arr2[j]){
                    if(arr1[i]!=arr1[i-1]) {
                        System.out.print(arr2[j] + " ");
                        flg=1;
                    }
                } else if (arr1[i]<arr2[j]) {
                    break;
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[] arr1={9,8,7,5,3,3,1};
        int[] arr2={1,2,3,4,5};
        repeatedelements(arr1,arr2);
    }
}
