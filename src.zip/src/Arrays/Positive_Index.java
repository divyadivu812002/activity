package Arrays;
import java.util.Arrays;
public class Positive_Index {
    public static void main(String[] args) {
        int[] arr={-3,9,-8,6,7,8,-9,0};
        int n=arr.length;
        int poc=0;
        for (int i = 0; i <n; i++) {
            if(arr[i]>0)
                poc++;
        }
        System.out.println(poc);
        int[] arr2=new int[poc];
        int mid;
        if (poc%2==0)
             mid=(poc/2)-1;
        else
            mid=poc/2;
        System.out.println(mid);
        int k=0;
        for (int i = 0; i <n ; i++) {
            if(arr[i]>0){
                arr2[k]=arr[i];
                k++;
            }
        }
        System.out.println(Arrays.toString(arr2));
        System.out.println(arr2[mid]);
    }
}
