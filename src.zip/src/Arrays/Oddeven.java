package Arrays;

public class Oddeven {
    public static void main(String[] args) {
        int []arr={1,2,3,4,5,6};
        int n=arr.length,k=0;
        int arr1[]=new int[n];
        for (int i = 0; i <n; i++) {
            if (arr[i] % 2 == 0) {
                arr1[i] = arr[i];
                k++;
            }
        }
        for (int i = k; i <n; i++) {
            arr1[i]=arr[i];
            k++;
        }
        for (int i:arr1)
            System.out.print(i);
    }
}
