package Arrays;
public class Repeating {
    public static void main(String[] args) {
        int[] arr={3,3,3,5,5,5,5};
        int count=1;
        int j=1, max=1;
        boolean flg=true;
        for(int i=0;i<arr.length-1;){
            if(j>=arr.length){
                break;
            }
            if(arr[i]==arr[j]){
                j++;
                count++;
                flg=false;
            }
            else if(arr[i]!=arr[j]){
                i=j;
                j=i+1;
                if(max<count){
                    max=count;
                }
                count=1;
            }
//            if(count==1)
//                System.out.println(arr[i]);
        }
        System.out.print(max);
        if(flg)
            System.out.println(-1);
    }
}
