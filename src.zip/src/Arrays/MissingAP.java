package Arrays;

public class MissingAP {
    static int findMissingUtil(int arr[], int low, int high, int diff)
    {
        int mid;
        while (low <= high)
        {
            mid = (low + high) / 2;
            if ((arr[mid] - arr[0]) / diff == mid)
                low = mid + 1;
            else
                high = mid - 1;
        }
        return arr[high] + diff;
    }
    static int findMissing(int arr[], int n)
    {
        int diff = (arr[n - 1] - arr[0]) / n;
        return findMissingUtil(arr, 0, n - 1, diff);
    }
    public static void main (String[] args)
    {
        int arr[] = {2, 4, 6, 8, 10, 14};
        int n = arr.length;
        System.out.println("The missing element is "+
                findMissing(arr, n));
        System.out.println(1/2);
    }
}
