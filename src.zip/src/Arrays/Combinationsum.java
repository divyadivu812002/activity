package Arrays;

public class Combinationsum {
    static void combination(int[] arr,int key){
        int n=arr.length,sum=0;
        int ind=0;
        for (int i = 0; i <n; i++) {
            for (int j = i; j <n; j++) {
                sum=0;
                for (int k = i; k <=j; k++) {
                    System.out.print(arr[k]+" ");
                    sum+=arr[k];
                }
                System.out.println();
//                if(sum==key){
//                    System.out.println("sum"+sum);
//                }
                }
            //combination(arr,key);

        }

    }
    public static void main(String[] args) {
        int[] arr={1,2,3,4};
        int key=5;
        combination(arr,key);
    }
}
