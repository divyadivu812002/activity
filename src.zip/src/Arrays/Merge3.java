package Arrays;

import java.util.*;

public class Merge3 {
    public static void main(String[] args) {
        int[] arr1={1,2};
        int[] arr2={3,4};
        int[] arr3={5,6};
        int n=arr1.length+arr2.length+arr3.length;
        int[] arr=new int[n];
        int a1=0,a2=0,a3=0;
        for (int i=0;i<n;i++){
            if(i< arr1.length){
                arr[i]=arr1[a1];
                a1++;
            }
            else if(a2<arr2.length){
                arr[i]=arr2[a2];
                a2++;
            }
            else{
                arr[i]=arr3[a3];
                a3++;
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}
