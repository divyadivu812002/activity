package Arrays;

public class Knapsack {
    public static void main(String[] args) {
        int n=3;
        int w=50;
        int sum=0,ind=0;
        int val[]={60,100,120};
        int wt[]={10,200,30};
        for (int i = n-1; i <val.length; i++) {
            for (int j = n-2; j < val.length; j+=val[i]) {
                if (wt[n-1] <= w) {
                    if (val[i] >= val[j]) {
                        sum += val[i];
                        ind = i;
                        w -= wt[i];
                        System.out.print(ind + " ");
                    }
                }
                }
            }

        System.out.println();
        System.out.println(sum);
    }
}
