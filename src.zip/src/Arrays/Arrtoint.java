package Arrays;

public class Arrtoint {
    public static void main(String[] args) {
        int arr[]={3,6,9};
        int res=3;
        for(int i=0;i<arr.length;i++) {
            if(arr[i]%res!=0){
                System.out.print(arr[i]+" ");
            }
        }

        }
    }

