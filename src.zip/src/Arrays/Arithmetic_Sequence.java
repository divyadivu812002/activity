package Arrays;

public class Arithmetic_Sequence {
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        int n=arr.length,d=0;
        for (int i=0;i<n-1;i++){
            for(int j=0;j<n;j++){

            }
        }
    }
}
