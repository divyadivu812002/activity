package Arrays;

public class Twosum {
    public static void threesum(int[] nums, int target) {
        int c=0;
        for (int i = 0; i < nums.length; i++) {
            for (int j = 0; j < i; j++) {
                for (int k = 0; k < j; k++) {
                    if (nums[i] + nums[j] + nums[k] <= target) {
                        System.out.println(nums[k] + " " + nums[j] + " " + nums[i]);
                        c+=1;
                    }
                }
            }
        }
        System.out.println("The total no.of triplets is:"+ c);
    }
        public static void main(String[] args) {
        int nums[]={1,2,6,3,4};
        int target=8;
        threesum(nums,target);
    }
}
