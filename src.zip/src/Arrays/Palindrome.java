package Arrays;

public class Palindrome {
    public static void main(String[] args) {

        int[] arr = {1, 2,3,4, 2, 1};
       // String s="madam";
        int n = arr.length;
        int i ,j;
        for (i = 0, j = n - 1; i < n; ){
            if(arr[i]!=arr[j]){
                System.out.println("false");
                break;
            }
            else {
                i++;
                j--;
            }
        }
        System.out.println("true");
    }
}
