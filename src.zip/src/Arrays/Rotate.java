package Arrays;
import java.util.*;
public class Rotate {
    public static void main(String[] args) {
        int arr[]={1,2,3,4,5};
        int n=2;
        for (int i = 0; i <arr.length; i++) {
            System.out.print(arr[(i+n)%arr.length]);
        }
    }





























//    public static int rotate(int [] arr,int d) {
//        int n = arr.length;
//        int arr1[] = new int[n];
//        int k = 0;
//        int temp=0;
//        for (int i = d; i < n; i++) {
//            arr1[k] = arr[i];
//            k++;
//        }
//        for (int i = 0; i <d; i++) {
//            arr1[k] = arr[i];
//            k++;
//        }
//        for (int i = 0; i < n; i++) {
//            temp=arr1[i];
//            System.out.print(temp+" ");
//        }
//        return temp;
//    }
//
////    public static void print(int temp){
////        for (int i = 0; i <; i++) {
////
////        }
//
//    public static void main(String[] args) {
//        int arr[]={-1};
//        int d=2;
//       rotate(arr,d);
////        print();

    }

