package Arrays;

public class Common_Element {
    public static void main(String[] args) {
        int[] arr1={1,2,3};
        int[] arr2={3,4,5};
        int[] arr3={2,4,5};
        //int c=0;
        for (int i = 0; i <arr1.length; i++) {
          int  c=3;
            for (int j = 0; j <arr1.length; j++) {
                if(arr1[i]==arr2[j] || arr1[i]==arr3[j]){
                 c--;
                }
            }
            System.out.println(arr1.length- c);
        }
    }
}
