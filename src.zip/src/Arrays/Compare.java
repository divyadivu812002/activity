package Arrays;

public class Compare {
    public static void main(String[] args) {
        int arr[]={1,2,3,3,2,5,6};
        int n= arr.length,c=Integer.MAX_VALUE,k=0;
        for (int i = 0; i <n; i++) {
            int count=0;
            for (int j = i+1; j <n; j++) {
                count++;
                if(arr[i]==arr[j]){
                    if(c>count) {
                        c = count;
                        k=i;
                    }
                }
            }
        }
        if(c!=Integer.MAX_VALUE) {
           // System.out.println(c);
            System.out.println(arr[k]);
        }
        else
            System.out.println("No duplicates");
    }

}
