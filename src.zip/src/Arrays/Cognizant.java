package Arrays;
import java.util.*;
public class Cognizant {


        public static int maxSumArrangement(int N, int[] A) {
            // Initialize an array to hold the negative values
            int[] negatives = new int[N];
            int negativeIndex = 0;

            // Initialize an array to hold the positive values
            int[] positives = new int[N];
            int positiveIndex = 0;

            // Initialize a variable to hold the total sum
            int sum = 0;

            // Iterate through the input array
            for (int i = 0; i < N; i++) {
                // If the current value is negative
                if (A[i] < 0) {
                    // Add it to the array of negative values
                    negatives[negativeIndex++] = A[i];
                }
                // If the current value is positive
                else {
                    // Add it to the array of positive values
                    positives[positiveIndex++] = A[i];
                }
                // Add the current value to the total sum
                sum += A[i];
            }

            // Sort the arrays of negative and positive values in descending order
            Arrays.sort(negatives);
            Arrays.sort(positives);

            // Initialize a variable to hold the maximum sum
            int maxSum = sum;

            // If there are negative values
            if (negativeIndex > 0) {
                // The maximum sum is the total sum plus the product of the number of negative values
                // and the smallest negative value
                maxSum += negativeIndex * negatives[negativeIndex - 1];
            }

            // If there are positive values
            if (positiveIndex > 0) {
                // The maximum sum is the total sum plus the product of the number of positive values
                // and the largest positive value
                maxSum += positiveIndex * positives[positiveIndex - 1];
            }

            // Return the maximum sum
            return maxSum;
        }

        public static void main(String[] args) {
            int N = 8;
            int[] A = {1, -6, -5, -12, 1, 3, 8, -3};
            System.out.println(maxSumArrangement(N, A)); // Output: 39

//            N = 5;
//            A = {-99, -1, 0, 50, 10};
//            System.out.println(maxSumArrangement(N, A)); // Output: 160
        }
    }