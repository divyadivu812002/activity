package Arrays;
import java.util.*;

public class Median {
    public static void median(int[] nums1, int[] nums2) {
        int n1=nums1.length;
        int n2=nums2.length;
        int n3=n1+n2;
        float sum=0;
        double avg=0;
        int nums3[]=new int[n3];
        for(int i=0;i<n1;i++){
            nums3[i]=nums1[i];
        }
        for(int i=0;i<n2;i++){
            nums3[n1+i]=nums2[i];
        }
        Arrays.sort(nums3);
        int st=0;
        int end=n3-1;
        int mid=st+((end-st)/2);
       // System.out.println(mid);
        double merge=nums3[mid];
        if(n3%2==0){
            st=mid;
            end=mid+1;
            merge=((nums3[st])+(nums3[end]))/2f;
            System.out.print(merge);
        }


    }


    public static void main(String[] args) {
        int nums1[]={1,3};
        int nums2[]={2,4};
        median(nums1, nums2);

    }
}
