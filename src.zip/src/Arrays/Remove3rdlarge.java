package Arrays;

import java.util.Arrays;

public class Remove3rdlarge {
    static void removelast(int[] arr) {
        int n = arr.length, count = 1;
        //System.out.println(Arrays.toString(arr));
        for (int i = 0; i < arr.length - 1; i++) {

            if (arr[i] != arr[i + 1]) {
                count++;
            }
        }
       // System.out.println(count);
        if (count <= 2) {
            System.out.println(arr[arr.length - 1]);
        }
        else {
            //int last = arr[n - 1]
            int i = 0, c = Integer.MIN_VALUE, ind = Integer.MIN_VALUE;
            while (i < 3) {
                c = Integer.MIN_VALUE;
                for (int j = 0; j < arr.length; j++) {
                    //for (int k = j+1; k < arr.length ; k++) {
                    if (arr[j] >= c) {
                        c = arr[j];
                        ind = j;
                    }
                }


                for (int k = 0; k < arr.length; k++) {
                    if (arr[k] == c) {
                        arr[k] = Integer.MIN_VALUE;
                    }
                }
                for (int k = 0; k < arr.length; k++) {
                  //  System.out.print(arr[k] + " ");
                }
              //  System.out.println();
                i++;
            }
            System.out.println(c);
        }
    }
    public static void main(String[] args) {
        int[] arr={1,2,3};
        Arrays.sort(arr);
        removelast(arr);
    }
}
