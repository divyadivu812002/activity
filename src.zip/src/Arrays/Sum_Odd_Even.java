package Arrays;

public class Sum_Odd_Even {
    public static void main(String[] args) {
        int[] arr={3,2,1,7,5,4};
        int maxodd=0,odd2=0,evmax=0,ev2=0,sum;
        for (int i = 0; i <arr.length; i++) {
          //  for (int j = i+1; j <arr.length ; j++) {
                if(i%2==0 && arr[i]>evmax) {
                    ev2 = evmax;
                    evmax = arr[i];
                }
                    else if(i%2==0 && ev2<arr[i]){
                        ev2=arr[i];
                    }
                 if(i%2!=0 && arr[i]>maxodd) {
                    odd2=maxodd;
                    maxodd=arr[i];
                }
                 else if( i%2!=0 && odd2<arr[i]){
                     odd2=arr[i];
                 }
            }
        System.out.println(odd2+" "+ev2);
        sum=odd2+ev2;
        System.out.println(sum);
    }
}
