package Arrays;

public class MaxSumSub {
    public static void main(String[] args) {
        int k=10;
        int[] arr={1,2,3,4,5,6,7};
        int n=arr.length;
        int start = 0, end = 0, flg = 1, large = 0;
        for (int size = n; size >= 1; size--) {
            for (int i = 0; i <= n - size; i++) {
                int sum = 0;
                int count = 0;
                for (int j = i; j < size + i; j++) {
                    sum += arr[j];
                    count++;
                }
                if (sum == k && count > large) {
                    large = count;
                    end = i + size - 1;
                    start = i;
                }
            }
        }

// Printing the result subarray
        for (int i = start; i <= end; i++) {
            System.out.print(arr[i] + " ");
        }

    }
}
