package Arrays;
import java.util.*;
public class Permutations {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        int cnt=0;String temp="";
        int count=0;
        for(int i=0;i<str.length();i++){
            String dum="";
            if(str.charAt(i)=='-'){
                cnt++;
            }
            if(cnt%2==0&&cnt!=0&&str.charAt(i)=='-'){
                dum+=str.charAt(i+1);
                dum+=str.charAt(i+2);
                dum+=str.charAt(i+3);
                dum+=str.charAt(i+4);
                // System.out.println(dum);
                if(temp.indexOf(dum)==-1){
                    temp+=dum;
                    count++;
                    i=i+4;
                }
    }
        }
        System.out.println(count);
    }
}

