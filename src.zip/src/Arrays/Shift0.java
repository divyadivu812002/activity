package Arrays;
public class Shift0 {
    public static void main(String[] args) {
        int[] arr={5,8,3,0,0,4,7,1};
        int n=arr.length;
        int c=0;
        for (int i = 0; i <n; i++) {
            if(arr[i]!=0){
              //  swap(arr,i,c);
                int temp=arr[i];
                arr[i]=arr[c];
                arr[c]=temp;
                c++;
            }
        }
        for (int i = 0; i <n; i++) {
            System.out.print(arr[i]+" ");
        }
    }
    static void swap(int []arr,int i,int c){
        int temp=arr[i];
        arr[i]=arr[c];
        arr[c]=temp;
    }
}
