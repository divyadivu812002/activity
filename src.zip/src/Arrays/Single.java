package Arrays;

import java.util.Arrays;

public class Single {
    public static void main(String[] args) {
    int arr[]={2,2,3,4,52};
    int n=arr.length;
    //int c=0;
        int temp=0;
        for (int i = 0; i <n; i++) {
            int c = 0;
            for (int j = 0; j < n; j++) {
                if (arr[i] == arr[j])
                    c++;
            }
            for (int j = 0; j <n; j++) {
                if (c == 2)
                    System.out.println(arr[i]);
            }
        }
//        System.out.println(temp);
    }
    }
