package Arrays;
import java.util.*;
public class Subarray {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int arr[] =new int[n];
        for (int i = 0; i <n; i++) {
            arr[i]=s.nextInt();
        }
        int c=0;
        //int n = arr.length;
        for (int i = 0; i <n; i++) {
            for (int j = i; j <n; j++) {
                int sum=0;
                for (int k = i; k <= j; k++) {
                    // System.out.print(arr[k]);
                    sum=sum+arr[k];

//                    if(sum<0){
//                        c=+1;
//                        System.out.println(c);
//                    }
                }
              //  System.out.println();
//                System.out.println("Row wise Sum is "+sum);
//                System.out.println();
                if(sum>0){
                    c+=1;

                }
                //System.out.print(sum);
                //System.out.println();
            }
        }
        System.out.println(c);
    }
}