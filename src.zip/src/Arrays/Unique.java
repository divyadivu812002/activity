package Arrays;
import java .util.*;
public class Unique {
        public static void main(String[] args) {
            int[] inputArray = {3,6,5,1,8,6,2,5};
            int length = inputArray.length;
            int[] uniqueArray = new int[length];
            int uniqueCount = 0,duplicatecount=0;

            for (int i = 0; i < length; i++) {
                int currentElement = inputArray[i];
                boolean isDuplicate = true;

                for (int j = 0; j < uniqueCount; j++) {
                    if (uniqueArray[j] == currentElement) {
                        isDuplicate = false;
                        duplicatecount++;
                        break;
                    }
                }

                if (isDuplicate) {
                    uniqueArray[uniqueCount++] = currentElement;
                }
            }

            for (int i = 0; i < length-duplicatecount; i++) {
                System.out.print(uniqueArray[i]+" ");
            }
        }
    }


