package Arrays;

public class Arraysum {
    public static void main(String[] args) {
        int arr1 []= {6, 7, 9};
        int arr2[]={5,7,8};
        int temp=0,add=0;
        for (int i = 0; i <arr1.length; i++) {
            for (int j = 0; j <i; j++) {
                temp=arr1[j]+arr2[i];
                add=add+temp;
                System.out.println(temp);
            }
        }
       // System.out.println(add);
//        String s=Integer.toString(add);
//        int j=0;
//        int newarr[]=new int[s.length()];
//        for (int i = 0; i <arr1.length(); i++) {
//           newarr[s-j-1]=arr1.length%10;

       // }
    }
}
