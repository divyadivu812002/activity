package Arrays;
import java.util.Arrays;
public class Merge {
    // Java Program to demonstrate merging
// two array using pre-defined method
        public static void main(String[] args)
        {
            // first array
            int[] a = { 1, 2 };

            // second array
            int[] b = { 3,4 };

            // determines length of firstArray
            int a1 = a.length;

            // determines length of secondArray
            int b1 = b.length;

            // resultant array size
            int c1 = a1 + b1;

            // create the resultant array
            int[] c = new int[c1];
            for (int i = 0; i <a1; i++) {
                c[i]=a[i];
                //System.out.print(a1);
            }

            for (int i = 0; i <b1; i++) {
                c[a1+i]=b[i];
            }


            // using the pre-defined function arraycopy
            //System.arraycopy(a, 0, c, 0, a1);
            //System.arraycopy(b, 0, c, a1, b1);

            // prints the resultant array
            for (int i = 0; i <c.length; i++) {
                System.out.print(c[i]+" ");
            }
            System.out.println();
            float sum=0;
            for (int i = 0; i <c1; i++) {
                sum=sum+c[i];
               // System.out.println(sum);
            }
            float avg=sum/c1;
            System.out.println(sum+" "+c1);
            System.out.println(avg);
            float k=10,l=4;
            float m=k/l;
            System.out.println(m);
        }
    }


