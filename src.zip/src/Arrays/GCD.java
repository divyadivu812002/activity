package Arrays;

public class GCD {
    public static void main(String[] args) {
        int arr[]={11,12,13};
        int rem1=0,rem2=0;
        for (int i = 0; i <arr.length; i++) {
            rem1 = arr[i] % 10;
        }
            for (int j = 0; j < arr.length; j++) {
                rem2 = arr[j] % 10;
//                System.out.println(rem1 + " " + rem2);
        }
        for (int i = 0; i <arr.length; i++) {
            System.out.println(rem1+" "+rem2);
        }
    }
}
