package Arrays;

public class Even_Subarray {
    public static void main(String[] args) {
        int[] arr={1,2,3,4,5};
        int n=arr.length;
        for(int i=0,j=1;j<n;){
            if(arr[i]+arr[j]%2==0){
                System.out.print(arr[i]+" ");
                j++;
            }
            else {
                System.out.println();
                j++;
            }
//            if(j==n){
//                i++;
//                j=i;
//            }
        }
    }
}
