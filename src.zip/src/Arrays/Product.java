package Arrays;
public class Product {
    public static void main(String[] args) {
        int[] arr1={-1,0,2,-1};
        //int[] arr2=new int[arr1.length];
       // int c=0;
        for (int i = 0; i <arr1.length; i++) {
           int c=1;
            for (int j = 0; j <arr1.length; j++) {
                if(i!=j) {
                    c=c*arr1[j];
                }
            }
            System.out.print(c+" ");
        }
    }
}
