package Arrays;

public class Three_Sum {
    public static void main(String[] args) {
//        int[] arr={2,3,4,1,5,7};
//        int k=3,sum=9;
        String str="letcedo";
        char[] arr=str.toCharArray();
        int i=0,j=0;
        for( i=0,j=arr.length-1;i<arr.length/2;){
            if(arr[i]=='e' && arr[j]=='o'){
                char c=arr[i];
                arr[i]=arr[j];
                arr[j]=c;
                i++;j--;
                //break;
            }
            else if(arr[i]=='e' && arr[j]!='o'){
                j--;
            }
            else if(arr[j]=='o' && arr[i]!='e'){
                i++;
            }
            else{
                i++;j--;
            }
        }
        for(i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
