package Zoho_interview;

import java.util.Arrays;
import java.util.Scanner;

public class Wave {
    public static void swap(int i,int[] arr){
        int temp=arr[i];
        arr[i]=arr[i+1];
        arr[i+1]=temp;
    }
    public static void swaping(int i,int[] arr){
        int temp=arr[i];
        arr[i]=arr[i-1];
        arr[i-1]=temp;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int[] arr=new int[n];
        for (int i=0;i<n;i++){
            arr[i]=s.nextInt();
        }
        int i=0,j=0;
        for (i=0,j=n-1;i<=n/2;i+=2,j-=2){
            swap(i,arr);
            swaping(j,arr);
        }
        System.out.println(Arrays.toString(arr));
    }
}
