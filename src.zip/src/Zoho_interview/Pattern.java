package Zoho_interview;
import java.util.Scanner;

public class Pattern {
    public static boolean check(String inp,String patt){
        for (int i=0;i<patt.length()-1;i++) {
            if (patt.charAt(i) =='?' && patt.charAt(++i)=='?') {
                    return false;
            } else if (patt.charAt(i)=='*'){
                int start=i;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String inp="baaabab";
        String pattern="ba?a";
        boolean ch=true;
        ch=check(inp,pattern);
        System.out.println(ch);
    }
}
