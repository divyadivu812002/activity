package Zoho_interview;
import java.util.Scanner;
public class Prime {

    public static boolean isPrime(int n) {
        for (int i = 2; i*i <= n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int start = sc.nextInt();
        int end = sc.nextInt();
        for (int i = end; i >= start; i--) {
            int num = i;
            boolean check = true;
            while (num != 0) {
                check = isPrime(num);
                if (check) {
                    num = num / 10;
                } else {
                    num = 0;
                }
            }
            if (check){
                System.out.println(i);
                return;
            }
        }
    }
}
