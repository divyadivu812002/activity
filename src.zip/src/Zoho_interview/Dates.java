package Zoho_interview;

import java.util.Scanner;

public class Dates {
    public static void printday(int start,int time,String input,String[] wd,int i,int wh){
//        if(time<7){
//            start=0;
//        }

//        wh=7;
        int end=17;
        if(end-start>=time){
//        if(time<=7){
            System.out.println(input+" "+(start+time));
            return;
        }

        else {
           // System.out.println("i is"+i);
            for (int st=i;i < wd.length-1;) {
                input = wd[++i];
                //System.out.println(input + " " + i);
                time =Math.abs(time - wh);
               // System.out.println("time is"+time);
                break;
            }
        }
        printday(start,time,input,wd,i,wh);
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String[] wd={"Monday","Tuesday","Wednesday","Thursday","Friday"};
        int[] arr={10,5};
        int wh=7;
        String input="Tuesday";
        int start=12;
        int time=15;
        int total=0;
        for (int i=0;i<wd.length-1;i++) {
            if (input.equals(wd[i]) && start >= 10 && start <= 17) {
                // time=time-wh;
                printday(start,time,input,wd,i,wh);
            }
        }
    }
}
