package MultiThreading;


class Threads1 extends Thread{
    public void run(){
        try {
            for (int i = 65; i < 70; i++) {
                System.out.println((char)(i));
                Thread.sleep(1000);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
}
class Threads2 extends Thread{
    public void run(){
        try {
            for (int i = 0; i < 5; i++) {
                System.out.println(i);
                Thread.sleep(1000);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
}

class Thread3 implements Runnable{
    public void run(){

    }
}

public class Main {
    public static void main(String[] args) {
        Threads1 th1=new Threads1();
        Threads2 th2=new Threads2();
        th1.start();
        th2.start();
    }
}
