package Exception;

import java.util.Scanner;

public class Train {
    public static void main(String[] args) {
        try{
            Scanner scan=new Scanner(System.in);
            int a = scan.nextInt();
            int b = scan.nextInt();
            int c=a/b;
            System.out.println(c);
        }
        catch (Exception e){
            System.out.print(e.getMessage());
        }
    }
}