package Treeset;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class Remove {
    public static void main(String[] args) {
//        ArrayList<Integer> arr1=new ArrayList<>(Arrays.asList(1,4,4,7));
//        ArrayList<Integer> arr2=new ArrayList<>(Arrays.asList(2,4,6,8));
        HashSet<Integer> s=new HashSet<>();
        int[] arr={1,2,3,3,4,4,5};
        int[] arrr2={2,4,6,7,8};
        for (int i = 0; i <arr.length; i++) {
            s.add(arr[i]);
        }
        for (int i = 0; i <arrr2.length; i++) {
            s.add(arrr2[i]);
        }
        System.out.println(s);
    }
}
