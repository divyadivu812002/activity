package Treeset;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeSet;

public class Intersection {
    public static void main(String[] args) {
        ArrayList<Integer> arr1=new ArrayList<>(Arrays.asList(1,3,5,7));
        ArrayList<Integer> arr2=new ArrayList<>(Arrays.asList(3,4,6,8));
        TreeSet<Integer> tree=new TreeSet<>();
        arr1.retainAll(arr2);
        tree.addAll(arr1);
        System.out.println(tree);
    }
}
