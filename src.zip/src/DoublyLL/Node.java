package DoublyLL;

public class Node {
    int data;
    Node next;
    Node prev;

    Node(int data) {
        this.data=data;
        this.next=null;
        this.prev=null;
    }
}

class Methods{
    Node head;
    Node tail;

    void add(int data){
        Node temp=new Node(data);
        if(head==null){
            head=temp;
            tail=temp;
        }
        else {
           tail.next=temp;
           temp.prev=tail;
           tail=temp;
        }
    }
    void add(int ind,int data){
        Node temp=new Node(data);
        Node cur=head;
        int count=0;
        while (count<ind-1){
            cur=cur.next;
            count++;
        }
        cur.next.prev=temp;
        temp.next=cur.next;
        cur.next=temp;
        temp.prev=cur;
    }
    void printllst(){
        Node cur=head;
        while (cur!=null){
            System.out.print(cur.data+" ");
            cur=cur.next;
        }
        System.out.println();
    }

    void printllback(){
        Node cur=tail;
        while (cur!=null){
            System.out.print(cur.data+" ");
            cur=cur.prev;
        }
    }
    void addfirst(int data){
        Node temp=new Node(data);
        if(head==null){
            head=temp;
            tail=temp;
        }
        else {
            temp.next=head;
            head.prev=temp;
            head=temp;
        }
    }

    void removefirst(){
        if(head==null){

        } else if (head.next==null) {
            head=null;
            tail=null;
        }
        else {
            head=head.next;
            head.prev=null;
        }
    }
}

class DoubleLinkedList{
    public static void main(String[] args) {
        Methods l1=new Methods();
        l1.add(10);
        l1.add(20);
        l1.add(30);
        l1.add(40);
        l1.printllst();
        l1.add(3,25);
        l1.printllst();
//        l1.printllback();
//        l1.addfirst(5);
//        l1.printllst();
        l1.removefirst();
        l1.printllst();
    }
}
