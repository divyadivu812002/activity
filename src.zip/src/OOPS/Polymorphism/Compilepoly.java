package OOPS.Polymorphism;

public class Compilepoly {
  static void add (int a,int b){
        int sum=a+b;
        System.out.println(sum);
    }
    static void add(int a,int b,int c){
        int sum=a+b+c;
        System.out.println(sum);
    }

    public static void main(String[] args) {
        int a=5,b=6,c=7;
        add(a,b);
        add(a,b,c);
  }
}
