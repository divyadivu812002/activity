package OOPS.Polymorphism;

public class Polymorphism {

}
class bike{
    void run(){
        System.out.println("running");
    }
}
class splendor extends bike{
    @Override
    void run() {
        System.out.println("running safely");
    }
}
class polyuse{
    public static void main(String[] args) {
        splendor b=new splendor();
        b.run();
    }
}
