package OOPS;

import java.util.Scanner;

public class Fraction {
    int numerator;
    int denominator;
public  Fraction(int numerator,int denominator){
    this.numerator=numerator;
    this.denominator=denominator;
    //   simplify();
}
    private void simplify() {
    int gcd=1;
    //int small=Math.min(numerator,denominator);
//        System.out.println(small);
    for (int i=2;i<=numerator;i++){
        if(numerator%i==0 && denominator%i==0){
            gcd=i;
        }
    }
    numerator=numerator/gcd;
    denominator=denominator/gcd;
    print();
}
public void increment(){
    numerator=numerator+denominator;
    simplify();
}
public void print(){
    System.out.println(numerator+"/"+denominator);
}
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        int b=s.nextInt();
        Fraction f1=new Fraction(a,b);
        f1.simplify();
        f1.increment();
    }
}
