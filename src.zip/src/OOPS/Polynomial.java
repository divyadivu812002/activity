package OOPS;

public class Polynomial {
    int data[];
    int nextelementindex;
    public Polynomial(){
        data=new int[2];
        nextelementindex=0;
    }
//    public int size(){
//        return nextelementindex;
//    }

    public void setcoeff(int degree,int coeff){
        if(degree>data.length-1) {
            int temp[]=data;
            data=new int[degree+1];
            for (int i = 0; i <temp.length; i++) {
                data[i]=temp[i];
            }
        }
        data[degree] = coeff;
    }
    public int getcoeff(int coeff){
        if (coeff<this.data.length) {
            return data[coeff];
        }
        else {
            return 0;
        }
    }
    public boolean isempty(){
       return nextelementindex==0;
    }
//    public int degree(){
//        return size();
//    }
    public void print() {
        for (int i = 0; i <data.length; i++) {
            if(data[i]!=0){
                System.out.print(data[i]+"x^"+i+"+");
            }
        }
        System.out.println();
    }
    public Polynomial add(Polynomial p){
        Polynomial ans=new Polynomial();
        int plen1=this.data.length;
        int plen2=p.data.length;
//        System.out.println(plen1+" "+plen2);
        int len=Math.min(plen1,plen2);
        int i;
        for (i = 0; i <len; i++) {
           // System.out.print(this.data[i]+" ");
            //System.out.print(p.data[i]+" ");
           this.setcoeff(i,this.data[i]+p.data[i]);
//            System.out.print(d+" ");
        }
        while (i<plen1){
            this.setcoeff(i,this.data[i]);
            i++;
        }
        while (i<plen2){
            this.setcoeff(i,p.data[i]);
            i++;
        }
        for (int j = 0; j <this.data.length; j++) {
            System.out.print(this.data[j]+"x^"+i+"+");
        }
        System.out.println();

        return this;
    }

    public Polynomial subtract(Polynomial p){
        Polynomial ans=new Polynomial();
        int plen1=this.data.length;
        int plen2=p.data.length;
        int len=Math.min(plen1,plen2);
        int i;
        for(i=0;i<len;i++){
            this.setcoeff(i,this.data[i]-p.data[i]);
        }
        while (i<plen1){
            this.setcoeff(i,this.data[i]);
            i++;
        }
        while (i<plen2){
            this.setcoeff(i,p.data[i]);
            i++;
        }
        for (int j = 0; j <this.data.length; j++) {
            System.out.print(this.data[j]+"x^"+j+"+");

        }
        return this;
    }
    public Polynomial multiply(Polynomial p){
        Polynomial ans=new Polynomial();
        int plen1=this.data.length;
        int plen2=p.data.length;
        int len=Math.min(plen1,plen2);
        int i;
        for (i=0;i<len;i++){
            this.setcoeff(i,this.data[i]*p.data[i]);
        }
        while (i<plen1){
            this.setcoeff(i,this.data[i]);
            i++;
        }
        while (i<plen2){
            this.setcoeff(i,p.data[i]);
            i++;
        }
        for (int j = 0; j <this.data.length; j++) {
            System.out.print(this.data[j]+"x^"+j+"+");
        }
        return this;
    }

    public static void main(String[] args) {
      Polynomial p1=new Polynomial();
      p1.setcoeff(0,3);
      p1.setcoeff(3,5);
      p1.print();
      Polynomial p2=new Polynomial();
      p2.setcoeff(0,4);
      p2.setcoeff(3,2);
      p2.setcoeff(5,8);
      p2.print();
//      p1.add(p2);
//      p1.subtract(p2);
      p1.multiply(p2);
    }
}
