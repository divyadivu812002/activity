package OOPS.Inheritance;

public class Vehicle {
    String name;
    private int speed;
    void print() {
        System.out.println(name + " " + speed);
    }
        public int getspeed(){
            return speed;
    }
    public void setspeed(int speed){
        this.speed=speed;
    }
}
class Car extends Vehicle{
    int numofdoors;
    void print(){
        System.out.println(name+" "+getspeed()+" "+numofdoors);
    }
}
class Bike extends Vehicle {
    int topspeed;
}
class Vehicleuse{
    public static void main(String[] args) {
        Vehicle v=new Vehicle();
        v.name="Tata";
        v.setspeed(100);
        Bike b=new Bike();
        b.name="Honda";
        v.print();
        b.print();
    }
}