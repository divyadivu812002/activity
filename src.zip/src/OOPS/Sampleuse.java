package OOPS;

import java.util.Scanner;

abstract public class Sampleuse {
    abstract void run();
}

abstract class Simp extends Sampleuse{
    void run(){
        System.out.println("Hii");
    }
}



