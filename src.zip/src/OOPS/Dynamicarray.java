package OOPS;
public class Dynamicarray {
    int data[];
    int nextelementindex;
    public Dynamicarray(){
        data=new int[5];
        nextelementindex=0;
    }
    public boolean isEmpty(){
        return nextelementindex==0;
    }
    public int size(){
        return nextelementindex;
    }
    public int get(int i){
        return data[i];
    }
    public void set(int i,int elem){
        data[i]=elem;
    }
    public void add(int elem){
        if (nextelementindex==data.length){
            doublecapacity();
        }
        data[nextelementindex]=elem;
        nextelementindex++;
    }
    public void doublecapacity(){
        int temp[]=data;
        data=new int[2*temp.length];
        for (int i = 0; i <temp.length; i++) {
            data[i]=temp[i];
        }
    }
    public int remove(){
        int temp=data[nextelementindex-1];
        nextelementindex--;
        return temp;
    }

    public static void main(String[] args) {
        Dynamicarray d=new Dynamicarray();
        for (int i = 1; i <100; i++) {
            d.add(100+i);
        }
        System.out.println(d.size());
        System.out.println(d.get(2));
        d.set(2,34);
        System.out.println(d.get(3));
        while (!d.isEmpty()) {
            System.out.println(d.remove());
            System.out.println("size"+d.size());
        }
    }
}
