package OOPS;

public class Gettersetter {
    int numerator;
    int denominator;
    public  Gettersetter(int numerator,int denominator){
        this.numerator=numerator;
        this.denominator=denominator;
        
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }
    public int getNumerator(){
        return numerator;
    }
    public void setDenominator(int denominator){
        if(denominator==0){
            return;
        }
        this.denominator=denominator;
    }
    public int getDenominator(){
        return denominator;
    }

    private void simplify() {
        int gcd=1;
        int small=Math.min(numerator,denominator);
        // System.out.println(small);
        for (int i=2;i<=small;i++){
            if(numerator%i==0 && denominator%i==0){
                gcd=i;
            }
        }
        numerator=numerator/gcd;
        denominator=denominator/gcd;
        print();
    }

    public void increment(){
        numerator=numerator+denominator;
        simplify();

    }
    public void add(Gettersetter f2){
        this.numerator=numerator* f2.numerator;
        this.denominator=denominator* f2.denominator;
        simplify();
    }
    public static Gettersetter add(Gettersetter f1, Gettersetter f2){
        int newnum=f1.numerator* f2.numerator;
        int newden=f1.denominator* f2.denominator;
        Gettersetter f3=new Gettersetter(newnum,newden);
        return f3;
    }
    public void print(){

        System.out.println(numerator+"/"+denominator);
    }
    public static void main(String[] args) {
//        Scanner s=new Scanner(System.in);
//        int a=s.nextInt();
//        int b=s.nextInt();
        Gettersetter f1=new Gettersetter(4,6);
        Gettersetter f2=new Gettersetter(4,8);
        f1.simplify();
     //   f1.increment();
        Gettersetter f3=Gettersetter.add(f1,f2);
        f3.simplify();
        //f3.print();
    }
}

