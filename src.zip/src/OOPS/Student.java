package OOPS;
public class Student {
    String name;
    private int rollnumber;
    int age,salary,a,b;
//     Student(){
//         this(10,2);
//         System.out.println("one");
//    }
     Student(int a,int b){
        this.a=a;
        this.b=b;
         System.out.println("Two");
    }
    void print(){
        System.out.println(name+" "+rollnumber);
    }
  //  public int getRollnumber(){
    //    return rollnumber;
  //  }
   // public void setRollnumber(int rollnumber){
      //  rollnumber=rollnumber;
 //   }
}


