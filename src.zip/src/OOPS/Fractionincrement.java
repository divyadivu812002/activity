package OOPS;

public class Fractionincrement {

}
