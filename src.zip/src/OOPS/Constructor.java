package OOPS;

import java.util.Scanner;

public class Constructor {
    private int roll;
    String name;
    public Constructor(String name,int roll){
        this.name=name;
        this.roll=roll;
    }
//    public int getRoll(){
////       this.roll=roll;
//       return getRoll();
//    }
//    public void setRoll(int roll){
//        this.roll=roll;
//    }
    public void print(){
        System.out.println(name+" "+roll);
    }

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String s1=s.nextLine();
        int n=s.nextInt();
        Constructor c=new Constructor(s1,n);
        c.print();
        //c.setRoll(n);
    }
}
