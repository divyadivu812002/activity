package OOPS;
public class Complexnumbers {
        int first;
        int second;

        public Complexnumbers (int first,int second){
            this.first=first;
            this.second=second;
        }
        public void setFirst(int first){

            this.first=first;
        }
        public int getFirst(){
            return first;
        }
        public void setSecond(int second){
            this.second=second;
        }
        public int getSecond(){
            return second;
        }
        public static Complexnumbers add(Complexnumbers f1,Complexnumbers f2){
            int newfirst=(f1.first*f2.first)-(f1.second* f2.second);
            int newsecond= (f1.second*f2.first)+(f1.first*f2.second);
            Complexnumbers f3=new Complexnumbers(newfirst,newsecond);
            //System.out.println(newfirst+" "+newsecond);
           return f3;
        }
        public void print(){
            System.out.println(first);
            System.out.println(second+"i");
        }


    public static void main(String[] args) {
        Complexnumbers f1=new Complexnumbers(4,5);
        Complexnumbers f2=new Complexnumbers(6,7);
        Complexnumbers f3=Complexnumbers.add(f1,f2);
        f3.print();
    }
}
