package OOPS;

import java.util.Scanner;

public class Sample {
    public static class Bike{}
    private int roll = 0;
    String name;

    public int getRoll() {
        //this.roll=roll;
        return this.roll;
    }

    public void setRoll(int roll) {
        if (roll > 0)
            this.roll=roll;
    }
}

class Main55{
    public static void main(String[] args) {
        Sample.Bike b=new Sample.Bike();
    }
}

