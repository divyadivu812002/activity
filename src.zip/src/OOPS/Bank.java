package OOPS;

import java.util.ArrayList;
import java.util.List;

public class Bank {
    String bName;
    int noBranch;
    String ifsc;
    public Bank(){
    }
    public Bank(String name){
        this.bName=name;
        this.noBranch=0;
        this.ifsc="1234AAA";
    }
}

class Customer extends Bank{
    static int id;
    String cName;
    String cid;
    int accNo;
    private int balance;

    public Customer(String name,int no){
        super("AAA");
        this.cName=name;
        this.accNo=no;
    }

    public void setBalance(int amount){
        this.balance=amount;
    }
    public int getBalance(){
        return this.balance;
    }
    public void genId(){
        this.cid=bName.substring(0,3)+"IFSC"+id++;
    }
}

class Mains {
    public static void addCustomer(List list) {
        Customer cus = new Customer("Sanjay", 123);
        cus.genId();
        cus.setBalance(2000);
        list.add(cus);
    }
    public static void getCustomer(List list){
        for (Object cus : list) {
            System.out.println(cus);
        }
    }
    public static void main(String[] args) {
        Bank bank = new Bank("AAA");
        ArrayList<Customer> list=new ArrayList<>();
        System.out.println("Enter customer details");
        addCustomer(list);
        getCustomer(list);
    }
}
