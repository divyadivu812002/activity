package OOPS;
import java.util.*;
public class Studentuse {
    public static void main(String[] args) {
     //   Scanner in=new Scanner(System.in);
        Student s1=new Student(2,3);
      //  s1.print();
     //   Student s2=new Student("Gowtham");
    //    s2.print();
 //       s1.name=in.nextLine();
       // s1.rollnumber=in.nextInt();
        //    s1.age=in.nextInt();
//        s1.setRollnumber(in.nextInt());
//        s1.salary=in.nextInt();
//        s2.name=s1.name;
//        System.out.println(s2.name+" "+s1.getRollnumber());
//        System.out.println(s1.age+" "+s1.salary);
    }
}
