package Zoho;

import java.util.Arrays;

public class Find_Weight {
    public static void swap(int[] arr,int j){
                   int temp=arr[j+1];
                    arr[j+1]=arr[j];
                    arr[j]=temp;
    }
    public static void main(String[] args) {
        int[] arr={10,36,54,89,12},sum_arr=new int[arr.length];//5-ps,4-*4 and /6, 3 if even
        int n=arr.length;
        for (int i = 0; i <n; i++) {
            int w=0;
            double sqrt=Math.sqrt(arr[i]);
            if(sqrt*sqrt==arr[i]){
                w+=5;
            }
            if ((arr[i]%6==0) && (arr[i]%4==0)) {
                w+=4;
            }
            if (arr[i]%2==0){
                w+=3;
            }
             sum_arr[i]=w;
            System.out.println(arr[i]+" "+w);
        }
        for (int i = 0; i <n ; i++) {
            for (int j = 0; j < n-1; j++) {
                if (sum_arr[j + 1] > sum_arr[j]) {
                    swap(sum_arr,j);
                    swap(arr, j);
                }
            }
        }
//

        System.out.println(Arrays.toString(arr)+" "+Arrays.toString(sum_arr));
    }
}
