package Zoho;

public class Patternodd {
    public static void main(String[] args) {
        String str="sanjay";
        int n=str.length();
        //char[][] res=new char[n][n];
        for (int i = 0; i <str.length(); i++) {
            for (int j = 0; j <str.length() ; j++) {
                if(i==j){
           //         res[i][j]=str.charAt(i);
                    System.out.print(str.charAt(i));
                }
                else if((i+j==n-1)){
                    System.out.print(str.charAt((n-1)-i));
                }
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
