package Zoho;
import java.util.*;

public class MinimumPerfectBudget {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int minBudget = Integer.MAX_VALUE;

        for (int i = 0; i < n; i++) {
            int expenditure = scanner.nextInt();
            int bonus = scanner.nextInt();
            int rewardOrPenalty = scanner.nextInt();

            if (rewardOrPenalty >= 0) {
                minBudget = Math.min(minBudget, expenditure);
            } else {
                minBudget = Math.min(minBudget, expenditure - rewardOrPenalty);
            }
        }

        System.out.println(minBudget);
    }
}
