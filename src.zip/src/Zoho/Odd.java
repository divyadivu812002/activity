package Zoho;

public class Odd {
    public static void main(String[] args) {
        int start=2,end=15;
        for (int i = start; i <end; i++) {
            if(i%2!=0){
                System.out.print(i+" ");
            }
        }
    }
}
