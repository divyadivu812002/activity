package Zoho;

public class String_Arrange {
    public static void main(String[] args) {
        String str="WELCOMETOZOHOCORPORATION";
        char[][] carr=new char[5][5];
      //  int[][] arr=new int[5][5];
        int n=carr.length,k=0,i,j;
        System.out.println(n);
        for (i = 0; i <n; i++) {
            for (j = 0; j <n; j++) {
                if(k==str.length()){
                    carr[i][j]='M';

                }
                else {
                    carr[i][j] = str.charAt(k);
                    k++;
                }

            }
           // System.out.println(k);
        }
        for ( i = 0; i <n; i++) {
            for (j = 0; j <n; j++) {
                System.out.print(carr[i][j]+" ");
            }
            System.out.println();
        }
        for (int l = 0; l <n; l++) {
            for (int m = 0; m <n; m++) {
                if(carr[l][m]=='T' && carr[l][m+1]=='O' && carr[l][m+2]=='O'){
                    System.out.println("starts at<"+l+","+m+">");
                    System.out.println("ends at<"+l+","+m+2+">");
                } else if (carr[l][m]=='T' && carr[l+1][m]=='O' && carr[l+2][m]=='O') {
                    System.out.println("starts at<"+l+","+m+">");
                    System.out.println("ends at<"+(l+2)+","+m+">");
                }

            }

        }
    }
}
