package Zoho;

import java.util.Arrays;
import java.util.Scanner;

public class PerfectBudget {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        Project[] projects = new Project[n];

        for (int i = 0; i < n; i++) {
            int expenditure = scanner.nextInt();
            int completionBonus = scanner.nextInt();
            String rewardPenalty = scanner.next();
            int rewardPenaltyValue = Integer.parseInt(scanner.next());

            projects[i] = new Project(expenditure, completionBonus, rewardPenalty, rewardPenaltyValue);
        }

        Arrays.sort(projects);

        int budget = 0;
        int currentBonus = 0;

        for (Project project : projects) {
            if (project.rewardPenalty.equals("+") || currentBonus >= project.rewardPenaltyValue) {
                budget += project.expenditure;
                currentBonus += project.completionBonus;
            } else {
                budget += Math.abs(project.rewardPenaltyValue - currentBonus);
                currentBonus = project.rewardPenaltyValue;
            }
        }

        System.out.println(budget);

        scanner.close();
    }
}

class Project implements Comparable<Project> {
    int expenditure;
    int completionBonus;
    String rewardPenalty;
    int rewardPenaltyValue;

    public Project(int expenditure, int completionBonus, String rewardPenalty, int rewardPenaltyValue) {
        this.expenditure = expenditure;
        this.completionBonus = completionBonus;
        this.rewardPenalty = rewardPenalty;
        this.rewardPenaltyValue = rewardPenaltyValue;
    }

    @Override
    public int compareTo(Project other) {
        return Integer.compare(Math.abs(other.rewardPenaltyValue), Math.abs(this.rewardPenaltyValue));
    }
}
