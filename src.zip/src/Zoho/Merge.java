package Zoho;

import java.util.Arrays;

public class Merge {
    public static void main(String[] args) {
        int[] arr1={1,2,3,4,5,6,7,};
        int[] arr2={5,6,7,8,9};
        int[] arr3=new int[arr1.length+arr2.length];
        for (int i = 0; i <arr1.length; i++) {
            arr3[i] = arr1[i];
        }
            for (int i = 0; i < arr2.length; i++) {
                    arr3[arr1.length + i] = arr2[i];
            }
        System.out.println(Arrays.toString(arr3));
            int[] res=new int[arr3.length];
            int dupcount=0,ucount=0;
        for (int i = 0; i <arr3.length; i++) {
            int current=arr3[i];
            boolean duplicate=true;
            for (int j = 0; j <ucount; j++) {
                if(res[j]==current){
                    duplicate=false;
                    dupcount++;
                    break;
                }
            }
            if(duplicate){
                res[ucount++]=current;
            }
        }
        for (int i = 0; i < arr3.length-dupcount; i++) {
            System.out.print(res[i]+" ");
        }
    }
}
