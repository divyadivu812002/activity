package Zoho;

public class A1b2 {
    public static void main(String[] args) {
        String str="a3b2c5";
        int n=str.length();
        char[] arr=str.toCharArray();
        for (int i = 0; i <arr.length ; i++) {
            if(arr[i]>='0'&& arr[i]<='9'){
                int temp=(int) arr[i]-48;
                for (int j = 0; j <temp ; j++) {
                    System.out.print(arr[i-1]+" ");
                }
            }
        }
    }
}
