package Zoho;

import java.util.Scanner;

public class MazeRunner {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: Number of rows and columns
        int R = scanner.nextInt();
        int C = scanner.nextInt();

        // Input: Maze
        int[][] maze = new int[R][C];
        for (int i = 0; i < R; i++) {
            for (int j = 0; j < C; j++) {
                maze[i][j] = scanner.nextInt();
            }
        }

        // Input: Starting point
        int startX = scanner.nextInt();
        int startY = scanner.nextInt();

        // Input: Target point
        int targetX = scanner.nextInt();
        int targetY = scanner.nextInt();

        // Output the result
        int result = shortestPath(maze, startX, startY, targetX, targetY, 0, 0);
        if (result == Integer.MAX_VALUE) {
            System.out.println("STUCK");
        } else {
            System.out.println(result);
        }

        scanner.close();
    }

    static int shortestPath(int[][] maze, int x, int y, int targetX, int targetY, int distance, int blocksWith2) {
        if (x == targetX && y == targetY) {
            return distance;
        }

        int[] dx = {0, 0, 1, -1};
        int[] dy = {1, -1, 0, 0};

        int R = maze.length;
        int C = maze[0].length;

        int minDistance = Integer.MAX_VALUE;

        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i];
            int ny = y + dy[i];

            if (nx >= 0 && nx < R && ny >= 0 && ny < C && maze[nx][ny] != 1) {
                int newBlocksWith2 = blocksWith2 + (maze[nx][ny] == 2 ? 1 : 0);
                if (newBlocksWith2 <= 2) {
                    maze[x][y] = 1; // Mark the current cell as visited

                    int result = shortestPath(maze, nx, ny, targetX, targetY, distance + 1, newBlocksWith2);
                    minDistance = Math.min(minDistance, result);

                    maze[x][y] = 0; // Backtrack - reset the cell to unvisited
                }
            }
        }

        return minDistance;
    }
}
