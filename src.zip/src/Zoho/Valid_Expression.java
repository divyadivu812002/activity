package Zoho;

import java.util.HashMap;

public class Valid_Expression {
    public static boolean operatorcheck(char[] arr,int n){
        for (int i = 0; i <n; i++) {
            if(arr[i]=='+' && arr[i+1]>='a' ){
                return true;
            }
        }
        return false;
    }
    public static boolean bracketcheck(char[] arr,int n){
        int op=0,cl=0,count=0;
        for (int st = 0,end=n-1; st <n; st++,end--) {
            if(arr[st]=='('){
                op++;
                count++;
            }
            else if(arr[st]==')'){
                op--;
                count++;
            }
        if(arr[end]=='('){
            cl++;
        }
        else if(arr[end]==')'){
            cl--;
        }
        }
        if(op==0 && cl==0 && count%2==0){
            return true;
        }
        else {
            return false;
        }
    }
    public static boolean isvalid(String str){
        char[] arr=str.toCharArray();
        int n=arr.length;
        if(operatorcheck(arr,n)&&(bracketcheck(arr,n))){
                return true;
            }
        return false;
    }
    public static void main(String[] args) {
        String str="(a+b)((a*c))";
        System.out.println(isvalid(str));
    }
}
