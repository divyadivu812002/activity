package Zoho;

import java.util.Arrays;

public class Merge_Sort {
    public static void main(String[] args) {
        int []arr1={3,3,4};
        int n1=arr1.length;
        int[] arr2={1,2,5,5,6,7,8};
        int[] arr3=new int[arr1.length+arr2.length];
        int first=0,second=0,n2=arr2.length,n3=arr3.length;
        System.out.println(n1+" "+n2+" "+n3+" "+Arrays.toString(arr3));
        if (arr1[0] < arr1[n1 - 1]) {
        for (int i = 0; i <n3; i++) {
            System.out.println("first,second"+first+" "+second);
            if (first < n1 && second < n2) {
                if (first >= n1-1) {
                    arr3[i] = arr2[second++];
                } else if (second >= n2 - 1) {
                    arr3[i] = arr1[first++];
                } else if (arr1[first] < arr2[second]) {
                    arr3[i] = arr1[first++];
                    System.out.print("f" + first + " " + i + " " + arr3[i]);
                    System.out.println();
                } else if (arr1[first] > arr2[second]) {
                    arr3[i] = arr2[second++];
                    System.out.print("s" + second + " " + i + " " + arr3[i]);
                    System.out.println();
                }
                if (first < n1 - 1 && arr1[first] == arr3[i]) {
                    first++;
                    continue;
                }
                if (second < n2 - 1 && arr2[second] == arr3[i]) {
                    second++;
                    continue;
                }
            }
            System.out.print(Arrays.toString(arr3));
        }
        }
    }
}
