package Zoho;
public class Spiral_Form {
    public static void main(String[] args) {
        int n=6;
        int m=7;
        char[][] arr=new char[m][n];
        int r=m,c=n;
        int k=0,l=0,i;
        char x='X';
        while (k<m && l<n){
            for (i=l;i<n;i++)
                arr[k][i]=x;
            k++;
            for (i=k;i<m;i++)
                arr[i][n-1]=x;
            n--;
            if(k<m){
                for (i=n-1;i>=l;i--)
                    arr[m-1][i]=x;
                m--;
            }
            if(l<n){
                for (i=m-1;i>=l;i--)
                    arr[i][l]=x;
                l++;
            }
            if(x=='X')
                x='O';
            else
                x='X';
        }
        for (i=0;i<r;i++){
            for (int j = 0; j <c; j++) {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }

    }
}
