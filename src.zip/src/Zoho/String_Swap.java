package Zoho;
public class String_Swap {
    static void swap(String[] str , int i){
        if(i >= 0) {
            System.out.print(str[i] + " ");
            swap(str, i - 1);
        }
    }
    public static void main(String[] args) {
        String[] str={"welcome","to","zoho"};
        swap(str , str.length - 1);
       // System.out.print(swap(str,str.length-1));
    }
}
