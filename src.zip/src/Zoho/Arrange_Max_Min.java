package Zoho;
import java.util.Arrays;
public class Arrange_Max_Min {
    public static void main(String[] args) {
        int[] arr={5,7,2,6,1,3,4};//7,1,6,2,5,3,4
        int n=arr.length,max=0,min=0,ind=0;
        for (int i = 0; i <n; i++) {
            max=0;min=Integer.MAX_VALUE;ind=i;
            for (int j = i; j <n; j++) {
                if (i % 2 == 0) {
                    if (arr[j] >max) {
                        max=arr[j];
                        ind=j;
                    }
                }
                else{
                    if (arr[j] < min ){
                       min=arr[j];
                       ind=j;
                    }
                }
            }
            System.out.println(arr[i]+" "+arr[ind]);
            int temp = arr[i];
            arr[i] = arr[ind];
            arr[ind] = temp;
            System.out.println(Arrays.toString(arr));
            }
        System.out.println(Arrays.toString(arr));
    }
}

