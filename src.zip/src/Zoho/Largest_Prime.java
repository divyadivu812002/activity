package Zoho;
public class Largest_Prime {
    static void prime(int n){
        int i;
        if(n<0)
            return ;
        int c=0;
        if(n==2 || n==3)
            return ;
        for (i = 2; i <n; i++) {
            if (n % i == 0) {
                c=1;
                break;
            }
//            else {
//                c=1;
//              //  System.out.println("Not");
//                break;
//            }
        }
        if(c==0){
            System.out.println("Yes"+" "+i);
        }
       // else
            prime(n-1);
    }
    public static void main(String[] args) {
        int n=15;
       //System.out.println(prime(n));
        prime(n);
    }
}
