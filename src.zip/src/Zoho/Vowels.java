package Zoho;
public class Vowels {
    public static void main(String[] args) {
        String str="string";
        System.out.println('c'-'a');
        int n=str.length();
        for(int i=0;i<n;i++){
            if(str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' || str.charAt(i)=='u'){
                System.out.print(str.charAt(i));
            }
            if(str.charAt(i)>'a' && str.charAt(i)<'e') {
                if (Math.abs(str.charAt(i) - 'a') > Math.abs(str.charAt(i) - 'e')) {
                    System.out.print("e");
                } else {
                    System.out.print("a");
                }
            }
                   else if (str.charAt(i)>'e' && str.charAt(i)<'i') {
                        if (Math.abs(str.charAt(i) - 'e') > Math.abs(str.charAt(i) - 'i')) {
                            System.out.print("i");
                        } else {
                            System.out.print("e");
                        }
                    }
                        else if(str.charAt(i)>'i' && str.charAt(i)<'o') {
                            if (Math.abs(str.charAt(i) - 'i') > Math.abs(str.charAt(i) - 'o')) {
                                System.out.print("o");
                            } else {
                                System.out.print("i");
                            }
                        }
                            else if(str.charAt(i)>'o' && str.charAt(i)<'u') {
                                if (Math.abs(str.charAt(i) - 'o') > Math.abs(str.charAt(i) - 'u')) {
                                    System.out.print("u");
                                } else {
                                    System.out.print("o");
                                }
                            }
                else if(str.charAt(i)>'u' && str.charAt(i)<'a') {
                    if (Math.abs(str.charAt(i) - 'u') > Math.abs(str.charAt(i) - 'a')) {
                        System.out.print("a");
                    } else {
                        System.out.print("u");
                    }
                }
            }
        }
    }
