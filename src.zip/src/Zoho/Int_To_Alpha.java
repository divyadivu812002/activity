package Zoho;

public class Int_To_Alpha {
        public static void numberToColumnLabel(int n) {
            if (n <= 0)
                return ;
            String result ="";
            while (n > 0) {
                n--;
                char letter = (char) ('A' + (n % 26));
                result+=letter;
                n /= 26; 
            }
            System.out.println(result);
            String rev="";
            for (int i = 0; i <result.length(); i++) {
                rev=result.charAt(i)+rev;
            }
            System.out.println(rev);
        }

        public static void main(String[] args) {
//            System.out.println(numberToColumnLabel(1));    // Output: "A"
//            System.out.println(numberToColumnLabel(26));   // Output: "Z"
//            System.out.println(numberToColumnLabel(27));   // Output: "AA"
//            System.out.println(numberToColumnLabel(28));   // Output: "AB"
            numberToColumnLabel(699); // Output: "ZZZ"
        }
    }
