package Zoho;

public class Possible_Paths {
    public static long numofpaths(long m,long n){
        if(m==1 || n==1)
            return 1;
        else
            return numofpaths(m-1,n)+numofpaths(m,n-1);
    }
    public static void main(String[] args) {
        long m=10,n=100000000;
        System.out.println(numofpaths(m,n));
    }
}
