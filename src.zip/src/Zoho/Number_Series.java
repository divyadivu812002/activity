package Zoho;
public class Number_Series {
    public static void main(String[] args) {
        int n=10,a;
        for (int i = 1; n!=0; i++) {
            a=i;
            int count=0;
            while (a>0){
                int rem=a%10;
                a=a/10;
                count++;
                if(rem==5||rem==9){
                    count--;
                }
            }
            if(count==0){
                System.out.println(i);
                n--;
            }
        }
    }
}
