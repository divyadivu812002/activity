package Zoho;

import java.util.Arrays;

public class Arranging {
    public static void main(String[] args) {
        int[] arr={4,2,3,1,5,6};
        int min, max, ind;
        for(int i=0;i<arr.length;i++){
            min=Integer.MAX_VALUE; max=0; ind=i;
            for(int j=i;j<arr.length;j++){
                if(i%2==0){
                    if(arr[j]<min && arr[j]%2==0){
                        min=arr[j];
                        ind=j;
                    }
                }
                else{
                    if(arr[j]>max && arr[j]%2!=0){
                        max=arr[j];
                        ind=j;
                    }

                }
            }
            int temp=arr[i];
            arr[i]=arr[ind];
            arr[ind]=temp;
        }
        System.out.println(Arrays.toString(arr));
    }
}
