package Zoho;

public class Sum_Groups {
    public static void main(String[] args) {
        int[] arr={ 3, 9, 7, 4, 6, 8};
        int x=3;
        for (int i=0;i<arr.length;i++){
            for (int j = i; j <arr.length; j++) {
                for (int k = i; k <arr.length; k++) {
                    if ((arr[i]) % 3 == 0 && (arr[i] + arr[k]) % x == 0) {
                        System.out.print(arr[i] + " "+arr[k]+" ");
                    }
                }
                System.out.println();
            }
        }
//        int res=Integer.parseInt(str);
//        System.out.println(res);
    }
}
