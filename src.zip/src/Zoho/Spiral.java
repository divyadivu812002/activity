package Zoho;

import java.util.Arrays;

public class Spiral {
    public static void main(String[] args) {
        int n=4;
        int m=4;
        int[][]arr=new int[n][m];
        int min_col=0,max_col=m-1, min_row=0, max_row=n-1;
        int val=16;
        while (val>=1) {
            for (int row = max_row; row >=min_row; row--) {
                arr[row][min_col] = val--;
            }
            min_col++;
            for (int col = min_col; col <= max_col; col++) {
                arr[min_row][col] = val--;
            }
            min_row++;
            for (int row = min_row; row <= max_row; row++) {
                arr[row][max_col] = val--;
            }
            max_col--;
            for (int col = max_col; col >= min_col; col--) {
                arr[max_row][col] = val--;
            }
            max_row--;

        }
        for (int i = 0; i <n; i++) {
            for(int j=0;j<m;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
}
