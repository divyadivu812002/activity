package Zoho;

import java.util.Scanner;

public class Int_To_Word {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        String str=String.valueOf(n);
        System.out.println(str);
        int l=str.length();
        String fin="",sub;
        int c,nn=0,nnn=0,subc;
        for (int i = l-1; i>=0; i--) {
            char cc=str.charAt(i);
            c=Integer.parseInt(String.valueOf(cc));
            String[] one={" ","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen",
                      "seventeen","eighteen","nineteen"};
        String[] two={" ","ten","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
        if(i>0){
            sub=str.substring(i-1,i+1);
            subc=Integer.parseInt(sub);
        }
        else{
            subc=22;
        }
        if(nnn==2){
            if(c!=0){
                fin="hundred "+fin;
            }
            nn=0;
        }
        if(nnn==3){
            if(c!=0){
                fin="thousand "+fin;
            }
            nn=0;
        }
        if(subc < 20 && nnn == 0){
            fin=one[subc]+" "+fin;
            nn++;nnn++;i--;
        }
        else if (subc<20 && nnn!=1 && nnn%2!=0) {
            fin=one[subc]+" "+fin;
            nn++;nnn++;i--;
        } else if (nn%2==0) {
            fin=one[c]+" "+fin;
        }
        else {
            fin=two[c]+" "+fin;
        }
        nn++;nnn++;
        }
        System.out.println(fin);

//        int first=n%10;
//        System.out.println(first);
//        n=n/10;
//        int sec=n%10;
//        int check=first+sec+9;
//        n=n/10;
//        int third=n;
//        System.out.println(check+" "+sec+" "+third);
//        String[] one={" ","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen",
//                      "seventeen","eighteen","nineteen",};
//        String[] two={" ","ten","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
//        String hun="hundred";
//        if(a<20)
//            System.out.println(one[a]);
//        else if(a<100)
//            System.out.println(two[sec]+" "+one[first]);
//        else if(check<20)
//            System.out.println(one[third]+" "+hun+" and "+two[sec]+" "+one[first]);
    }
}
