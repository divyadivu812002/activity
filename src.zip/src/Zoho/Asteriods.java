package Zoho;

import java.util.Arrays;

public class Asteriods {
    public static void main(String[] args) {
        int [] arr={10,-1,5,-2,-4};
        int n=arr.length;
        int count=0;
        for(int i=n-1;i>0;i--){
//            if(arr[i]>0 && arr[i-1] >0 && arr[i]>arr[i-1]){
//                arr[i-1]=arr[i];
//                arr[i]=0;
//            }
            if((arr[i]<0 && arr[i-1]>0)){
                arr[i]=Math.abs(arr[i]);
                System.out.println(arr[i]);
                if(arr[i]==arr[i-1]){
                    arr[i]=0;
                    arr[i-1]=0;
                    count+=2;
                }
                else if(arr[i]>arr[i-1]){
                    arr[i-1]=-(arr[i]);
                    arr[i]=0;
                    count++;
                }
                else{
                    arr[i]=0;
                    count++;
                }
            }
        }
        int[] arr2=new int[n-count];
        for (int i=0;i<arr2.length;i++){
            arr2[i]=arr[i];
        }
        System.out.println(Arrays.toString(arr2));
    }
}
