package Zoho;

public class Paranthesis {
    public static void main(String[] args) {
        String str="(((a)";//((abc)(de))
        char[] arr=str.toCharArray();
        int n=arr.length,open=0,close=0;
        int mid=arr.length/2;
        System.out.println(mid);
        for (int st= 0,end=n-1;  st<n; st++,end--) {
                if(arr[st]=='('){
                    open++;
                }
                else if(arr[st]==')'){
                    open--;
                }
                if(arr[end]==')'){
                    close++;
                }
                else if(arr[end]=='('){
                    close--;
                }
                if(arr[mid]=='('){
                    arr[mid]=',';
                }
                if(open<0){
                    arr[st]=',';
                    //System.out.print(open);
                    open=0;
                }
          //  System.out.println();
                if(close<0){
                    arr[end]=',';
                    //System.out.print(close);
                    close=0;
                }
        //    System.out.println();
        }
        for (char c : arr) {
            if (c != ',') {
                System.out.print(c);
            }
        }
        System.out.println();
    }
}
