package Zoho;

import java.util.Scanner;

public class Petrol {
    static int finale(int n,int[] dist,int[] pb){
        for (int i = 0; i < dist.length; i++) {
            if (n < dist[i]) {
                return 0;
            } else {
                int reach = reach(n, dist[i]);
                n = fill(reach, pb[i]);
            }
        }
        return n;
    }
    static int reach(int n,int i){
        return n-i;
    }
    static int fill(int n,int i){
        return n+i;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
       // char[] pb={'A','B','C'};
        int[] dist={1,5,5};
        int[] pb_capacity={6,4,0};
        int fin=finale(n,dist,pb_capacity);
        if(fin==0){
            System.out.println("You are drained out!!");
        }
        else
            System.out.println(fin);
    }
}
