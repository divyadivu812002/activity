package Zoho;
public class Pattern_XO {
    public static void main(String[] args) {
        int n=6;
        int m=7;
        int i, k = 0, l = 0;
        int r = m, c = n;
        char a[][] = new char[m][n];
        char x = 'X';
        while (k < m && l < n){
            for (i = l; i < n; i++)
                a[k][i] = x;
            k++;
            for (i = k; i < m; i++)
                a[i][n-1] = x;
            n--;
            if (k < m) {
                for (i = n-1; i >= l; i--)
                    a[m-1][i] = x;
                m--;
            }
            if (l < n) {
                for (i = m-1; i >= k; i--)
                    a[i][l] = x;
                l++;
            }
            if(x=='X')
                x='O';
            else
                x='X';
        }
        for (i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
                System.out.print(a[i][j] + " ");
            System.out.println();
        }
    }
}
