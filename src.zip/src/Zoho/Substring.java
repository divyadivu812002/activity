package Zoho;

public class Substring {
    public static int findsub(String str1, String str2) {
        int n = str1.length();
        int m = str2.length(),count=0;
        for (int i = 0; i < n; i++) {
            // if(str1.charAt(i)==str2.charAt(0)){
            for (int j = 0; j < m; j++) {
                if (str1.charAt(i) == str2.charAt(j)) {
                    count++;
                    if(count==m)
                        return i-count+1;
                }
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        String str1="test123str";
        String str2="123";
        System.out.println(findsub(str1,str2));
        //findsub(str1,str2);
    }
}
