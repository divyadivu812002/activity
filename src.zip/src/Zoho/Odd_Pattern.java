package Zoho;

public class Odd_Pattern {
    public static void main(String[] args) {
        int n = 5, v = 1, e = 2;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if ((n - 1 - i )>j) {
                    System.out.print(" ");
                } else
                if (i % 2 == 0) {
                    System.out.print(v+" ");
                    v += 2;
                } else {
                    System.out.print(e+" ");
                    e += 2;
                }
            }
            System.out.println();
        }
    }
}
