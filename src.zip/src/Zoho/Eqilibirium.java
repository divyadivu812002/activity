package Zoho;

public class Eqilibirium {
    static int equil(int[] arr, int n){
        int ls=arr[0],rs=arr[n-1];
        for (int i = 0,j=n-1; i <n;) {
            if(ls==rs){
                return i+1;
            } else if (ls<rs) {
                ls+=arr[i+1];
                i++;
            }
            else{
                rs+=arr[j-1];
                j--;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] arr={5,2,3,2,5};
        int n=arr.length;
        int res=equil(arr,n);
        System.out.println(res);
    }
}
