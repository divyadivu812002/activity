package Zoho;

public class Container_Water {
    public static void main(String[] args) {
        int[] arr={5,5,7,2,9,1,8};
        int samplemax=Integer.MIN_VALUE;
        int max=0;
        int left=0, right=arr.length-1;
        while(left<right){
           samplemax=(Math.abs(left-right)-1)*Math.min(arr[left],arr[right]);
           if(samplemax>max){
               max=samplemax;
           }
           if(arr[left]<arr[right]){
               left++;
           }
           else{
               right--;
           }
            }
        System.out.println(max);
        }
    }

