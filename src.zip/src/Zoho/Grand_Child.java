package Zoho;

public class Grand_Child {
    public static void main(String[] args) {
        String[][] str={
                {"shaw","rooney"},
                {"shaw","rooney"},
                {"rooney","ronaldo"},
                {"shaw","rooney"},
                {"luke","shaw"}
        };
        String find="ronaldo";
        int n=str.length,count=0;
        int m=str[0].length;
        for (int i = 0; i <n; i++) {
            for (int j = 0; j < m; j++) {
                if (str[i][j].equals(find)  && count<2) {
                    find = str[i][j - 1];
                    System.out.println(find);
                    count++;
                }
                if(count==2)
                    break;
            }
        }
        count=0;
        for (int i = 0; i <n; i++) {
            for (int j = 0; j <m; j=2) {
                if(str[i][j].equals(find)){
                    count++;
                    System.out.println(count);
                }
            }
        }

    }
}