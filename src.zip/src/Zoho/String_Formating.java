package Zoho;

public class String_Formating {
    public static String stringfunc(int st,int end,String str){
      //  System.out.println("1");
        String sub="";
        for (int i=st;i<st+end;i++){
            sub+=str.charAt(i);
        }
        return sub;
    }
    public static int intfunc(int st,int end,String str){
        int n=0;
        for(int i=st;i<st+end;i++){
            int num=str.charAt(i)-'0';
            n=n*10+num;
        }
        return n;
    }
    public static void main(String[] args) {
        String str="05knows124006sanjay";
        String st;
     //   System.out.println('5'-'0');
        for (int i = 0; i <str.length()-1;) {
            if(str.charAt(i)=='0') {
                int start=i+2;
               // System.out.println(i);
                //System.out.println(Character.getNumericValue(str.charAt(++i)));
                int end=str.charAt(i+1)-'0';
                st=stringfunc(start,end,str);
                i= start+end;
                if (i-1==str.length()-1)
                    System.out.print("\""+st+"\"");
                else
                    System.out.print("\""+st+"\""+",");
            }
           // i++;
                 else if (str.charAt(i)=='1'){
                    int start=i+2;
                    int end=str.charAt(i+1)-'0';
                    int num=intfunc(start,end,str);
                    i=start+end;
                    if(i-1==str.length()-1)
                        System.out.print(num);
                    else
                        System.out.print(num+",");
                }
        }
    }
}
