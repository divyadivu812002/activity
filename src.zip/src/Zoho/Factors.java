package Zoho;

import java.util.Arrays;

public class Factors {
    static int factors(int cur){
        int count=0;
        for (int i = 1; i <cur; i++) {
            if(cur%i==0){
               // System.out.print(i+" ");
                count++;
            }
        }
      //  System.out.println();
        return count;
    }
    static void swap(int[] arr,int j){
        int temp=arr[j];
        arr[j]=arr[j+1];
        arr[j+1]=temp;
    }
    public static void main(String[] args) {
        int[] arr={8,2,3,12,16};
        int[] count=new int[arr.length];
        for (int i = 0; i <arr.length; i++) {
            int cur=arr[i];
            count[i]=factors(cur);
        }
        System.out.println(Arrays.toString(count));
        for (int i = 0; i <count.length; i++) {
            for (int j = 0; j <count.length-1; j++) {
                if (count[j]<count[j+1]){
                    swap(arr,j);
                    swap(count,j);
                }
            }
        }
        System.out.print(Arrays.toString(arr)+" "+Arrays.toString(count));
        }
    }

