package Zoho;

public class String_Rev {
    public static void main(String[] args) {
        String str="today is a good day";
        int n=str.length();
        int i=n-1;
        for (int j=0; j<n; ) {
            if(str.charAt(j)==' '){
                System.out.print(' ');
                j++;
            }
            else if(str.charAt(j)!=' ' && str.charAt(i)!=' '){
                System.out.print(str.charAt(i));
                i--;j++;
            } else if (str.charAt(j)!=' ' && str.charAt(i)==' ') {
                i--;
            }
        }
    }
}
