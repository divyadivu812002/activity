package Accenture;

import java.util.ArrayList;

public class Lexi {
    public static void main(String[] args) {
        int n=2;
        ArrayList<Integer> arr=new ArrayList<>(n);
        int cur=1,temp=1;
        while(cur<=n){
            if(arr.size()>n){
                break;
            }
            while(cur<=n){
                if(arr.size()>=n){
                    break;
                }
                arr.add(cur);
                if(cur*10<=n){
                    cur*=10;
                }
                else{
                    cur++;
                }
            }
            temp++;
            cur=temp;
        }
//        return arr;
        System.out.print(arr);
    }
}
