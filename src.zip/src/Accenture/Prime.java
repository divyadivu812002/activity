package Accenture;

public class Prime {
    static void printPrimes(int n){
        boolean arr[]=new boolean[n+1];
        for(int i=2;i*i<=n;i++){
            if(arr[i]==false){
                for(int j=i*i;j<=n;j=j+i){
                    arr[j]=true;
                }
            }
        }
        for(int i=2;i<n;i++){
            if(arr[i]==false)
                System.out.print(i+" ");
        }
    }
    public static void main(String[] args) {
        int n=30;
        printPrimes(n);
    }
}
