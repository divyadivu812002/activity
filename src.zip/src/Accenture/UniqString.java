package Accenture;

public class UniqString {
    public static void main(String[] args) {
        String str = "sanjay";
        int n = str.length();
        String res = "";
        int count = 0;

        for (int i=0; i<n;i++){
            boolean flag=false;
            for (int j=0;j<count;j++){
                if (str.charAt(i)==res.charAt(j)){
                    flag=true;
                    break;
                }
            }
            if(!flag){
                res=res+str.charAt(i);
                count++;
            }
        }
        System.out.println(res);
    }
}
