package Accenture;

public class Password {
    public static int solve(String str,int n){
        boolean numflg=false,capflg=false;
        if(n>=4 && !Character.isDigit(str.charAt(0))){
            for (int i = 0; i <n; i++) {
                char cas = str.charAt(i);
                if (str.charAt(i) >= '0' && str.charAt(i) <= '9')
                    numflg = true;
                else if (Character.isUpperCase(cas))
                    capflg= true;
                else if (str.charAt(i)==' ' || str.charAt(i)=='/') {
                    return 0;
                }
                if(numflg && capflg)
                    break;
            }
            if(numflg && capflg)
                return 1;
          //  System.out.println(flg);
                }
        return 0;
    }
    public static void main(String[] args) {
        String str="aAcv2c";
        int n=str.length();
        System.out.println(solve(str,n));
    }
}
