package Accenture;

public class Carry {
    public static void  solve(int a,int b){
        a=a^b;
        b=a^b;
        a=a^b;
        System.out.println(a+" "+b);
    }
    public static void main(String[] args) {
        int a=1,b=2;
        //System.out.println(solve(a,b));
        solve(a,b);
    }
}
