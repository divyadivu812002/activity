package Accenture;
public class Equilibirium {
       static int equilibrium(int[] arr, int n)
        {
            int j,totalsum, leftsum;
                totalsum = 0;
                for ( j = 0; j < n; j++)
                    totalsum += arr[j];
                leftsum = 0;
                for (j = 0; j < n; j++) {
                    totalsum -= arr[j];
                    if (totalsum == leftsum)
                        return arr[j];
                    leftsum += arr[j];
                }
            return -1;
        }
        public static void main(String[] args) {
            int[] arr = {1,2,3};
            int arr_size = arr.length;
            System.out.println(equilibrium(arr, arr_size));
        }
    }


