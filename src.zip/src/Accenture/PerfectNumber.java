package Accenture;

public class PerfectNumber {
    public static void main(String[] args) {
        int n=6;
        int sum=0;
        int i=0;
        for(i=1;i*i<=n;i++){
            if(n%i==0 ){
                sum+=i;
                if(i!=n/i && n/i !=n){
                    sum=sum+n/i;
                }
            }
        }
        System.out.println(sum);
    }
}
