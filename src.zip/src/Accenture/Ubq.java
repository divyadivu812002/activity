package Accenture;

public class Ubq {
    public static void main(String[] args) {
        int[] arr = {2,7,4,5};
        int n = arr.length;
        int max = Integer.MIN_VALUE;
        int j=1;
        for (int i = 0; i < n-1;) {
            if(arr[i]+arr[j]>max){
                max=arr[i]+arr[j];
            }
            j++;
            if(j==n){
                i++;
                j=i+1;
            }
        }
        System.out.println(max);
    }
}
