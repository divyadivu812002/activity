package Accenture;

public class Rat {
    public static int solve(int r,int u,int[] arr){
        int n=arr.length;
        int total=r*u,count=0,sum=0;
        for (int i = 0; i <n; i++) {
             if(sum<=total){
                sum+=arr[i];
                count++;
            }
        }
        if(sum==0)
            return -1;
        if(sum<total)
            return 0;
        return count;
    }
    public static void main(String[] args) {
        int rat=6,unit=2;
        //int[] arr=new int[n];
        int[] arr={4,3,2,3,1};
        System.out.println(solve(rat,unit,arr));

    }
}
