package Accenture;

public class Arrange {
    public static boolean canArrange(int[] arr, int k) {
        int n=arr.length;
        for(int i=0,j=n-1;i<n/2;i++,j--){
            if((arr[i]+arr[j])%k!=0)
                return false;
        }
        return true;
    }

    public static void main(String[] args) {
        int[] arr={-1,1,-2,2,-3,3,-4,4};
        int k=3;
        System.out.println(canArrange(arr,k));
    }
}
