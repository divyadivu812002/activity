package Accenture;

public class GcdHcf {
    public static void main(String[] args) {
        int n = 15, m = 20;
        while (n!=0 && m!=0) {
            if (n > m) {
                n = n % m;
            } else {
                m = m % n;
            }
        }
        System.out.println(n==0?m:n);
//        System.out.println(n);
//        int len = n < m ? n : m;
//        System.out.println(len);
//        for(int i=len;i>=1;i--){
//            if(n%i==0 && m%i==0){
//                System.out.println(i);
//                break;
//            }
//        }
    }
}
