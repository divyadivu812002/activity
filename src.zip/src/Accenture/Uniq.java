package Accenture;

import java.util.Arrays;

public class Uniq {
    static void uniqArray(int[] arr){
        int n=arr.length;
        int[] res=new int[n];
        int count=0;
        for(int i=0;i<n;i++){
            int flag=1;
            for(int j=0;j<i;j++){
                if(arr[i]==res[j]){
                    flag=0;
                }
            }
            if(flag==1){
                res[count]=arr[i];
                count++;
            }
        }
        for(int i=0;i<count;i++){
            System.out.print(res[i]+" ");
        }
    }
    static void uniqString(String str){
        String res="";
        for (int i=0;i<str.length();i++){
            if(res.indexOf(str.charAt(i))==-1){
                res=res+str.charAt(i);
            }
        }
        System.out.print(res+" ");
    }

    public static void main(String[] args) {
        int[] arr={1,2,3,2,4,4,5};
        String str="sanjay";
//        uniqArray(arr);
//        uniqString(str);
    }
}
