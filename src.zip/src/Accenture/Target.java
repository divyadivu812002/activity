package Accenture;

import java.util.Arrays;

public class Target {
    public static void main(String[] args) {
        int nums[]={5,8,8,9};
        int target=8;
        int arr[]={-1,-1};
        int count=0;
        int n=nums.length;
        for(int i=0;i<n;i++){
            if(nums[i]==target && count==0){
                arr[0]=i;
                count=1;
            }
            if(nums[i]==target && i<n-1){
                arr[1]=i;
            } else if (i==n-1 && nums[i]==target) {
                arr[1]=i;
            }
        }
        System.out.println(Arrays.toString(arr));
//        return arr;
    }
}
