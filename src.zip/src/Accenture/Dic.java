package Accenture;

public class Dic {

    // Helper function to check if the substring exists in the array
    public static boolean isarr(String str, String[] arr) {
        for (int i = 0; i < arr.length; i++) {
            if (str.equals(arr[i])) {
                System.out.println("Equal " + str);
                return true;
            }
        }
        return false;
    }

    // Function to minimize the extra characters
    public static int minExtraChar(String s, String[] arr) {
        int n = s.length();
        boolean[] used = new boolean[n]; // To mark used characters and avoid overlaps
        int len = 0;

        // Loop over substring sizes
        for (int size = n; size >= 1; size--) { // Start from longest possible substrings
            for (int i = 0; i <= n - size; i++) {
                String sub = s.substring(i, i + size);

                // Check if the substring is in the dictionary and has not been used
                if (isarr(sub, arr)) {
                    boolean canUse = true;
                    // Ensure no part of this substring has been counted already
                    for (int j = i; j < i + size; j++) {
                        if (used[j]) {
                            canUse = false;
                            break;
                        }
                    }

                    // If it's a valid substring, mark it as used and add its length
                    if (canUse) {
                        System.out.println("lem " + len + " " + sub.length());
                        len += sub.length();
                        // Mark this range as used
                        for (int j = i; j < i + size; j++) {
                            used[j] = true;
                        }
                    }
                }
            }
            System.out.println("length " + len);
        }

        return n - len;
    }

    public static void main(String[] args) {
        String[] str = {"ix","qoqw","ax","ar","v","hxpl","nxcg","thr","kod","pns","cdo","euy","es","rf","bxcx","xe","ua","vws","vumr","zren","bzt","qwxn","ami","rrbk","ak","uan","g","vfk","jxmg","fhb","nqgd","fau","rl","h","r","jxvo","tv","smfp","lmck","od"};
        String name = "aakodubkrlauvfkzje";
        int n = minExtraChar(name, str);
        System.out.println(n); // Expected output: 7
    }
}
