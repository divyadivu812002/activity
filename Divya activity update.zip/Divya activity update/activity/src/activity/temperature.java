package activity;

public class temperature {
	public void checktemp(int degree) {
		if(degree>30) {
			System.out.println("Hot");
		}
		else if(degree>20 && degree<30) {
			System.out.println("humid");
		}
		else if(degree>10 && degree<20) {
			System.out.println("cold");
		}
		else {
			System.out.println("Freezing");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		temperature temp=new temperature();
		temp.checktemp(35);
		temp.checktemp(5);
		temp.checktemp(28);
		temp.checktemp(16);
		temp.checktemp(50);

	}

}
