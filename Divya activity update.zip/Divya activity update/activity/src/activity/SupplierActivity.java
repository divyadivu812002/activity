package activity;
import java.util.function.*;
import java.util.*;
class Item{
	private String itemName;
	private float price;
	public Item(String itemName, float price) {
		super();
		this.itemName = itemName;
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String toString() {
		return "ItemName: "+itemName+"Price: "+price;
	}
}
class Stock{
	List<Item> itemList=new ArrayList();
	Stock(){
		itemList.add(new Item("Coffe",20));
		itemList.add(new Item("Tea",10));
		itemList.add(new Item("Ice Tea",23));
	}
	public String toString() {
		return "ItemList"+itemList;
	}
}

public class SupplierActivity {
	public void supplyStock(Supplier<Stock>supplier) {
		System.out.println(supplier.get());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SupplierActivity obj=new SupplierActivity();
		obj.supplyStock(()->new Stock());
	
	}

}
