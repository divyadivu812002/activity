package activity;

import java.util.Scanner;

public class SnakeAndLadder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int playerPosition=1;
		int diceRoll;
		while(playerPosition<100) {
			System.out.println("Current Position: "+playerPosition);
			System.out.println("Enter dice roll(1-6):");
			diceRoll=sc.nextInt();
			while(diceRoll<1||diceRoll>6) {
				System.out.println("Invalid input please enter a num between 1 and 6: ");
			diceRoll=sc.nextInt();
			}
			playerPosition+=diceRoll;
			System.out.println("You rolled: "+diceRoll);
			if(playerPosition==4) {
				playerPosition=14;
				System.out.println("Climbed ladder to: "+playerPosition);
			}
			else if(playerPosition==9) {
				playerPosition=31;
				System.out.println("climbeed ladder to:"+playerPosition);
			}
			else if(playerPosition==17){
				playerPosition=7;
				System.out.println("Slid down snake to: "+playerPosition);
				
			}else if(playerPosition==54) {
				playerPosition=34;
				System.out.println("Slid down snake to:"+playerPosition);
			}
			if(playerPosition>=100) {
				System.out.println("Congratulations!You won");
				break;
			}
			
		}

	}

}
