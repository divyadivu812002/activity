package activity;

public class tenevennum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;for(i=1;i<=20;i++) {
			if(i%2==0) {
				System.out.println(i+" ");
			}
		}

	}

}
