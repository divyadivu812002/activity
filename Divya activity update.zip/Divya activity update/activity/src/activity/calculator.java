package activity;

public class calculator {
	static int P;
	static float R;
	static int T;
	static double Interest;
	static {
		P=100;
		R=0.05f;
		T=2;
	}
	static void Simple() {
		 Interest=P*R*T;
		 System.out.println(Interest);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calculator obj=new calculator();
		obj.Simple();
		
		

	}

}
