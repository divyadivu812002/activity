package activity;

public class Studentactivity {
	String StudentName;
	String address;
	int age;
	static int marks;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Studentactivity s=new Studentactivity();
		s.StudentName="Divya";
		s.address="egattur";
		s.age=22;
		s.marks=60;
		boolean passed=(marks>35)?true:false;
		System.out.println(passed);
		

	}

}
