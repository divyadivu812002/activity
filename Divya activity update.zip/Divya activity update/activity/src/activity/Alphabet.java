package activity;

public class Alphabet {
	//char letter;
	public static void findalpha(char letter) {
		switch(letter) {
		case 'a':
			System.out.println("vowel");
		break;
		case 'e':
			System.out.println("vowel");
		break;
		case 'i':
			System.out.println("vowel");
		break;
		case 'o':
			System.out.println("vowel");
		break;
		case 'u':
			System.out.println("vowel");
		break;
		case 'A':
			System.out.println("vowel");
		break;
		case 'E':
			System.out.println("vowel");
		break;
		case 'I':
			System.out.println("vowel");
		break;
		case 'O':
			System.out.println("vowel");
		break;
		case 'U':
			System.out.println("vowel");
		break;
		default:
			System.out.println("consonants");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Alphabet a=new Alphabet();
		a.findalpha('a');
		a.findalpha('p');

	}

}
