package activity;
//COMPARABLE ACTIVITY
import java.util.TreeSet;

public class Student implements Comparable<Student>{
	private String studentName;
	private float marks;
	public int compareTo(Student student) {
		if(this.getMarks()==student.getMarks()) {
	    	return 0;
	    }else {
	    	if(this.getMarks()<student.getMarks()) {
	    		return 1;
	    	}else {
	    		return -1;
	    	}
	    }
	}
	public Student() {}
  public Student(String studentName,float marks) {
	   super();
	   this.studentName=studentName;
	   this.marks=marks;
  }
	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public float getMarks() {
		return marks;
	}

	public void setMarks(float marks) {
		this.marks = marks;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Student> set=new TreeSet<Student>();
		set.add(new Student("Divya",88));
		set.add(new Student("Priya",99));
		set.add(new Student("Sita",60));
		set.add(new Student("Ananya",40));
		for(Student student:set) {
			System.out.println(student.getStudentName()+" "+student.getMarks());
		
}

	}

	}

