package activity;


	enum WeekDays{
		SUNDAY,
		MONDAY,
		TUESDAY,
		WEDNESDAY,
		THURSDAY,
		FRIDAY,
		SATURDAY
	}
	public class enumactivity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WeekDays W=WeekDays.MONDAY;
		System.out.println(W);

	}

}
