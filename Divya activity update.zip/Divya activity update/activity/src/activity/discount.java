package activity;

public class discount {
	public double returnDiscount(double price) {
		double finalprice=price*12/100;
		return finalprice;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		discount d=new discount();
		double result=d.returnDiscount(100);
		System.out.println(result);

	}

}
