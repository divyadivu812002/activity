package activity;
import java.util.Scanner;

public class MaxNumberFinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int max=Integer.MIN_VALUE;
		int number;
		System.out.println("enter 10 num: ");
		for(int i=1;i<=10;i++) {
			System.out.println("Number"+i+":");
			number=sc.nextInt();
			if(number>max) {
				max=number;
			}
		}
		System.out.println("Maximum value is: "+max);

	}

}
