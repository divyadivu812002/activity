package activity;

public class Game {
	public int gameScore(int score) {
		switch(score) {
		case 1:
		 return 2;
		case 4:
			return 8;
		case 6:
			return 12;
		default:
			return 0;
		
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game g=new Game();
		int res1=g.gameScore(1);
		int res2=g.gameScore(6);
		int res3=g.gameScore(4);
		int res4=g.gameScore(6);
		int res5=g.gameScore(6);
		int result=res1+res2+res3+res5;
		if(result>50) {
			System.out.println("You Won!");
		}
		else if(result>30) {
			System.out.println("You can practice more");
		}
		else {
			System.out.println("you are a loser!");
		}
	}

}
