package activity;
import java.util.function.*;
import java.util.*;
class Customer{
	private String customerName;
	private String customerAddress;
	private List<Product>productList;
	public Customer(String customerName, String customerAddress, List<Product> productList) {
		super();
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.productList = productList;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public List<Product> getProductList() {
		return productList;
	}
	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	public String toString() {
		return "Customer Name: "+customerName+"Customer Addres: "+customerAddress;
	}
}
class Product{
	private String productName;
	private float price;
	public Product(String productName, float price) {
		super();
		this.productName = productName;
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
}
public class supplieractivity1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
