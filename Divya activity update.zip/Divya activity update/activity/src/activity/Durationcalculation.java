package activity;
import java.time.LocalTime;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Durationcalculation {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalTime startTime=LocalTime.now();
		Scanner sc=new Scanner(System.in);
        int endhour=sc.nextInt();
        int endminute=sc.nextInt();
        int endsecond=sc.nextInt();
        LocalTime endTime=LocalTime.of( endhour, endminute,endsecond);
        Duration duration=Duration.between(startTime, endTime);
        System.out.println(duration);
        long hrs=ChronoUnit.HOURS.between(startTime,endTime);
System.out.println(hrs);
	}

}
