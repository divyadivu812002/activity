package activity;

public class average {
public void area(float radius) {
	System.out.println(3.14*radius*radius);
}
public void square(int number) {
	System.out.println(number*number);
}
public void average(int a,int b, int c,int d,int e) {
	System.out.println((a+b+c+d+e)/5);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		average a=new average();
		a.area(4);
		a.square(5);
		a.average(5, 10, 15, 20, 25);

	}

}
