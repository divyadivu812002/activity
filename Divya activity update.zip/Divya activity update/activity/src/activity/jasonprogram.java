package activity;

public class jasonprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int age=25;
        int marks=90;
        int experience=5;
        if(age>23 && marks>70 && experience>3) {
        	System.out.println(true);
        }
        else {
        	System.out.println(false);
        }
	}

}
