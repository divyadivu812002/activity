package activity;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;

public class Stringtokenizerdemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String input="A quick brown fox jumped over a fence .2 boys saw the fox they ran to 1 farmer and brought 2 sticks.There were 10 chickens inside a barn.The boys shouted ,and 3 farmers appeared ";
		StringReader reader=new StringReader(input);
		StreamTokenizer tokenizer=new StreamTokenizer(reader);
		int token;
		int wordcount=0;
		int numcount=0;
		while((token=tokenizer.nextToken())!=StreamTokenizer.TT_EOF) {
			switch(token) {
			case StreamTokenizer.TT_WORD:
				wordcount++;
				break;
			case StreamTokenizer.TT_NUMBER:
				numcount++;
				break;
			
			}
		}
		System.out.println("wordcount= "+wordcount);
		System.out.println("numbercount= "+numcount);

	}

}
