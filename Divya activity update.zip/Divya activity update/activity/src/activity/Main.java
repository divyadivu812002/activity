package activity;

public class Main {
	static int basic=1200;
	static int da=3%basic;
	static int hra=5%basic;
	static int pt=5%basic;
	static int ptax=5%basic;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int res=basic+da+hra-pt-ptax;
   System.out.println(res);
		
	}

}
