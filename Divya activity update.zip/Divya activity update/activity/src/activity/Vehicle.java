package activity;

import java.util.Comparator;
import java.util.TreeSet;

//import startProject.Employee;
//import startProject.SortbySalary;



class veh{
	private double distance;
	private double Time;
	private double Speed;
	public veh() {}
	public veh(double distance, double time ){
		super();
		this.distance = distance;
		this.Time = time;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public double getTime() {
		return Time;
	}
	public void setTime(double time) {
		Time = time;
	}
	public double getSpeed() {
		if(Time==0) {
			return 0;
		}else
			return distance/Time;
	}
	
}


public class Vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				TreeSet<veh> set=new TreeSet(new SortbySpeed());
				set.add(new veh (24,2));
				
				set.add(new veh (34,2));
				set.add(new veh (65,5));
				for(veh v:set) {
				System.out.println(v.getSpeed());
				}
			}

		}

		class SortbySpeed implements Comparator<veh>{
			public int compare(veh v1,veh v2) {
				if(v1.getSpeed()==v2.getSpeed()) {
					return 0;
				} else {
					if(v1.getSpeed()<v2.getSpeed()) {
						return -1;
					} else {
						return 1;
					}
				}
			
	}

}
