package activity;

public class Employees {
	String employeeName;
	String address;
	String contactNumber;
	int age;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employees e=new Employees();
		e.employeeName="Divya";
		e.address="egattur";
		e.contactNumber="76526562767";
		e.age=22;
		System.out.println(e.employeeName+" "+e.address+" "+e.contactNumber+" "+e.age);
		

	}

}
