package activity;

public class Customer {
private String customerName;
private String address;

public Customer(String customerName, String address) {
	super();
	this.customerName = customerName;
	this.address = address;
}

public String getCustomerName() {
	return customerName;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "Custometer Name:" +customerName+"Adress:"+address;
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer=new Customer("Peter","23 Old Baker Street");
		
System.out.println(customer.toString());
	}

}
