package activity;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
		String str="MALAYALAM";
		builder.append(str);
		String str1=builder.reverse().toString();
		if(str.equals(str1)) {
			System.out.println("palindrome");
		}
		else {
			System.out.println("not a palindrome");
		}

	}

}
