package activity;

import java.util.TreeMap;
import java.util.Map.Entry;

class AssetTy implements Comparable<AssetTy>{
	private String assetId;
	
	

    public AssetTy() {
    	
    }
	public AssetTy(String assetId) {
		
		this.assetId = assetId;
	}



	public String getAssetId() {
		return assetId;
	}



	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public int compareTo(AssetTy a) {
		
		return this.assetId.compareTo(a.assetId);
	}
}
class Employee{
	String employeeName;


	public Employee(String employeeName) {
		super();
		this.employeeName = employeeName;
	}



	public String getEmployeeName() {
		return employeeName;
	}



	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

public class AssetType{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				TreeMap <AssetTy,Employee> map=new TreeMap();
				map.put(new AssetTy("E001"), new Employee("Peter"));
				map.put(new AssetTy("F002"), new Employee("Sam"));
				map.put(new AssetTy("HCL003"),new Employee("Erric"));
				map.put(new AssetTy("LEN04"), new Employee("Simond"));
				map.put(new AssetTy("DELL05"), new Employee("Wiliam"));
				map.put(new AssetTy("HP006"), new Employee("Kathy"));
				for(Entry<AssetTy,Employee> a:map.entrySet()) {
					System.out.println(a.getKey().getAssetId()+" "+a.getValue().getEmployeeName());
				}

	}

}
}
