package activity;
import java.text.NumberFormat;
import java.util.Locale;

public class numformat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double number=347.45;
		double numbers=12.45;
		NumberFormat japancurrency=NumberFormat.getCurrencyInstance(Locale.JAPAN);
		String num=japancurrency.format(number);
		System.out.println("japancurrency: "+num);
		NumberFormat chinacurrency=NumberFormat.getCurrencyInstance(Locale.CHINA);
		String num1=chinacurrency.format(number);
		System.out.println("chinacurrency: "+num1);
		NumberFormat francecurrency=NumberFormat.getCurrencyInstance(Locale.FRANCE);
		String num2=francecurrency.format(number);
System.out.println("francecurrency: "+num2);
NumberFormat formatter1=NumberFormat.getPercentInstance();
String n=formatter1.format(numbers);
formatter1.setMinimumFractionDigits(2);
System.out.println("percentage: "+formatter1.format(numbers/100));
	}

}
