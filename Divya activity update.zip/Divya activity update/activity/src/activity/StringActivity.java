package activity;

public class StringActivity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="peter,erric,simond,school";
		String[] seperate=s.split(",");
		String sep=String.join("", seperate);
		System.out.println("TotalWords"+sep.length());
		int count=0;
		int sum=0;
		for(char se:sep.toCharArray()) {
		if(se=='a'||se=='e'||se=='i'||se=='o'||se=='u'||se=='A'||se=='E'||se=='I'||se=='O'||se=='U') {
		count++;
		}
		
		else {
			sum++;
		}
		

	}
		System.out.println("vowelcount: "+count);
		System.out.println("consonantcount: "+sum);
	}

}
