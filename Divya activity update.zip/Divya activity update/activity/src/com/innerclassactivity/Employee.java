package com.innerclassactivity;

public class Employee {
	String employeename;
 String departmentname;
 

	Attendance obj=new Attendance();
static class Attendance{
	public void marked(String employeename, String departmentname) {
		
		System.out.println("EmployeeName: "+employeename+"DepartmentName: "+departmentname);
	}
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee.Attendance e=new Employee.Attendance();
		e.marked("Divya", "IT");
		e.marked("Priya", "Dev");
		e.marked("Madhu", "IT");
		e.marked("Subha", "Dev");
		
		

	}

}
