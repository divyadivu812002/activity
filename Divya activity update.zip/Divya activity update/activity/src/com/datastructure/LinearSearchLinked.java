package com.datastructure;
import java.util.Scanner;

class Node2{
	int data;
	Node2 next;
	public Node2(int data,Node2 next) {
		this.data=data;
		this.next=next;
	}
}

public class LinearSearchLinked {
	
Node2 Start;
LinearSearchLinked(){
	Start=null;
}
	public void add(int data)
	{
		Node2 n=new Node2(data,null);
		
		if(Start==null)
		{
		    Start=n;
		    
	        return;
		}
		else
		{
			 Node2 curr;
			 for(curr=Start;curr.next!=null;curr=curr.next)
			 {
				
			 }
			  curr.next=n;		   	
		}	
	}
public void linearSearch(int value) {
	Node2 curr=Start;
	int flag=0;
	while(curr!=null) {
		if(curr.data==value) {
			System.out.println("Found");
			flag++;
			break;
			
		}
		curr=curr.next;
		flag++;
	}if(curr==null) {
		System.out.println("Not found");
	}
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinearSearchLinked l=new LinearSearchLinked();
		l.add(1);
		l.add(5);
		l.add(98);
		l.add(7);
		l.add(42);
		l.add(12);
		l.add(15);
		l.add(16);
		Scanner sc=new Scanner(System.in);
		int value=sc.nextInt();
		l.linearSearch(value);

	}

}
