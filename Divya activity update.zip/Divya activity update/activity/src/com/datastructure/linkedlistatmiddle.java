package com.datastructure;
class Studen{
	private String studentName;
	private float marks;
	public Studen(String studentName, float marks) {
		super();
		this.studentName = studentName;
		this.marks = marks;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Name: "+studentName+" ,Marks: "+marks;
	}
}
class Nod
{
	 Studen student;
	 Nod next;
	public Nod(Studen student,Nod next)
	{
		this.student=student;
	   this.next=next;
	   
	}
}

public class linkedlistatmiddle{
	

	 Nod START;
	 linkedlistatmiddle()
	 {
		 START=null;
	 }
	
	public void add(Studen student)
	{
		Nod n=new Nod(student,null);
		
		if(START==null)
		{
		   
		
		    START=n;
		    
	        return;
		}
		else
		{
			 Nod curr;
			 for(curr=START;curr.next!=null;curr=curr.next)
			 {
				
			 }
			  curr.next=n;
			   
			
		}	
		
	}
	
		
	public void traverse()
	{
		  Nod temp;
		  for(temp=START;temp!=null;temp=temp.next)
		  {
			  System.out.println(temp.student);
		  }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		linkedlistatmiddle obj=new linkedlistatmiddle();
		obj.add(new Studen("Divya",99.9f));
		obj.add(new Studen("priya",99.9f));
		obj.add(new Studen("madhu",99.9f));
		//System.out.println("Student List");
		obj.traverse();		

	}

}

