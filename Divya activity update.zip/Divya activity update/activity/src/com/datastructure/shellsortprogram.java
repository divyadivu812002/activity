package com.datastructure;
public class shellsortprogram {
	public static void shellSort(int[] arr) {
		int gap=arr.length/2;
		while(gap>0) {
			for(int i=gap;i<arr.length;i++) {
				int temp=arr[i];
				int j=i;
				while(j>=gap && arr[j-gap]>temp) {
					arr[j]=arr[j-gap];
					j-=gap;
				}
				arr[j]=temp;
			}
			gap/=2;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {5,2,8,1,9};
		shellSort(arr);
		for(int num:arr){
			System.out.print(num+" ");
			
		}

	}

}
