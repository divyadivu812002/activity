package com.datastructure;
class Student{
	private String studentName;
	private float marks;
	public Student(String studentName, float marks) {
		super();
		this.studentName = studentName;
		this.marks = marks;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Name: "+studentName+" ,Marks: "+marks;
	}
}
class Node
{
	 Student student;
	 Node next;
	public Node(Student student,Node next)
	{
		this.student=student;
	   this.next=next;
	   
	}
}

public class linkedliststudent {
	

	 Node START;
	 linkedliststudent()
	 {
		 START=null;
	 }
	
	public void add(Student student)
	{
		Node n=new Node(student,null);
		
		if(START==null)
		{
		   
		
		    START=n;
		    
	        return;
		}
		else
		{
			 Node curr;
			 for(curr=START;curr.next!=null;curr=curr.next)
			 {
				
			 }
			  curr.next=n;
			   
			
		}	
		
	}
		
	public void traverse()
	{
		  Node temp;
		  for(temp=START;temp!=null;temp=temp.next)
		  {
			  System.out.println(temp.student);
		  }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		linkedliststudent obj=new linkedliststudent();
		obj.add(new Student("Divya",99.9f));
		obj.add(new Student("priya",99.9f));
		obj.add(new Student("madhu",99.9f));
		//System.out.println("Student List");
		obj.traverse();		

	}

}
