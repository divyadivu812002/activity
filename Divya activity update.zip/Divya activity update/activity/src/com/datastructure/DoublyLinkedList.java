package com.datastructure;

class Nodes
{  
	  int data;
	  Nodes prev,next;
	  public Nodes(int data,Nodes prev,Nodes next)
	  {
		  this.data=data;
		  this.prev=prev;
		  this.next=next;
	  }
}
public class DoublyLinkedList {
 
	 Nodes START,LAST;
	
	   public DoublyLinkedList()
	   {
		    START=LAST=null;
	   }
	   
	    public void add(int data)
	    {
	    	Nodes n=new Nodes(data,null,null);
	    	 if(START==null&&LAST==null)
	    	 {
	    		  START=LAST=n;
	    		  return;
	    	 }
	    	 else
	    	 {
	    		 START.next=n;
	    		 n.prev=START;
	    		 START=n;
	    	 }
	    	
	    	
	    }
	    public void traverse()
	    {
	    	for(Nodes curr=LAST;curr!=null;curr=curr.next)
	    	{
	    		System.out.println(curr.data);
	    	}
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
DoublyLinkedList obj=new DoublyLinkedList();
obj.add(12);
obj.add(11);
obj.add(23);
obj.add(19);
obj.traverse();
	}
 
}
