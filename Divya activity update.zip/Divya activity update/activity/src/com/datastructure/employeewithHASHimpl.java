package com.datastructure;
class Emp {
 private int employeeId;
 private String name;

 public Emp(int employeeId, String name) {
     this.employeeId = employeeId;
     this.name = name;
 }

 public int getEmployeeId() {
     return employeeId;
 }

 public String getName() {
     return name;
 }

 @Override
 public String toString() {
     return "Employee{" +
             "employeeId=" + employeeId +
             ", name='" + name + '\'' +
             '}';
 }
}


class HashN {
 String key;
 int count;
 HashN next;

 public HashN(String key) {
     this.key = key;
     this.count = 1; 
     this.next = null;
 }
}


public class employeewithHASHimpl {
 private Emp[][] dailyAttendance; 
 private HashN[] attendanceTable; 
 private int capacity; 
 private int days; 

 public employeewithHASHimpl(int days, int hashTableCapacity) {
     this.days = days;
     dailyAttendance = new Emp[days][31]; 
     attendanceTable = new HashN[hashTableCapacity];
     capacity = hashTableCapacity;
 }

 
 private int hash(int employeeId) {
     return (employeeId ) % capacity; 
 }

 
 public void markAttendance(int day, Emp employee) {
     if (day < 0 || day >= days) {
         throw new IllegalArgumentException("Invalid day");
     }

     
     for (int i = 0; i < dailyAttendance[day].length; i++) {
         if (dailyAttendance[day][i] == null) {
             dailyAttendance[day][i] = employee; 
             break;
         }
     }
     updateAttendanceCount(employee);
 }

 private void updateAttendanceCount(Emp employee) {
     int index = hash(employee.getEmployeeId());
     HashN current = attendanceTable[index];

     if (current == null) {
         attendanceTable[index] = new HashN(String.valueOf(employee.getEmployeeId())); 
     } else {
         while (true) {
             if (current.key.equals(String.valueOf(employee.getEmployeeId()))) {
                 current.count++; 
                 return;
             }
             if (current.next == null) break; 
             current = current.next;
         }
         current.next = new HashN(String.valueOf(employee.getEmployeeId())); 
     }
 }

 public int getAttendanceCount(int employeeId) {
     int index = hash(employeeId);
     HashN current = attendanceTable[index];

     while (current != null) {
         if (current.key.equals(String.valueOf(employeeId))) {
             return current.count; 
         }
         current = current.next; 
     }
     return 0; 
 }

 
 public Emp getLatestArrival(int day) {
     if (day < 0 || day >= days) {
         return null; 
     }
     Emp latest = null;
     for (int i = 0; i < dailyAttendance[day].length; i++) {
         if (dailyAttendance[day][i] != null) {
             latest = dailyAttendance[day][i]; 
         }
     }
     return latest; 
 }


 public static void main(String[] args) {
	 employeewithHASHimpl attendanceSystem = new employeewithHASHimpl(30, 31); 

     Emp emp1 = new Emp(1, "Alice");
     Emp emp2 = new Emp(2, "Bob");
     Emp emp3 = new Emp(3, "Charlie");

     attendanceSystem.markAttendance(0, emp1);
     attendanceSystem.markAttendance(0, emp2);
     attendanceSystem.markAttendance(1, emp2);
     attendanceSystem.markAttendance(1, emp1);
     attendanceSystem.markAttendance(2, emp1); 
    
     Emp latestArrivalDay0 = attendanceSystem.getLatestArrival(0);
     System.out.println("Latest arrival on day 0: " + latestArrivalDay0);

     System.out.println("Attendance count for Alice: " + attendanceSystem.getAttendanceCount(1));
     System.out.println("Attendance count for Bob: " + attendanceSystem.getAttendanceCount(2));
     System.out.println("Attendance count for Charlie: " + attendanceSystem.getAttendanceCount(3));
 }
}
