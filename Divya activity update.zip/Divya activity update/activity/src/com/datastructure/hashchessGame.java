package com.datastructure;
public class hashchessGame{
	private static final int size=31;
	private String[] board=new String[size];
	public int hash(String key) {
		return(key.hashCode())%size;
	}
	public void init() {
		for(int i = 1; i <= 8; i++) {
		    board[hash("A" + i)] = "Pa" + i;
		    board[hash("B" + i)] = "Pb" + i;
		}

		board[hash("A1")]="R1";
		board[hash("H1")]="R2";
		board[hash("A8")] = "R1";
        board[hash("H8")] = "R2";
        board[hash("B1")] = "N1";
        board[hash("G1")] = "N2";
        board[hash("B8")] = "N1";
        board[hash("G8")] = "N2";
		board[hash("C1")] = "B1";
        board[hash("F1")] = "B2";
        board[hash("C8")] = "B1";
        board[hash("F8")] = "B2";
        board[hash("D1")] = "Q";
        board[hash("D8")] = "Q";
        board[hash("E1")] = "K";
        board[hash("E8")] = "K";
	}
	public String getAt(String position) {
		return board[hash(position)] != null ? board[hash(position)] : "Empty";
	}
	public boolean move(String from,String to) {
		String piece=getAt(from);
		if(piece.equals("Empty")) {
			return false;
		}
		String target=getAt(to);
		if(target.equals("Empty") || target.charAt(0)!=piece.charAt(0)) {
			board[hash(to)]=piece;
			board[hash(from)]=null;
			return true;
			
		}
		return false;
	}
	public static void main(String[] args) {
		hashchessGame chess=new hashchessGame();
		chess.init();
		System.out.println(chess.getAt("E1"));
		System.out.println(chess.move("E1", "E2"));
		System.out.println(chess.getAt("E2"));
		System.out.println(chess.getAt("A3"));
		System.out.println(chess.move("E2", "E1"));
		System.out.println(chess.getAt("E8"));
		System.out.println(chess.move("E2", "E8"));
	}
	
}