package com.datastructure;
class Employee{
	private int empId;
	private String empName;

	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
	


	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}
@Override
public String toString() {
	return "employeeId: "+empId+" ,EmployeeName: "+empName;
}
}
class N{
	Employee employee;
	N next;
	public N(Employee employee){
		this.employee=employee;
		this.next=null;
	}
}
class linkedlist{
	N START;
	void add(Employee employee) {
		if(isExist(employee.getEmpId())) {
			System.out.println("Id already exists");
			return;
		}
		N newNode=new N(employee);
		if(START==null) {
			START=newNode;
		}else {
			N last=START;
			while(last.next!=null) {
				last=last.next;
			}
			last.next=newNode;
		}
	}
	public boolean isExist(int empId) {
		N curr=START;
		while(curr!=null) {
			if(curr.employee.getEmpId()==empId) {
				return true;
			}
			curr=curr.next;
		}
		return false;
	}
	Employee find(int empId) {
		N curr=START;
		while(curr!=null) {
			if(curr.employee.getEmpId()==empId) {
				return curr.employee;
			}
			curr=curr.next;
		}
		System.out.println("employee not found");
		return null;
	}
	void print() {
		N curr=START;
		while(curr!=null) {
			System.out.println(curr.employee);
			curr=curr.next;
		}
	}
}
public class chechuniqueinlinkedlist{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		linkedlist check=new linkedlist();
		check.add(new Employee(1,"Divya"));
		check.add(new Employee(1,"Priya"));
		check.add(new Employee(2,"Madhu"));
		check.print();
		Employee emp=check.find(1);
		if(emp!=null) {
			System.out.println("Found");
			System.out.println(emp);
		}

	}

}
