package com.datastructure;
import java.util.HashSet;

public class Hashwordcount {
    private static final int SIZE = 31;
    private String[] keys = new String[SIZE];
    private int[] values = new int[SIZE];

    
    public int hash(String key) {
    	return(keys.hashCode())% SIZE;
    }

   
    public void put(String key, int value) {
        int index = hash(key);

        while (keys[index] != null) {
            if (keys[index].equals(key)) {
                values[index] += value;
                return;
            }
            index = (index + 1) % SIZE;
        }

 
        keys[index] = key;
        values[index] = value;
    }

    
    public int get(String key) {
        int index = hash(key);

        while (keys[index] != null) {
            if (keys[index].equals(key)) {
                return values[index]; 
            }
            index = (index + 1) % SIZE;
        }
        return 0; 
    }

    public static void main(String[] args) {
        Hashwordcount wordCount = new Hashwordcount();
        String inputText = "Hello, world! Hello everyone. Welcome to the world of programming.";

        String[] words = inputText.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", "").split("\\s+");

        for (String word : words) {
            if (!word.isEmpty()) {
                wordCount.put(word, 1); 
            }
        }

        HashSet<String> printedWords = new HashSet<>();

        
        for (String word : words) {
            if (!word.isEmpty() && !printedWords.contains(word)) { 
                int frequency = wordCount.get(word);
                System.out.println(word + ": " + frequency); 
                printedWords.add(word); 
            }
        }
    }
}
