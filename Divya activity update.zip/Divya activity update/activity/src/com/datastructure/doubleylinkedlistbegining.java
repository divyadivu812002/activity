package com.datastructure;

class No
{  
	  int data;
	  No prev,next;
	  public No(int data,No prev,No next)
	  {
		  this.data=data;
		  this.prev=prev;
		  this.next=next;
	  }
}
public class doubleylinkedlistbegining{
 
	 No START,LAST;
	
	   public doubleylinkedlistbegining()
	   {
		    START=LAST=null;
	   }
	   
	    public void add(int data)
	    {
	    	No n=new No(data,null,null);
	    	 if(START==null&&LAST==null)
	    	 {
	    		  START=LAST=n;
	    		  return;
	    	 }
	    	 else
	    	 {
	    		 n.next=START;
	    		 START.prev=n;
	    		 START=n;
	    	 }
	    	
	    	
	    }
	    public void traverse()
	    {
	    	for(No curr=START;curr!=null;curr=curr.next)
	    	{
	    		System.out.println(curr.data);
	    	}
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		doubleylinkedlistbegining obj=new doubleylinkedlistbegining();
obj.add(12);
obj.add(11);
obj.add(23);
obj.add(19);
obj.traverse();
	}
 
}