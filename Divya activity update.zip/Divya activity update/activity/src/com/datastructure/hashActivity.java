package com.datastructure;


class Player{
	int id;
	String name;
	public Player(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String toString() {
		return "name: "+name+" ,ID: "+id;
	}
}
class HashNode{
	String keylocation;
	Player player;
	HashNode next;
	
	public HashNode(String keylocation,Player player, HashNode next) {
		super();
		this.keylocation = keylocation;
		this.player = player;
		this.next = next;
	}
	
}
public class hashActivity {
	int capacity;
	HashNode[] table;
	public hashActivity(int capacity) {
		this.capacity=capacity;
		table=new HashNode[capacity];
	}
	
	public int hash(String keylocation) {
		return(keylocation.hashCode())% capacity;
	}
	public void put(String keylocation,Player player) {
		int index=hash(keylocation);
		HashNode n=new HashNode(keylocation,player,null);
		//System.out.println(index);
		//System.out.println(table.length);
		if(table[index]==null) {
			table[index]=n;
			return;
		}else {
			HashNode current;
			for(current=table[index];current!=null;current=current.next) {
				
			}
			current.next=n;
		}
	}

	public Player get(String keylocation) {
		int index=hash(keylocation);
		if(table[index]==null) {
			System.out.println("empty position");
			return null;
		}
		else {
			HashNode current;
			for(current=table[index];current!=null;current=current.next) {
				if(current.keylocation.equals(keylocation)) {
					return current.player;
			}
			}
			System.out.println("Not found");
			return null;
			}
		}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hashActivity obj=new hashActivity(31);
		obj.put("e001", new Player(1, "Divya"));
	    obj.put("e002", new Player(2, "Priya"));
	    obj.put("e003", new Player(3, "Madhu"));
	    obj.put("e004", new Player(4, "Subha"));
	    System.out.println(obj.get("e001"));  
	    System.out.println(obj.get("e002")); 
	    System.out.println(obj.get("e003")); 
	    System.out.println(obj.get("e004"));

	}

}
