package com.tree;



class node{
	int data;
	String name;
	node left;
	node right;
	public node(int data,String name) {
		this.data=data;
		this.name=name;
	}

}
public class employeeTree {
	node root;
	public employeeTree() {
		root=null;
	}
	public void addnode(int data,String name) {
		root=addemp(root,data,name);
	}
	public void inorder() {
		inorderemp(root);
	}
	public void inorderemp(node n) {
		if(n!=null) {
			inorderemp(n.left);
			System.out.println(n.data+" "+n.name);
			inorderemp(n.right);
		}
	}
	public node addemp(node n,int data,String name) {
		if(n==null) {
			n=new node(data,name);
			return n;
		}
		else if(data<0) {
			n.left=addemp(n.left,data,name);
		}else if(data>1) {
			n.right=addemp(n.right,data,name);
		}
		return n;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employeeTree obj=new employeeTree();
		obj.addnode(15,"Peter");
		obj.addnode(12, "Erric");
		obj.addnode(13, "Simond");
		obj.addnode(11,"Nelson" );
		obj.addnode(14,"Cathy");
		obj.addnode(10,"Marry");
		obj.addnode(7, "Fedrick");
		obj.addnode(8,"Bruce");
		obj.addnode(4,"Steve");
		obj.addnode(2,"Klark");
		obj.inorder();
	}

}
