package com.tree;
class HierarchyNode{
	String data;
	HierarchyNode left;
	HierarchyNode right;
	public HierarchyNode(String data) {
		this.data=data;
	}
}


public class HierarchyTree {
	HierarchyNode root;
	public void inOrder() {
		inOrderRec(root);
	}
	public void inOrderRec(HierarchyNode n) {
		if(n!=null) {
			inOrderRec(n.left);
			System.out.println(n.data);
			inOrderRec(n.right);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HierarchyNode h=new HierarchyNode("Erric");
		HierarchyTree hr=new HierarchyTree();
		hr.root=h;
		hr.root.left=new HierarchyNode("Simond");
		hr.root.right=new HierarchyNode("Cathy");
		
		HierarchyNode ri=hr.root.right;
		ri.left=new HierarchyNode("Samuel");
		ri.right=new HierarchyNode("Elina");
		
		HierarchyNode li=hr.root.left;
		li.left=new HierarchyNode("Jason");
		li.right=new HierarchyNode("Rodrigue");
		
		HierarchyNode li1=li.left;
		li1.left=new HierarchyNode("Jayant");
		li1.right=new HierarchyNode("Henry");
		
		hr.inOrder();
		
		
		

	}

}
