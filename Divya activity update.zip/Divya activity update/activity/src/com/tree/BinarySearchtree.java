package com.tree;
class Nodes{

}

public class BinarySearchtree {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
