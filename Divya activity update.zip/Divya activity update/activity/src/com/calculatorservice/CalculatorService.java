package com.calculatorservice;

public class CalculatorService {
	public void calculateIntrest() {
		System.out.println(12000*3*4/100);
	}
	public void calclateDiscount() {
		System.out.println(12000*3/100);
	}

}

