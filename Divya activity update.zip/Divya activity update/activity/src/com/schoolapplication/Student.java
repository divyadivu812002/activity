package com.schoolapplication;
//import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
public class Student {
	private String studentName;
	private List<Course>courseList;
	public Student(String studentName) {
		super();
		this.studentName = studentName;
		this.courseList = new ArrayList<>();
	}
	public String getStudentName() {
		return studentName;
	}
	public List<Course>getCourseList(){
		return courseList;
	}

	public void addCourse(Course course) {
		courseList.add(course);
	}
	@Override
	public String toString() {
		return studentName+":"+courseList;
	}
	

}
