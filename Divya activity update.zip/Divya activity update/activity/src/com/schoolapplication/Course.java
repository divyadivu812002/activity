package com.schoolapplication;

public class Course {
	private String courseName;
	private int durationInHours;
	public Course(String courseName, int durationInHours) {
		super();
		this.courseName = courseName;
		this.durationInHours = durationInHours;
	}
	public String getCourseName() {
		return courseName;
	}

	
	public int getDurationInHours() {
		return durationInHours;
	}
	
	@Override
	public String toString() {
		return "Coursename:"+courseName+"-"+"Hours: "+durationInHours;
	}
}
