package com.schoolapplication;
import java.util.List;
import java.util.ArrayList;
public class school {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Course course1=new Course("Java",45);
		Course course2=new Course("Angular",35);
		Student student1=new Student("Divya");
		student1.addCourse(course1);
		Student student2=new Student("Priya");
		student2.addCourse(course2);
		Teacher teacher=new Teacher("TE01","Ms Abi");
		teacher.addStudent(student1);
		teacher.addStudent(student2);
		teacher.addCourse(course1);
		teacher.addCourse(course2);
		System.out.println(teacher);
		System.out.println(student1);
		System.out.println(student2);
		
	}

}
