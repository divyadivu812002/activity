package com.schoolapplication;
import java.util.List;
import java.util.ArrayList;
public class Teacher {
	private String teacherId;
    private String teacherName;
    private List<Student> studentList;
    private List<Course> courseList;
	public Teacher(String teacherId, String teacherName) {
		super();
		this.teacherId = teacherId;
		this.teacherName = teacherName;
		this.studentList = new ArrayList<>();
		this.courseList = new ArrayList<>();
	}
	public String getTeacherId() {
		return teacherId;
	}
	public String getTeacherName() {
		return teacherName;
	}
	
	public List<Student> getStudentList() {
		return studentList;
	}
	public void addStudent(Student student) {
		studentList.add(student);
	}
	public List<Course> getCourseList() {
		return courseList;
	}
	public void addCourse(Course course) {
		courseList.add(course);
	}
	@Override
    public String toString() {
    	return "TeacherID:"+teacherId+",Name: "+teacherName+",Students: "+studentList+",Courses: "+courseList;
    }

}
