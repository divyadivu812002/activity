package com.Intrest;

public interface IntrestDelegate {
	public void doCalculate(String calculationType);

}
