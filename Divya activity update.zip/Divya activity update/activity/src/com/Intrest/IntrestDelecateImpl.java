package com.Intrest;
import com.calculatorservice.CalculatorService;

public class IntrestDelecateImpl implements IntrestDelegate{
	private CalculatorService calculatorService;
	public IntrestDelecateImpl(CalculatorService calculatorService) {
		this.calculatorService=calculatorService;
	}


@Override
public void doCalculate(String calculationType) {
	if(calculationType.equals("12000*3*4/100")) {
		this.calculatorService.calculateIntrest();
	}
	if(calculationType.equals("12000*3/100")) {
		this.calculatorService.calclateDiscount();
	}
}
}
