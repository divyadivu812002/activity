package com.thursdayoct;

import java.util.Arrays;

public class QuickSort {
	public static void quickSort(int[] arr) {
		quickSort(arr,0,arr.length-1);
	}
	private static void quickSort(int[] arr,int left,int right) {
		if(left<right) {
			int pivotIndex=partition(arr,left,right);
			quickSort(arr,left,pivotIndex-1);
			quickSort(arr,pivotIndex+1,right);
		}
	}
	private static int partition(int[] arr,int left,int right) {
		int pivot=arr[right];
		int i=left-1;
		for(int j=left;j<right;j++) {
			if(arr[j]<pivot) {
				i++;
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		int temp=arr[i+1];
		arr[i+1]=arr[right];
		arr[right]=temp;
		return i+1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {5,2,8,1,9,3,7,4,6};
		quickSort(arr);
		System.out.println(Arrays.toString(arr));

	}

}
