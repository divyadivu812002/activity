package com.customerdetails;

public class Order  {
	private Customer customer;
	private Product product;
	public Order(Customer customer, Product product) {
		super();
		this.customer = customer;
		this.product = product;
	}
	public Customer getCustomer() {
		return customer;
	}
	
	public Product getProduct() {
		return product;
	}
	
	
}
