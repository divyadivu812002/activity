package com.customerdetails;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer=new Customer("C001","divya","divya@gmail.com","123456787");
		
        Product product=new Product("P001","Laptop",45500.00);
        Order order=new Order(customer,product);
        System.out.println(order.getCustomer().getName());
        System.out.println(order.getCustomer().getEmail());
        System.out.println(order.getCustomer().getCustomerId());
        System.out.println(order.getCustomer().getPhone());
        System.out.println(order.getProduct().getProductId());
        System.out.println(order.getProduct().getProductName());
        System.out.println(order.getProduct().getPrice());
	}

}
