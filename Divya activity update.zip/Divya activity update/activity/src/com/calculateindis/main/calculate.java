package com.calculateindis.main;
import com.calculatorservice.CalculatorService;
import com.Intrest.*;

public class calculate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculatorService service=new CalculatorService();
		IntrestDelegate delegate=new IntrestDelecateImpl(service);
		delegate.doCalculate("12000*3*4/100");
		delegate.doCalculate("12000*3/100");

	}

}
