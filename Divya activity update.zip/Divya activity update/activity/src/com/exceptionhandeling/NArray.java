package com.exceptionhandeling;

public class NArray {
	int size;
	int[] arr;
	

	public NArray(int size) {
		super();
		this.size = size;
		arr=new int[size];
		for (int i = 0; i < size; i++) {
            arr[i] = i; 
        }
	}
	
public void print() {
	
	try {
	for(int i=0;i<=size;i++) {
		System.out.println(arr[i]);
		
	}
	throw new Throwable();

	}
	catch(Throwable t) {
		System.out.println("Out of the Bound");
		
	}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NArray obj=new NArray(5);
		obj.print();

	}

}
