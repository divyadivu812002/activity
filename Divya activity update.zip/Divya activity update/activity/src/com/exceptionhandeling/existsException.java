package com.exceptionhandeling;

public class existsException extends Exception{
	String message;
	public existsException(String message) {
		super(message);
		this.message=message;
		
		
	}
	public String toString() {
		return " invalid="+message;
	}

}
