package com.exceptionhandeling;

public class nameException extends Exception{
	int candidatename;
	public nameException(int candidatename) {
		super("name is invalid"+candidatename);
		this.candidatename=candidatename;
	}
	public String toString() {
		return "invalid name: "+candidatename;
	}

}
