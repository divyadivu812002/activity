package com.exceptionhandeling;

public class hashtableException {
	private static int size=23;
	String[] str=new String[size];
	public int hash(String Key) {
		return(Key.hashCode())% size;
	}
	public void put(String key,String value)throws existsException {
		int index=hash(key);
		if(str[index]!=null) {
			
			throw new existsException("index already exist");
		
			
			
		}
		str[index]=value;
	}
	public String get (String key) {
		int index=hash(key);
		return str[index];
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		hashtableException obj=new hashtableException();
		try {
		obj.put("e001","peter");
		obj.put("e001","erric");
		obj.put("e003","kate");
		obj.put("e004","alex");
		obj.put("e005","ana");
		}catch(existsException e){
			System.out.println(e.getMessage());
		}
		

	}

}
