package com.exceptionhandeling;
import java.util.Random;
public class Wheeler implements AutoCloseable{
	int turns;
	public Wheeler(int turns)throws Exception {
		this.turns=turns;
	}
	
	public int rotate() throws TurnException{
		Random random=new Random();
		int result=Math.abs(random.nextInt())%turns;
		if(result==0) {
			throw new TurnException("number less than 0");
		}
		return result;
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Wheeler obj=new Wheeler(5);
		try{
		
		System.out.println(obj.rotate());
		}catch(TurnException e) {
			System.out.println(e);
		}
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("close called for cleanup");
		
	}

}
