package com.exceptionhandeling;

class Node {
    int price;
    int quantity; 
    Node next;

    public Node(int price, int quantity, Node next) {
        this.price = price;
        this.quantity = quantity;
        this.next = next;
    }
}

public class Sales {
    Node start;

    Sales() {
        start = null;
    }

    public void add(int price, int quantity)throws PriceException {
    	if (price < 10) {
            throw new PriceException("Price cannot be below 10 Rs.");
        }
        Node n = new Node(price, quantity, null);
        if (start == null) {
            start = n;
            return;
        } else {
            Node curr;
            for (curr = start; curr.next != null; curr = curr.next) {
                
            }
            curr.next = n;
        }
    }

    public void sell(int price, int quantity) throws OutOfStockException {
        Node curr = start;
        while (curr != null) {
            if (curr.price == price) {
                if (curr.quantity < quantity) {
                    throw new OutOfStockException("Out of stock");
                }
                curr.quantity -= quantity; 
                return;
            }
            curr = curr.next;
        }
        
    }

    public int countItems() {
        int count = 0;
        Node curr = start;
        while (curr != null) {
            count += curr.quantity; 
            curr = curr.next;
        }
        return count;
    }

    public static void main(String[] args) {
        Sales obj = new Sales();
        try {
        obj.add(10, 5);  
        obj.add(80, 3);  
        obj.add(5, 10); 
        } catch(PriceException e) {
        	System.out.println(e);
        }

        try {
            obj.sell(10, 6); 
            obj.sell(80, 1); 
        } catch (OutOfStockException e) {
            System.out.println("Error: " + e.getMessage());
        }

        int itemCount = obj.countItems(); 
        System.out.println("Number of items remaining: " + itemCount);
    }
}
