package com.exceptionhandeling;

public class PriceException extends Exception{
	
	String message;
	public PriceException(String message) {
		super("10Rs is invalid"+message);
		this.message=message;
	}
public String toString() {
	return "10Rs invalid="+message;
}
}
