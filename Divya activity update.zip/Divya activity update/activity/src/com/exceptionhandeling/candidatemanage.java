package com.exceptionhandeling;
class Candidate{
	private String candidatename;
	private int age;
	public Candidate(String candidatename, int age) {
		super();
		this.candidatename = candidatename;
		this.age = age;
	}
	public String getCandidatename() {
		return candidatename;
	}
	public void setCandidatename(String candidatename) {
		this.candidatename = candidatename;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String toString() {
		return "Candidatename: "+candidatename+"Age: "+age;
	}
	
	//int n=candidatename.length();
	public int setName(int n)throws nameException {
		if(n<3) {
			throw new nameException(n);
		}
		return n;
		
	}
}

public class candidatemanage {
	//private String candidatename;
	int n;
	public int setName(int n)throws nameException {
		if(n<3) {
			throw new nameException(n);
		}
		return n;
		
	}
	//private int age;
	public int setAges(int age)throws ageException {
		if(age<=0 ||   age>=100) {
			throw new ageException(age);
		}
		return age;
		
	}

	public static void main(String[] args) throws nameException,ageException {
		// TODO Auto-generated method stub
		
	try {
		Candidate obj=new Candidate("abcd",110);
		candidatemanage m=new candidatemanage();
		m.setName(obj.getCandidatename().length());
		m.setAges(obj.getAge());	
	}
	catch(nameException e) {
		System.out.println(e);
	}
	catch(ageException e) {
		System.out.println(e);
	}

	}

}

