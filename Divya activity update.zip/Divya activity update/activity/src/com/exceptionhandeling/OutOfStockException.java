package com.exceptionhandeling;

public class OutOfStockException extends Exception{
	String message;
	public OutOfStockException(String message) {
		super("quantity is invalid"+message);
		this.message=message;
		
	}
	public String toString() {
		return "invalid quantity"+message;
	}

}
