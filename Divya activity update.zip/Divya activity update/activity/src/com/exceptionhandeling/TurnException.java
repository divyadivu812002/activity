package com.exceptionhandeling;

public class TurnException extends Exception {
String message;
	public TurnException(String message) {
		super("Age is invalid"+message);
		this.message=message;
	}
public String toString() {
	return "Turns invalid="+message;
}

}
