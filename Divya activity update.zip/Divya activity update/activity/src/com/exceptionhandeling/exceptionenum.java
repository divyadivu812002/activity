package com.exceptionhandeling;

enum Attendance{
	PRESENT,
	ABSENT
	
}

public class exceptionenum {
int present=0;
int absent=0;
public  void mark(Attendance Days) {
switch(Days){
	case PRESENT:
		present++;
		break;
	case ABSENT:
		 absent++;
		 break;
}
}
public void Present() throws Throwable {
	
	if(present>20) {
		System.out.println("Exceeded present limit");
		throw new Throwable();
	}	
	
}
public void Absent() throws Throwable {
	
	if(absent>20) {
		System.out.println("Exceeded maximum absent limit");
		throw new Throwable();
	}
	
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		exceptionenum obj=new exceptionenum();
		for (int i = 0; i < 22; i++) { 
            obj.mark(Attendance.PRESENT);
        }


        try {
            obj.Present();
        } catch (Throwable e) {
            System.out.println("invalid");
        }
        for (int i = 0; i < 22; i++) { 
            obj.mark(Attendance.ABSENT);
        }


        try {
            obj.Absent();
        } catch (Throwable e) {
            System.out.println("invalid");
        }
		

	}

}
