package com.exceptionhandeling;



public class ageException extends Exception{
	int age;
	public ageException(int age) {
		super("Age is invalid"+age);
		this.age=age;
	}
public String toString() {
	return "Age invalid="+age;
}
}
