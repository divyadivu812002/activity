package StreamApiactivity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import StreamApi.TestNumber;

class Item{
	private String itemName;
	private float price;
	public Item(String itemName, float price) {
		super();
		this.itemName = itemName;
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String toString(){
		return "ItemName: "+itemName+" ,Price"+price;
}
}
class TestItem{
	public static boolean testItem(Item i) {
		return i.getPrice()>100;
	}
}
public class TestItemActivity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Item> l=new ArrayList<>();
		l.add(new Item("Cake",303));
		l.add(new Item("Cookie",405));
		l.add(new Item("Coke",203));
		l.add(new Item("Juice",734));
		Stream<Item> stream=l.stream();
		Stream<Item> mystream=stream.filter(TestItem::testItem);
		
		mystream.forEach(System.out::println);
		

	}

}

