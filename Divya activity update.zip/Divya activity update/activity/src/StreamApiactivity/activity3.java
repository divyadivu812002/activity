package StreamApiactivity;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.ArrayList;
class Product{
	private String productName;
	private float price;
	public Product(String productName, float price) {
		super();
		this.productName = productName;
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String toString() {
		return "ProductName: "+productName+" ,Price: "+price;
	}
}

public class activity3 {
	public void productlist(List<Product> productlist) {
		Predicate <Product> predicate = (product)-> product.getPrice() >200;
		
		Stream <Product> stream = productlist.stream();
		stream.filter(predicate).forEach((e)->System.out.println(e));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		activity3 ac=new activity3();
		List<Product> l=new ArrayList<>();
		l.add(new Product("cookies",544.3f));
		l.add(new Product("biscuit",167.8f));
		l.add(new Product("Juice",999.8f));
		l.add(new Product ("Sandwich",167.4f));
	    ac.productlist(l);
	    //Predicate<Integer> predicate=(price)->price*15/100;
		

	}

}
