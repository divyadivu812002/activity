package StreamApiactivity;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.function.Predicate;
class Account{
	private String accountId;
	private boolean transactionStatus;
	public Account(String accountId, boolean transactionStatus) {
		super();
		this.accountId = accountId;
		this.transactionStatus = transactionStatus;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public boolean isTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(boolean transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String toString() {
		return "AccountId: "+accountId+" ,TransactionStatus: "+transactionStatus;
	}
}

public class AccountOperation {
	public void checkStatus(List<Account> accountList,Predicate<Account> predicate) {
		Stream<Account> stream=accountList.stream();
		if(stream.allMatch(predicate)) {
			System.out.println("account transaction successfull");
		}
		else {
			System.out.println("account transaction is not successfull");
			System.out.println();
		}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Account> l=new ArrayList<>();
		l.add(new Account("divya",true));
		l.add(new Account("priya",false));
		l.add(new Account("madhu",true));
		l.add(new Account("subha",false));
		AccountOperation c=new AccountOperation();
		Predicate<Account> check=account->account.isTransactionStatus()==true;
		c.checkStatus(l,check);
		Stream<Account> stream1=l.stream();
		stream1.forEach((e)->System.out.println(e));
		
		
		
		

	}

}
