package StreamApiactivity;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.ArrayList;

class Candidate{
	private String name;
	private float age;
	public Candidate(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public String toString() {
		return "Name: "+name+" ,Age: "+age;
	}
}
	class CheckAge{
		public void checkCandidates(List<Candidate> candidateList,Predicate<Candidate> predicate) {
			Stream<Candidate> stream=candidateList.stream();
			if(stream.anyMatch(predicate)) {
				System.out.println("Candidate with age below 18 in list!please check");
			}
			Stream<Candidate> stream1=candidateList.stream();
			stream1.filter(predicate).forEach((e)->System.out.println(e));;
			
		}
	}


public class streamapiactivity2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Candidate> l=new ArrayList<>();
		l.add(new Candidate("divya",23));
		l.add(new Candidate("priya",27));
		l.add(new Candidate("madhu",18));
		l.add(new Candidate("subha",14));
		CheckAge c = new CheckAge();
		Predicate<Candidate> check = candidate -> candidate.getAge() < 18;

	        // Check candidates against the predicate
	        c.checkCandidates(l, check);
	        //Stream<Candidate> stream=l.stream();
	       
	        
	        
	}

}

