package StreamApiactivity;
import java.util.ArrayList;
import java.util.stream.Stream;
class Item{
	private String itemName;
	private float price;
	public Item(String itemName, float price) {
		super();
		this.itemName = itemName;
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String toString() {
		return "ItemName: "+itemName+" ,Price: "+price;
	}
}

public class streamapiactivity1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Stream.Builder<Item> builder=Stream.builder();
		builder.add(new Item("Switch",21.0f));
		builder.add(new Item("Router",21.0f));
		builder.add(new Item("Firewall",34.2f));
		builder.add( new Item("BTS",89.5f));
		builder.add(new Item("BSC",67.9f));
		builder.add(new  Item("RNC",56.4f));
		Stream stream=builder.build();4
		stream.forEach(System.out::println);*/
		//stream.forEach((e)->System.out.println(e));
		ArrayList<Item> l=new ArrayList<>();
		l.add(new Item("apple",34.2f));
		l.add(new Item("grapes",38.9f));
		Stream stream=l.stream();
		stream.forEach((e)->System.out.println(e));
		

	}

}
