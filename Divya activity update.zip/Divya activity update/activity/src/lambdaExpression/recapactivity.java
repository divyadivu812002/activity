package lambdaExpression;
class Student{
	private int marks;
	
	
}

public class recapactivity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Greater Compare=(a,b)->a.getAge()>b.getAge()?1:(a.getAge())

	}

}
