package lambdaExpression;
interface ondiscount{
	int disc(int price,int discount);
}

public class discount {

	

	public static void main(String[] args) {
		 int costprice = 2000;
		// TODO Auto-generated method stub
		ondiscount c=(price,discount)->{
			return costprice*discount/100;
		};
		int discounts=c.disc(costprice, 10);
		float sellingprice=costprice-discounts;
		System.out.println(sellingprice);

	}

}
