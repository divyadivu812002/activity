package lambdaExpression;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Predicate;
import java.util.TreeSet;

class Product{
	private String productName;
	private float price;
	public Product(String productName, float price) {
		super();
		this.productName = productName;
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String toString() {
		return "ProductName: "+productName+"Price"+price;
	}
}

public class activity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Product> llist=new ArrayList<>();
		llist.add(new Product("charger",120));
		llist.add(new Product("laptop",1211));
		llist.add(new Product("mobile",1900));
		llist.add(new Product("pendrive",319));
		llist.add(new Product("cable",414));
		llist.add(new Product("Sticker",13));
		Predicate<Product> predicate=(product)->product.getPrice()>200;
		 for (Product product : llist) {
	            if (predicate.test(product)) {
	                System.out.println("Product name: " + product.getProductName() + " Price: " + product.getPrice());
	            }
	            
	            
	            
	            Comparator<Product> comparator=(a,b)->{
	    			if(a.getPrice()==b.getPrice()) {
	    				return 0;
	    			}
	    			else if(a.getPrice()<b.getPrice()) {
	    				return -1;
	    			}
	    			else {
	    				return 1;
	    			}
	    		};
	    		//TreeSet<Product> set=new TreeSet<>(comparator);
	    		//set.forEach((a)->System.out.println(a.getProductName()+","+product.getPrice()));
	    		Comparator<Product> comparato = (a, b) -> Float.compare(a.getPrice(), b.getPrice());

	            // Sort the list of products
	            llist.sort(comparator);

	            // Display sorted products
	            System.out.println("\nSorted Products:");
	            llist.forEach(prod -> System.out.println(prod.getProductName() + ", " + prod.getPrice()));
	        }

	    	
		
		 }
	
	}


