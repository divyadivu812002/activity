package lambdaExpression;
interface Calculate{
	double area(double r);
}

public class AreaOfCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculate c=(r)->{
			return (3.14*r*r);
		};
		double res=c.area(4);
		System.out.println(res);

	}

}
