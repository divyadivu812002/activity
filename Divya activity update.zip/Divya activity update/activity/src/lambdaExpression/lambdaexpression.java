package lambdaExpression;
interface SimpleInterest{
	int multi(int p,int r,int t);
}
public class lambdaexpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest d=(p,r,t)->{
			return (p*r*t)/100;
		};
		int result=d.multi(5, 10, 15);
		System.out.println(result);

	}

}
