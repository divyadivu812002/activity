package lambdaExpression;
interface Calculates{
	int add(int r);
}

public class areasquare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculates c=(r)->{
			return (r*r);
		};
		int result=c.add(4);
		System.out.println(result);

	}

}
