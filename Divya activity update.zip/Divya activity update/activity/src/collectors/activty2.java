package collectors;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Map;

class Student{
	private  String studentName;
	private float marks;
	private String semester;
	public Student(String studentName, float marks, String semester) {
		super();
		this.studentName = studentName;
		this.marks = marks;
		this.semester = semester;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String toString() {
		return "StudentName: "+studentName+" ,Marks: "+marks+" ,Semester: "+semester;
	}
}

public class activty2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> studentlist=Arrays.asList(new Student("Divya",97.6f,"1"),
		new Student("priya",98.5f,"2"),
		new Student("iniya",99.9f,"1"),
		new Student("madhu",98.6f,"2"),
		new Student("Subha",98.9f,"1"));
		Stream<Student> studentstream=studentlist.stream();
		Map<String,List<Student>> groupedstudents=studentstream.collect(Collectors.groupingBy((s)->s.getSemester()));
		groupedstudents.forEach((semester,stList)->{
		System.out.println(semester);
		System.out.println(stList);
			
		});
		
		}

}
