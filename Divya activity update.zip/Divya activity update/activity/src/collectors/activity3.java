package collectors;

import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Employee{
	private String employeeName;
	private double basicSalary;
	private double dearnessAllowance;
	private double providentFund;
	private double netSalary;
	public Employee(String employeeName, double basicSalary, double dearnessAllowance, double providentFund,
			double netSalary) {
		super();
		this.employeeName = employeeName;
		this.basicSalary = basicSalary;
		this.dearnessAllowance = dearnessAllowance;
		this.providentFund = providentFund;
		this.netSalary = netSalary;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public double getDearnessAllowance() {
		return dearnessAllowance;
	}
	public void setDearnessAllowance(double dearnessAllowance) {
		this.dearnessAllowance = dearnessAllowance;
	}
	public double getProvidentFund() {
		return providentFund;
	}
	public void setProvidentFund(double providentFund) {
		this.providentFund = providentFund;
	}
	public double getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}
	@Override
	public String toString() {
		return "Employee [employeeName=" + employeeName + ", basicSalary=" + basicSalary + ", dearnessAllowance="
				+ dearnessAllowance + ", providentFund=" + providentFund + ", netSalary=" + netSalary + "]";
	}
	
}
public class activity3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> L=Arrays.asList(new Employee("Divya",28000,1200,1500,30000),
				new Employee("Priya",29000,1200,1400,31000),
				new Employee("Madhu",31000,1100,1600,32000),
				new Employee("Subha",29000,1200,1400,31000)
				
                );
		
		
		Stream<Employee> employeestream1=L.stream();
		DoubleSummaryStatistics  Basicsalary=employeestream1.collect(Collectors.summarizingDouble((p)->p.getBasicSalary()));
		System.out.println("Summary of TotalBasicSalary: "+Basicsalary);
		
		Stream<Employee> employeestream2=L.stream();
		DoubleSummaryStatistics DearnessAllowance=employeestream2.collect(Collectors.summarizingDouble((p)->p.getDearnessAllowance()));
		System.out.println("Summary of TotalDearnessAllowance: "+DearnessAllowance);
		
		Stream<Employee> employeestream3=L.stream();
		DoubleSummaryStatistics ProvidentFund=employeestream3.collect(Collectors.summarizingDouble((p)->p.getProvidentFund()));
		System.out.println("Summary of TotalProvidentFund: "+ProvidentFund);
		
		Stream<Employee> employeestream4=L.stream();
		DoubleSummaryStatistics NetSalary=employeestream4.collect(Collectors.summarizingDouble((p)->p.getNetSalary()));	
		System.out.println("Summary of TotalNetSalary: "+NetSalary);
		
		Stream<Employee> employeestream5=L.stream();
		double totalProvidentFund=employeestream5.collect(Collectors.summingDouble((p)->p.getProvidentFund()));
		System.out.println("TotalProvidentFund: "+totalProvidentFund);
	
		Stream<Employee> employeestream=L.stream();
		Comparator<Employee> compartormax=(a,b)->a.getNetSalary()<b.getNetSalary()?-1:1;
		 Optional<Employee> m=employeestream.max(compartormax);
		 Employee max=m.get();
		 System.out.println(max);
		 
		 Stream<Employee> employeestreams=L.stream();
		 Comparator<Employee> compartormin=(a,b)->a.getNetSalary()>b.getNetSalary()?-1:1;
		 Optional<Employee> n=employeestreams.min(compartormax);
		 Employee min=n.get();
		 System.out.println(min);
		
	}

}
