package collectors;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class RoomBooking{
	private int roomNumber;
	private String roomType;
	private int nightBooked;
	public RoomBooking(int roomNumber, String roomType, int nightBooked) {
		super();
		this.roomNumber = roomNumber;
		this.roomType = roomType;
		this.nightBooked = nightBooked;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public int getNightBooked() {
		return nightBooked;
	}
	public void setNightBooked(int nightBooked) {
		this.nightBooked = nightBooked;
	}
	public String toString() {
		return "RoomBooking{" +
                "roomNumber=" + roomNumber +
                ", roomType='" + roomType + '\'' +
                ", nightsBooked=" + nightBooked +
                '}';
	}
}

public class Hotelroombooking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		 List<RoomBooking> bookings = new ArrayList<>();
		int roomNumber=sc.nextInt();
		String roomType=sc.nextLine();
		int nightBooked=sc.nextInt();
		bookings.add(new RoomBooking(roomNumber, roomType, nightBooked));
        Stream<RoomBooking> bookingstream=bookings.stream();
        Map<String,List<RoomBooking>> groupedbooking=bookingstream.collect(Collectors.groupingBy((b)->b.getRoomType()));
        groupedbooking.forEach((roomTyp,roomList)->{
        	System.out.println(roomType);
        	System.out.println(roomList);
        });
	}

}
