package collectors;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
class Product{
	private String productName;
	private float price;
	public Product(String productName, float price) {
		super();
		this.productName = productName;
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String toString() {
		return "ProductName: "+productName+" ,Price: " +price;
	}
	
}
public class activity1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Product> l=new ArrayList<>();
		l.add(new Product("choco",244.0f));
		l.add(new Product("cookie",328.8f));
		l.add(new Product("brownie",765.7f));
		List<Product> dp = l.stream()
	            .filter(product -> product.getPrice() > 300)
	            .map(product -> new Product(product.getProductName(), product.getPrice() *  (0.1f)))
	            .collect(Collectors.toList());
	        dp.forEach(System.out::println);
		
		
	}

}
