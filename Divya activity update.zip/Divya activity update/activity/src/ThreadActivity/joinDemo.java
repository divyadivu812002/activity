package ThreadActivity;


public class joinDemo extends Thread{
	public void run() {
		System.out.println("child starts");;
		Thread th=new Thread(()->{
			System.out.println("nested child starts");
			for(int i=0;i<10;i++) {
				System.out.println(1);
				try {
					Thread.sleep(2000);
				}catch(Exception e) {
					
				}
			}
		});
		th.start();
		try {
			th.join(2000);
		}
		catch(Exception e) {
			
		}
		System.out.println("Child ends");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
joinDemo obj=new joinDemo();
obj.start();
try {
	obj.join();
}
catch(Exception e) {
	
}
System.out.println("main ends");
	}

}
