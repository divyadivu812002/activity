package ThreadActivity;


public class activity2 extends Thread {
	public void run() {
		for(char i='A';i<='Z';i++) {
			
			try{
				Thread.sleep(3000);
			}
			catch(InterruptedException e) {
				System.out.println("thread exception");
			}
			System.out.println(Thread.currentThread().getName());
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		activity2  childThread=new activity2 ();
		activity2  childThread1=new activity2 ();
		childThread.start();
		childThread1.start();
		
	}

}
