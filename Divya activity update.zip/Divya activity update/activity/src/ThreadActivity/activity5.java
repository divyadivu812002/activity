package ThreadActivity;
class BankAccount{
	private String accountNumber;
	private double Balance;
	public BankAccount(String accountNumber, double balance) {
		super();
		this.accountNumber = accountNumber;
		Balance = balance;
	}
	public synchronized void Deposit(double amount) {
		try {
			if(amount<0) {
				throw new IllegalArgumentException("amount is negative");
			}
			Balance+=amount;
			System.out.println(Thread.currentThread().getName()+" ,deposited "+amount+" ,New balance: "+Balance);
		}
			catch(IllegalArgumentException e) {
			System.out.println(Thread.currentThread().getName()+" "+e.getMessage());
			}	
	}
	public synchronized void Withdraw(double amount){
		try {
			if(amount<0) {
				throw new IllegalArgumentException("amount is negative");
			}
			if (amount > Balance) {
                System.out.println(Thread.currentThread().getName() + " attempted to withdraw " + amount + ". Insufficient balance.");
                return;
            }
			Balance-=amount;
			System.out.println(Thread.currentThread().getName()+" ,Withdrew "+amount+" ,New balance: "+Balance);
		}
		catch(IllegalArgumentException e) {
			System.out.println(Thread.currentThread().getName()+" "+e.getMessage());
		}
	}
 public double getBalance() {
	 return Balance;
 }
}

public class activity5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		activity5 obj=new activity5();
		 BankAccount account = new BankAccount("123456789", 1000.0);

		 Thread depositThread1 = new Thread(() -> account.Deposit(200), "DepositThread-1");
		 Thread depositThread2 = new Thread(() -> account.Deposit(200), "DepositThread-2");
		 Thread depositThread3 = new Thread(() -> account.Deposit(200), "WithdrawThread-1");
	      Thread withdrawThread1  = new Thread(() -> account.Withdraw(150), "WithdrawThread-3");
	        
	        Thread withdrawThread2 = new Thread(() -> account.Withdraw(150), "WithdrawThread-2");
	        
	        
	        
	        //Thread withdrawThread4 = new Thread(() -> account.Withdraw(1000), "WithdrawThread-4"); 

	        depositThread1.start();
	        depositThread2.start();
	        withdrawThread1.start();
	        withdrawThread2.start();
	        depositThread3.start();
	        
	        
	        //withdrawThread4.start();

	        try {
	        	 depositThread1.join();
		        depositThread2.join();
		        depositThread3.join();
		        withdrawThread1.join();
		        withdrawThread2.join();
		        
	            //withdrawThread4.join();
	        } catch (InterruptedException e) {
	            System.out.println("Thread interrupted: " + e.getMessage());
	        }

	       // System.out.println("Final balance: " + account.getBalance());

	}

}
