package ThreadActivity;
 
import java.util.Scanner;
 
class Simple implements Runnable
{
	public Simple()
	{
	
		Thread t = new Thread(this);
		t.start();
	}
	
	public void run()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter P Value");
		int P=scan.nextInt();
		System.out.println("Enter R Value");
		float R=scan.nextFloat();
		System.out.println("Enter T Value");
		int T=scan.nextInt();
		double simpleInterest=(P*R*T)/100;
		System.out.println("Simple Interest  " + simpleInterest);
		System.out.println(Thread.currentThread().getName());
	}
}
class User implements Runnable
{
	User()
	{
		Thread t = new Thread(this);
		t.start();
	}
	
	public void run()
	{
		
		System.out.println("Name: Divya ");
		System.out.println("Age: 23");
		
		System.out.println(Thread.currentThread().getName());
	}
}
 
public class activity3 extends Thread
{
	public static void main(String[]args)
	{
		
		Simple s = new Simple();
		
		User u = new User();
		
	}
 
}
