package ThreadActivity;

public class activity1 extends Thread{
	public void run() {
		for(int i=0;i<=10;i++) {
			System.out.println("Thread Started "+i);
			System.out.println("........");
			try{
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				System.out.println("thread exception");
			}
			System.out.println("Thread ended "+i);
			System.out.println();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		activity1 thread=new activity1();
		thread.setName("First Thread");
		thread.start();

	}

}
