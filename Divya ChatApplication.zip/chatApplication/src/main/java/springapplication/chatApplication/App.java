package springapplication.chatApplication;

import com.config.AppConfig;
import com.model.Chat;
import com.model.CompanyInfo;
import com.model.Friend;
import com.model.Message;
import com.model.User;
import com.service.UserService;
import com.service.ChatService;
import com.service.FriendService;
import com.service.MessageService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       /*AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
       User user=context.getBean(User.class);
       System.out.println(user);
       context.close();*/
    	/*AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
    	context.scan("com.model");
    	context.refresh();*/
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("com.model", "com.service", "com.dao");
        context.refresh();
    	CompanyInfo info=context.getBean(CompanyInfo.class);
    	info.printMessage();
    	
    	User user=new User();
    	user.setUserName("peter");
    	user.setPassword("peter123");
    	user.setEmailId("peter@gmail.com");
    	
    	User user1=new User();
    	user1.setUserName("sam");
    	user1.setPassword("sam123");
    	user1.setEmailId("sam@gmail.com");
    	
    	UserService service=context.getBean(UserService.class);
    	service.addUser(user);
    	service.addUser(user1);
    	List<User>userlist=service.getAll();
    	for(User users:userlist) {
    		System.out.println(users);
    	}
    			
    	user.setEmailId("peter@gmail.com");
    	service.updateUser(user);
    	List<User>userlist1=service.getAll();
    	for(User users1:userlist1) {
    		System.out.println(users1);
    	}
    	user1.setEmailId("sam@gmail.com");
    	service.updateUser(user1);
    	
    	FriendService service1=context.getBean(FriendService.class);
    	Friend friend=new Friend();
    	friend.setFriendName("Divya");
    	friend.setFriendType("best");
    	friend.setRequestStatus("accepted");
    	service1.addFriend(friend);
    	List<Friend>friendlist1=service1.getAll();
    	for(Friend friends:friendlist1) {
    		System.out.println(friends);
    	}
    	MessageService service2=context.getBean(MessageService.class);
    	Message message=new Message();
    	message.setDescription("hi");
    	message.setFriendTo("Madhu");
    	message.setUserFrom("Subha");
    	service2.addMessage(message);
    	List<Message>messagelist1=service2.getAll();
    	for(Message messages:messagelist1) {
    		System.out.println(messages);
    	}
    	List<Message> messages = new ArrayList<>();
        messages.add(message);
       
    	ChatService service3=context.getBean(ChatService.class);
    	
        Chat chat = new Chat();
        chat.setChatName("Chat1");
        chat.setMessageList(messages);
        service3.addChat(chat);
        System.out.println(chat);
        

    	
    	
    }
}
