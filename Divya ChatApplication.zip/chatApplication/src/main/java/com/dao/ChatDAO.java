package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.model.Chat;

@Repository
public interface ChatDAO {
	boolean addChat(Chat chat);
	Chat findchat(String chatName);
	List<Chat>getAll();
	boolean updateChat(Chat chat);
	boolean deleteChat(String chatName);

}
