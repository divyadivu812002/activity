package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.model.Chat;
@Component
public class ChatDAOImpl implements ChatDAO{
	List<Chat>chatList;
	public ChatDAOImpl() {
		chatList = new ArrayList<>();

	}

	@Override
	public boolean addChat(Chat chat) {
		// TODO Auto-generated method stub
		chatList.add(chat);
		return true;
	}

	@Override
	public Chat findchat(String chatName) {
		// TODO Auto-generated method stub
		for(Chat chat:chatList) {
			if(chat.getMessageList().equals(chatName)) {
			return chat;
			}
		}
		return null;
	}

	@Override
	public List<Chat> getAll() {
		// TODO Auto-generated method stub
		return chatList;
	}

	@Override
	public boolean updateChat(Chat chat) {
		// TODO Auto-generated method stub
		for(Chat c:chatList) {
			if(c.getMessageList().equals(chat.getMessageList())) {
				c.setMessageList(c.getMessageList());
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteChat(String chatName) {
		// TODO Auto-generated method stub
		Chat cr=findchat(chatName);
		for(Chat c:chatList) {
			if(c.getMessageList().equals(cr.getMessageList())) {
				chatList.remove(cr);
				return true;
			}
		}
		return false;
	}

}
