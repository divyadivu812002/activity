package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.model.User;
@Repository
public interface UserDAO {
 boolean addUser(User user);
 User findUser(String username);
 List<User>getAll();
 boolean updateUser(User user);
 boolean deleteUser(String username);


}
