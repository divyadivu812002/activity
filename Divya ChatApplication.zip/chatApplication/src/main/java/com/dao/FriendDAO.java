package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.model.Friend;
import com.model.User;

@Repository
public interface FriendDAO {
	boolean addFriend(Friend friend);
	Friend findFriend(String friendName);
	 List<Friend>getAll();
	 boolean updateFriend(Friend friend);
	 boolean deleteFriend(String FriendName);


}
