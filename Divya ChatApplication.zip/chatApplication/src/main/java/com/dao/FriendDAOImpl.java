package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.model.Friend;

@Component
public class FriendDAOImpl implements FriendDAO{
	List<Friend>friendlist;
	public FriendDAOImpl() {
		friendlist=new ArrayList();
	}

	@Override
	public boolean addFriend(Friend friend) {
		// TODO Auto-generated method stub
		friendlist.add(friend);
		return true;
	}

	@Override
	public Friend findFriend(String friendName) {
		// TODO Auto-generated method stub
		for(Friend friend:friendlist) {
			if(friend.getFriendName().equals(friendName)) {
			return friend;
			}
			
		}
		return null;
	}

	@Override
	public List<Friend> getAll() {
		// TODO Auto-generated method stub
		return friendlist;
	}

	@Override
	public boolean updateFriend(Friend friend) {
		// TODO Auto-generated method stub
		for(Friend f:friendlist) {
			if(f.getFriendName().equals(friend.getFriendName())) {
				f.setFriendType(friend.getFriendType());
				f.setRequestStatus(friend.getRequestStatus());
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteFriend(String FriendName) {
		// TODO Auto-generated method stub
		Friend cur=findFriend(FriendName);
		for(Friend f:friendlist) {
			if(f.getFriendName().equals(cur.getFriendName())) {
				friendlist.remove(cur);
			return true;
		}
	}
	return false;

}
}