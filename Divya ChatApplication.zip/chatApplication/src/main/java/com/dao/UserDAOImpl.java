package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.model.User;

@Component
public class UserDAOImpl implements UserDAO {
	List<User>userList;
	public UserDAOImpl() {
		userList=new ArrayList();
	}

	@Override
	public boolean addUser(User user) {
		userList.add(user);
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public User findUser(String username) {
		// TODO Auto-generated method stub
		for(User user:userList) {
			if(user.getUserName().equals(username)) {
				return user;
			}
		}
		return null;
	}

	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return userList;
	}

	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		for(User u:userList ) {
			if(u.getUserName().equals(user.getUserName())) {
				u.setEmailId(user.getEmailId());
				u.setPassword(user.getPassword());
				
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteUser(String username) {
		// TODO Auto-generated method stub
		User curruser=findUser(username);
		for(User u:userList) {
			if(u.getUserName().equals(curruser.getUserName())) {
				userList.remove(curruser);
				return true;
			}
		}
		return false;
	}

	
	

}
