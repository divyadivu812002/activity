package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.model.Message;

@Repository
public interface MessageDAO {
	boolean addMessage(Message message);
	Message findMessage(String messageName);
	List<Message>getAll();
	boolean updateMessage(Message message);
	boolean deleteMessage(String MessageName);

}
