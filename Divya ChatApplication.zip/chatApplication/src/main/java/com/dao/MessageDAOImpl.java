package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.model.Message;
@Component
public class MessageDAOImpl implements MessageDAO {
	List<Message>messageList;
	public MessageDAOImpl() {
		messageList=new ArrayList();
	}

	@Override
	public boolean addMessage(Message message) {
		// TODO Auto-generated method stub
	messageList.add(message);
	return true;
	}

	@Override
	public Message findMessage(String messageName) {
		// TODO Auto-generated method stub
		for(Message message:messageList) {
			if(message.getDescription().equals(messageName)) {
				return message;
			}
		}
		return null;
	}

	@Override
	public List<Message> getAll() {
		// TODO Auto-generated method stub
		return messageList;
	}

	@Override
	public boolean updateMessage(Message message) {
		// TODO Auto-generated method stub
		for(Message m:messageList) {
			if(m.getDescription().equals(message.getDescription())) {
				m.setFriendTo(message.getFriendTo());
				m.setUserFrom(message.getUserFrom());
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteMessage(String MessageName) {
		// TODO Auto-generated method stub
		Message curm=findMessage(MessageName);
		for(Message m:messageList) {
			if(m.getDescription().equals(curm.getUserFrom())) {
				messageList.remove(curm);
				return true;
			}
			
		}
		return false;
	}
	
	

}
