package com.service;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.dao.UserDAO;
import com.model.Friend;
import com.model.User;
 
@Service
public class UserService {
 
	@Autowired
	UserDAO userDAOImpl;
	public void addUser(User user)
	{
		if(userDAOImpl.addUser(user))
		{
			System.out.println("user added");
			
		}else
		{
			System.out.println("not added");
		}
		
	}
	
	public List<User> getAll()
	{
		return userDAOImpl.getAll();
	}
	
	
	public User findUser(String userName)
	{
		return userDAOImpl.findUser(userName);
	}
	
	
	public void updateUser(User user)
	{
		if(userDAOImpl.updateUser(user))
		{
			System.out.println("user updated successfully");
		}
		else
		{
			System.out.println("not updated");
		}
	}
	
	public void deleteUser(String username)
	{
		if(userDAOImpl.deleteUser(username))
		{
			System.out.println("user deleted");
		}else
		{
			System.out.println("unable tot delete");
		}
	}

	
}
 
