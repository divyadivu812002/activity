package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MessageDAO;

import com.model.Message;

@Service
public class MessageService {
	@Autowired
	MessageDAO messageDAOImpl;
	public void addMessage(Message message)
	{
		if(messageDAOImpl.addMessage(message))
		{
			System.out.println("Message added");
			
		}else
		{
			System.out.println("not added");
		}
		
	}
	
	public List<Message> getAll()
	{
		return messageDAOImpl.getAll();
	}
	
	
	public Message findMessage(String MessageName)
	{
		return messageDAOImpl.findMessage(MessageName);
	}
	
	
	public void updateMessage(Message message)
	{
		if(messageDAOImpl.updateMessage(message))
		{
			System.out.println("Message updated successfully");
		}
		else
		{
			System.out.println("not updated");
		}
	}
	
	public void deleteMessage(String messagename)
	{
		if(messageDAOImpl.deleteMessage(messagename))
		{
			System.out.println("Message deleted");
		}else
		{
			System.out.println("unable to delete");
		}
	}
}
