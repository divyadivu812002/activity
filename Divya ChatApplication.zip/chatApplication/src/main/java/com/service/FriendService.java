package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.FriendDAO;
import com.dao.UserDAO;
import com.model.Friend;
import com.model.User;


	@Service
	public class FriendService {
	 
		@Autowired
		FriendDAO friendDAOImpl;
		public void addFriend(Friend friend)
		{
			if(friendDAOImpl.addFriend(friend))
			{
				System.out.println("friend added");
				
			}else
			{
				System.out.println("not added");
			}
			
		}
		
		public List<Friend> getAll()
		{
			return friendDAOImpl.getAll();
		}
		
		
		public Friend findFriend(String friendName)
		{
			return friendDAOImpl.findFriend(friendName);
		}
		
		
		public void updateFriend(Friend friend)
		{
			if(friendDAOImpl.updateFriend(friend))
			{
				System.out.println("friend updated successfully");
			}
			else
			{
				System.out.println("not updated");
			}
		}
		
		public void deleteFriend(String friendname)
		{
			if(friendDAOImpl.deleteFriend(friendname))
			{
				System.out.println("friend deleted");
			}else
			{
				System.out.println("unable to delete");
			}
		}

		

}
