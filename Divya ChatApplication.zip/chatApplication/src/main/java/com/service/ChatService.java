package com.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ChatDAO;

import com.model.Chat;

@Service
public class ChatService {
	@Autowired
	ChatDAO chatDAOImpl;
	public void addChat(Chat chat)
	{
		if(chatDAOImpl.addChat(chat))
		{
			System.out.println("Chat added");
			
		}else
		{
			System.out.println("not added");
		}
		
	}
	
	public List<Chat> getAll()
	{
		return chatDAOImpl.getAll();
	}
	
	
	public Chat findChat(String ChatName)
	{
		return chatDAOImpl.findchat(ChatName);
	}
	
	
	public void updateChat(Chat chat)
	{
		if(chatDAOImpl.updateChat(chat))
		{
			System.out.println("Chat updated successfully");
		}
		else
		{
			System.out.println("not updated");
		}
	}
	
	public void deleteChat(String chatname)
	{
		if(chatDAOImpl.deleteChat(chatname))
		{
			System.out.println("Chat deleted");
		}else
		{
			System.out.println("unable to delete");
		}
	}
}

