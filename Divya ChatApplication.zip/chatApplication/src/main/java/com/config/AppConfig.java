package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.model.User;
@Configuration
public class AppConfig {
	@Bean
	public User getUser() {
		User user=new User();
		user.setUserName("Peter");
		user.setEmailId("peter@gmail.com");
		user.setPassword("password123");
		return user;
	}

}
