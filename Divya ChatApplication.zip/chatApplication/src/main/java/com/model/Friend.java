package com.model;

public class Friend {
	private String friendName;
	private String friendType;
	private String requestStatus;
	public Friend() {
		
	}
	public String getFriendName() {
		return friendName;
	}
	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}
	public String getFriendType() {
		return friendType;
	}
	public void setFriendType(String friendType) {
		this.friendType = friendType;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	@Override
	public String toString() {
		return "Friend [friendName=" + friendName + ", friendType=" + friendType + ", requestStatus=" + requestStatus
				+ "]";
	}
	

}
