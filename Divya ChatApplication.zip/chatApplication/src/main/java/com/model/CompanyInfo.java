package com.model;

import org.springframework.stereotype.Component;

@Component
public class CompanyInfo {
	public void printMessage() {
		System.out.println("###########################");
		System.out.println("###########App Development##########");
		System.out.println("###################On Spring Framework");
	}

}
