package com.model;

public class Message {
	private String UserFrom;
	private String FriendTo;
	private String description;
	public Message() {
		
	}
	public String getUserFrom() {
		return UserFrom;
	}
	public void setUserFrom(String userFrom) {
		UserFrom = userFrom;
	}
	public String getFriendTo() {
		return FriendTo;
	}
	public void setFriendTo(String friendTo) {
		FriendTo = friendTo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Message [UserFrom=" + UserFrom + ", FriendTo=" + FriendTo + ", description=" + description + "]";
	}
	

}
