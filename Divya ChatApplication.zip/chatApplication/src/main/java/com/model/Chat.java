package com.model;

import java.util.List;

public class Chat {
    private String chatName;
    private List<Message> messageList;

    public Chat() {
    }

    public Chat(String chatName, List<Message> messageList) {
        this.chatName = chatName;
        this.messageList = messageList;
    }

    public String getChatName() {
        return chatName;
    }

    public void setChatName(String chatName) {
        this.chatName = chatName;
    }

    public List<Message> getMessageList() {
        return messageList;
    }

    public void setMessageList(List<Message> messageList) {
        this.messageList = messageList;
    }

    @Override
    public String toString() {
        return "Chat [chatName=" + chatName + ", messageList=" + messageList + "]";
    }
}
